CREATE MATERIALIZED VIEW vm_payment_pit_for_migration AS SELECT DISTINCT p.id AS payment_id,
    LEAST((p.handling_at)::timestamp with time zone, COALESCE(d.executed_at, (pr.proc_updated_at)::timestamp with time zone, ((p.created_at + '00:05:00'::interval))::timestamp with time zone)) AS time_point
   FROM ((payments p
     LEFT JOIN ( SELECT DISTINCT decisions.payment_id,
            min(to_timestamp((decisions.variables #>> '{Analytic,executed_at}'::text[]), 'YYYY-MM-DD HH24:MI:SS.US'::text)) AS executed_at
           FROM decisions
          WHERE ((decisions.application_name)::text = ANY ((ARRAY['Bender_Auto_Decide'::character varying, 'Bender'::character varying])::text[]))
          GROUP BY decisions.payment_id) d ON ((d.payment_id = p.id)))
     LEFT JOIN ( SELECT DISTINCT proc_requests.payment_id,
            min((proc_requests.updated_at + '00:01:00'::interval)) AS proc_updated_at
           FROM proc_requests
          WHERE ((proc_requests.status = 'success'::proc_tx_status) AND (proc_requests.tx_type = 'authorization'::tx_type))
          GROUP BY proc_requests.payment_id) pr ON ((p.id = pr.payment_id)))
  WHERE (p.id < 299125);

CREATE UNIQUE INDEX vm_payment_pit_for_migration_payment_id_key
  ON vm_payment_pit_for_migration (payment_id);

