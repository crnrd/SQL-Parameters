CREATE FUNCTION simulator_shay(username character varying, application_name character varying, analytic_code_version character varying, payment_ids integer[])
  RETURNS integer
LANGUAGE plpgsql
AS $$
DECLARE
	payment_ids_curs CURSOR FOR select id from payments where /*status > 0 and */  id = ANY(payment_ids);
	decision SqlDecisionType;
	counts integer;
	run_id integer;
	err_str1 text;
	err_str2 text;
	err_str3 text;
BEGIN
	INSERT INTO simulation_runs_shay ( "username",  "application_name",  "analytic_code_version" )
	VALUES (  username,  application_name,  analytic_code_version)
	RETURNING id into run_id;

	counts := 0;
	--select count(*) into counts from (select id,bender_noam(run_id, id)  from payments where status in (1,6) and id between 16812 and 16820)a;
	FOR payment_rec in payment_ids_curs LOOP
		BEGIN		
			select 
				f.payment_id,
	 	    f.decision,
	  	  f.variables,
		    f.reason,
		    f.application_name,
		    f.analytic_code_version,
		    f.executed_at 
			into decision from bender_shay(payment_rec.id) f;
			BEGIN
				INSERT INTO simulations_shay(  "run_id",  "payment_id",  "reason", "decision",  "variables" ) 
								VALUES (run_id, decision.payment_id, decision.reason, decision.decision, decision.variables);
			EXCEPTION WHEN not_null_violation THEN
				RAISE NOTICE 'Error runnign analytic model on payment(%)', payment_rec.id;
			END;
		EXCEPTION WHEN OTHERS THEN
			GET STACKED DIAGNOSTICS err_str1 = MESSAGE_TEXT,
                          err_str2 = PG_EXCEPTION_DETAIL,
                          err_str3 = PG_EXCEPTION_HINT;
      RAISE NOTICE 'Error runnign analytic model on payment(%) \n (%) \n (%) \n (%) \n', payment_rec.id, err_str1, err_str2, err_str3;
		END;
		
		--insert into simulation_results(payment_id, decision) values (payment_rec.id, decision);
		counts = counts + 1;
	END LOOP;

RETURN counts;

END;
$$;

