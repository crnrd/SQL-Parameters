CREATE VIEW v_migration_log_by_seu AS
  SELECT p.id,
    p.status,
    p.updated_at,
    pb.email,
    pb.first_name,
    pb.last_name,
    pb.phone,
    pb.address,
    pb.city,
    pb.state,
    pb.country,
    pb.zip
   FROM (payments_log p
     LEFT JOIN vm_simplex_users_and_log_billing pb ON (((pb.id = p.simplex_end_user_id) AND (pb.updated_at = ( SELECT max(pb1.updated_at) AS max
           FROM vm_simplex_users_and_log_billing pb1
          WHERE ((pb1.updated_at <= p.updated_at) AND (pb1.id = p.simplex_end_user_id)))))))
  WHERE (p.current_payment_id < 299125);

