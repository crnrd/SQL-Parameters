CREATE VIEW v_migration_by_seu AS
  SELECT p.id,
    p.status,
    p.updated_at,
    pb.email,
    pb.first_name,
    pb.last_name,
    pb.phone,
    pb.address,
    pb.city,
    pb.state,
    pb.country,
    pb.zip,
    pit.time_point,
    pb.id AS seu_id
   FROM ((payments p
     LEFT JOIN vm_payment_pit_for_migration pit ON ((pit.payment_id = p.id)))
     LEFT JOIN vm_simplex_users_and_log_billing pb ON (((pb.id = p.simplex_end_user_id) AND (pb.updated_at = ( SELECT max(pb1.updated_at) AS max
           FROM vm_simplex_users_and_log_billing pb1
          WHERE ((pb1.updated_at <= pit.time_point) AND (pb1.id = p.simplex_end_user_id)))))))
  WHERE (p.id < 299125);

