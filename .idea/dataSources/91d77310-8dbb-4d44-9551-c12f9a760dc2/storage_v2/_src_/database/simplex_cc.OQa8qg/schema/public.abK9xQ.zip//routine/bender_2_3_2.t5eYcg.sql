CREATE FUNCTION bender_2_3_2(payment_pk integer, time_point timestamp without time zone)
  RETURNS sqldecisiontype
LANGUAGE plpgsql
AS $fun$
DECLARE
  model_decision SqlDecisionType;
  decision_out TEXT;
  payment payments%ROWTYPE;
  sim_time timestamp;
BEGIN

-- populate payment variable
select * from payments into payment where id = payment_pk;
sim_time = time_point;
-- BEGINNING OF ANALYTIC CODE

WITH
-------------------------------------------------------------------------
-------------------------------------------------------------------------
payment_info /* on commit drop */
AS 
(
select case when first_payment_id  is null then 1 else 0 end is_first,
       case when last_payment_time is not null then last_payment_time end last_payment_time,
       case when last_payment is not null then last_payment end last_payment   
       from ( 
       SELECT MIN(id) first_payment_id,
       max(created_at) last_payment_time,
       max(id) last_payment
       from payments
WHERE status > 0       
-- &&&&&&&&&&&&&&&&&&&
AND created_at < sim_time
AND id != payment.id
-- &&&&&&&&&&&&&&&&&&&
-- ***************
AND validation_request_body #>> '{email}' = payment.validation_request_body #>> '{email}' --     'scottscanlon63@gmail.com' 
-- ***************
-- and status > 0  -- redunadant because handling_at is null in all such cases 
)z
)

,total_simplex_approved_amount  /* on commit drop */ 
AS 
(SELECT coalesce(sum(payment_amount),0) total_approved_amount FROM 
(SELECT CASE  WHEN lower(currency) = 'gbp' THEN total_amount*1.55
              WHEN lower(currency) = 'eur' THEN total_amount*1.12
              WHEN lower(currency) = 'ils' THEN total_amount*0.26
              ELSE total_amount END payment_amount 
FROM payments 
WHERE status IN (2,6,13,15)
-- &&&&&&&&&&&&&&&&&&&
and handling_at < sim_time
AND id != payment.id
-- &&&&&&&&&&&&&&&&&&&
-- **************
AND simplex_end_user_id = payment.simplex_end_user_id
-- **************
) a
)

,WP_data /* on commit drop */
AS
(SELECT payment_id, email, inserted_at, wp_phone, 
simplex_phone_prepaid,
simplex_phone_line_type,       
partner_phone_prepaid,
partner_phone_line_type,
CASE
WHEN simplex_phone_spam IN ('No spam indication','Low spam indication%') AND simplex_phone_prepaid <> 'Prepaid' AND simplex_phone_line_type IN ('Mobile','Landline') 
THEN false ELSE true END AS simplex_phone_not_valid,
CASE
WHEN partner_phone_spam IN ('No spam indication','Low spam indication%') AND partner_phone_prepaid <> 'Prepaid' AND partner_phone_line_type IN ('Mobile','Landline') 
THEN false ELSE true END AS partner_phone_not_valid,  
CASE     
WHEN --simplex_name_garbled_message = 'Looks valid' AND 
simplex_name_celeb_message = 'Possible fake name (matches well-known name)' 
THEN true ELSE false END AS simplex_name_not_valid, 
CASE
WHEN --simplex_name_on_card_garbled_message = 'Looks valid' AND 
simplex_name_on_card_celeb_message = 'Possible fake name (matches well-known name)' 
THEN true ELSE false END AS simplex_name_on_card_not_valid,
CASE
WHEN --partner_name_garbled_message = 'Looks valid' AND 
partner_name_celeb_message = 'Possible fake name (matches well-known name)' 
THEN true ELSE false END AS partner_name_not_valid,    
CASE 
WHEN (simplex_address_type IN ('Single unit','PO box','Multi unit','Unknown address type') AND simplex_address_receiving_mail <> 'receiving_mail.warn' AND simplex_address_deliverable <> 'deliverable.warn') 
THEN false ELSE true END AS simplex_address_not_valid,
CASE 
WHEN (partner_address_type IN ('Single unit','PO box','Multi unit','Unknown address type') AND partner_address_receiving_mail <> 'receiving_mail.warn' AND partner_address_deliverable <> 'deliverable.warn') 
THEN false ELSE true END AS partner_address_not_valid,
 -- matching       
       CASE
         WHEN simplex_phone_addr_message = 'Directly connected to each other' THEN 'full_match'
         WHEN simplex_phone_addr_message = 'Indirectly connected to each other' THEN 'partial_match'
         ELSE 'no_match'
       END AS simplex_phone_address_match,
       CASE
         WHEN simplex_phone_name_code = 'match_status.perfect' THEN 'full_match'
         WHEN simplex_phone_name_code = 'match_status.inexact' THEN 'partial_match'
         ELSE 'no_match'
       END AS simplex_phone_name_match,
       CASE
         WHEN simplex_addr_name_code = 'match_status.perfect' THEN 'full_match'
         WHEN simplex_addr_name_code = 'match_status.inexact' THEN 'partial_match'
         ELSE 'no_match'
         END AS simplex_address_name_match,
       CASE
         WHEN simplex_phone_name_on_card_code = 'match_status.perfect' THEN 'full_match'
         WHEN simplex_phone_name_on_card_code = 'match_status.inexact' THEN 'partial_match'
         ELSE 'no_match'
       END AS simplex_phone_name_on_card_match,
       CASE
         WHEN simplex_addr_name_on_card_code = 'match_status.perfect' THEN 'full_match'
         WHEN simplex_addr_name_on_card_code = 'match_status.inexact' THEN 'partial_match'
         ELSE 'no_match'
       END AS simplex_address_name_on_card_match,
       CASE
         WHEN partner_phone_addr_message = 'Directly connected to each other' THEN 'full_match'
         WHEN partner_phone_addr_message = 'Indirectly connected to each other' THEN 'partial_match'
         ELSE 'no_match'
       END AS partner_phone_address_match,
       CASE
         WHEN partner_phone_name_code = 'match_status.perfect' THEN 'full_match'
         WHEN partner_phone_name_code = 'match_status.inexact' THEN 'partial_match'
         ELSE 'no_match'
       END AS partner_phone_name_match,
       CASE
         WHEN partner_addr_name_code = 'match_status.perfect' THEN 'full_match'
         WHEN partner_addr_name_code = 'match_status.inexact' THEN 'partial_match'
         ELSE 'no_match'
       END AS partner_address_name_match
FROM 
(SELECT payment_id, email, inserted_at, replace(request_data->> 'billing_phone','%2B','+') wp_phone, 
-- validation
             DATA  #>> '{components,billing_phone_validation,diagnostics,1,message}' simplex_phone_spam,
             DATA  #>> '{components,billing_phone_validation,diagnostics,2,message}' simplex_phone_prepaid,
             DATA  #>> '{components,billing_phone_validation,diagnostics,3,message}' simplex_phone_line_type,
             DATA  #>> '{components,phone_validation,diagnostics,1,message}' partner_phone_spam,
             DATA  #>> '{components,phone_validation,diagnostics,2,message}' partner_phone_prepaid,
             DATA  #>> '{components,phone_validation,diagnostics,3,message}' partner_phone_line_type,             
             DATA  #>> '{components,billing_name_validation,diagnostics,0,message}' simplex_name_on_card_celeb_message,
             DATA  #>> '{components,billing_name_validation,diagnostics,1,message}' simplex_name_on_card_garbled_message,
             DATA  #>> '{components,shipping_name_validation,diagnostics,0,message}' simplex_name_celeb_message,
             DATA  #>> '{components,shipping_name_validation,diagnostics,1,message}' simplex_name_garbled_message,
             DATA  #>> '{components,name_validation,diagnostics,0,message}' partner_name_celeb_message,
             DATA  #>> '{components,name_validation,diagnostics,1,message}' partner_name_garbled_message,             
             DATA  #>> '{components,billing_address_validation,diagnostics,0,message}' simplex_address_type,
             DATA  #>> '{components,billing_address_validation,diagnostics,1,code}' simplex_address_receiving_mail,
             DATA  #>> '{components,billing_address_validation,diagnostics,2,code}' simplex_address_deliverable,
             DATA  #>> '{components,billing_address_family_count,diagnostics,0,message}' simplex_address_family_count_message,
             DATA  #>> '{components,address_validation,diagnostics,0,message}' partner_address_type,
             DATA  #>> '{components,address_validation,diagnostics,1,code}' partner_address_receiving_mail,
             DATA  #>> '{components,address_validation,diagnostics,2,code}' partner_address_deliverable,
             DATA  #>> '{components,address_family_count,diagnostics,0,message}' partner_address_family_count_message,
-- matching
             DATA #>> '{components,billing_phone_name,diagnostics,0,code}' simplex_phone_name_on_card_code,
             DATA #>> '{components,billing_address_name,diagnostics,0,code}' simplex_addr_name_on_card_code,
             DATA #>> '{components,shipping_phone_address,diagnostics,0,message}' simplex_phone_addr_message,
             DATA #>> '{components,shipping_phone_name,diagnostics,0,code}' simplex_phone_name_code,
             DATA #>> '{components,shipping_address_name,diagnostics,0,code}' simplex_addr_name_code,
             DATA #>> '{components,phone_address,diagnostics,0,message}' partner_phone_addr_message,
             DATA #>> '{components,phone_name,diagnostics,0,code}' partner_phone_name_code,
             DATA #>> '{components,address_name,diagnostics,0,code}' partner_addr_name_code             
-- going over all (and only!) payments of this simplex user
  FROM (select ew.*,
        replace(request_data #>> '{email_address}','%40','@') email,
        max(inserted_at) over (partition by (request_data #>> '{email_address}','%40','@')::text) max_inserted_at
       from enrich_whitepages ew
--       left join payments p on (p.id=ew.payment_id)
-- ****************
        where replace(request_data #>> '{email_address}','%40','@') = payment.validation_request_body #>> '{email}'
-- ****************
 )
a where inserted_at=max_inserted_at
) wp
 ) 

,WP_payment_phone_match /* on commit drop */
AS
(SELECT p.id payment_id,
       CASE  WHEN p.id IN
       (SELECT payment_id
       FROM (SELECT id payment_id,
                    simplex_end_user_id,
                    phone
                    FROM (SELECT id,
                          updated_at,
                         phone,
                         MIN(updated_at) OVER (PARTITION BY id) min_updated_at
                         FROM (SELECT p.id,
                              p.created_at,
                              s.updated_at,
                              phone
                              FROM payments p
                              LEFT JOIN 
                              ( (SELECT id,
                                        updated_at,
                                        phone
                                        FROM simplex_end_users)
                                 UNION ALL 
                                 (SELECT current_simplex_user_id id,
                                         updated_at,
                                         phone
                                         FROM simplex_end_users_log)) s ON s.id = p.simplex_end_user_id
                                    -- ***************
                                    WHERE p.simplex_end_user_id = payment.simplex_end_user_id
                                    -- ***************
                                    AND   s.updated_at > p.created_at) a) b
                          WHERE updated_at = min_updated_at) a
                          LEFT JOIN (SELECT inserted_at,
                                           wp_phone
                                           FROM WP_data wp )b
                                ON a.phone = b.wp_phone
                       WHERE wp_phone IS NOT NULL) THEN 1
         ELSE 0
       END is_payment_phone_same_as_wp_phone
FROM payments p
-- ***************
where p.id = payment.id
-- ***************
)

-------------------------------------------------------------------------------
, user_form_attempts  /* on commit drop */

as (
select t1.id, name_count, name_on_card_count, address_count, name_count+name_on_card_count+address_count total_count from 
(
select payment_id id, count(distinct(name_string)) name_count from 
(select payment_id,
--valid name
case when response_data #>> '{errors,first_name,msg}' LIKE '%Latin characters only' or
response_data #>> '{errors,last_name,msg}' LIKE '%Latin characters only' then 1 else 0 end invalid_input_name,
-- name
regexp_replace(lower(request_data ->> 'first_name')||lower(request_data ->> 'last_name') ||lower(request_data ->> 'first_name_card')||lower(request_data ->> 'last_name_card'), ' ', '', 'g') name_string
--
from user_browser_events 
where event_type='validate'
) a where invalid_input_name = 0 and name_string <> '' group by 1
) t1
left join 
(
select payment_id id, count(distinct(address_string)) address_count from 
(select payment_id,
-- valid adddess
case when response_data #>> '{errors,address,msg}' LIKE '%invalid characters' or
response_data #>> '{errors,address2,msg}' LIKE '%invalid characters' or
response_data #>> '{errors,city,msg}' LIKE '%invalid characters'  or
response_data #>> '{errors,zip,msg}' LIKE '%invalid characters'  then 1 else 0 end invalid_input_address,
-- address
regexp_replace(lower(request_data #>> '{address}')||lower(request_data #>> '{address2}') ||lower(request_data #>> '{city}') ||lower(request_data #>> '{country}') ||lower(request_data #>> '{state}') ||lower(request_data #>> '{zip}'), ' ', '', 'g') address_string
--
from user_browser_events 
where event_type='validate'
) a where invalid_input_address = 0 and address_string <> '' group by 1
) t2
on t1.id = t2.id
left join 
(
select payment_id id, count(distinct(name_string)) name_on_card_count from 
(select payment_id,
--valid name
case when 
response_data #>> '{errors,first_name_card,msg}' LIKE '%Latin characters only'  or
response_data #>> '{errors,last_name_card,msg}' LIKE '%Latin characters only'  then 1 else 0 end invalid_input_name,
-- name
regexp_replace(lower(request_data ->> 'first_name_card')||lower(request_data ->> 'last_name_card'), ' ', '', 'g') name_string
--
from user_browser_events 
where event_type='validate'
) a where invalid_input_name = 0 and name_string <> '' group by 1
) t3 
on t1.id = t3.id
left join payments p on p.id = t1.id
-- ****************
where p.id = payment.id
-- ****************
)
--------------------------------------------------------------------------------------
,lang_per_id  /* on commit drop */
as (
SELECT CASE
         WHEN POSITION(';' IN lang_with_weight) = 0 THEN lang_with_weight
         ELSE LEFT (lang_with_weight,POSITION(';' IN lang_with_weight) -1)
       END lang,
       CASE
         WHEN POSITION('q=' IN lang_with_weight) = 0 THEN NULL
         ELSE RIGHT (lang_with_weight,char_length(lang_with_weight) - POSITION('q=' IN lang_with_weight) -1)
       END weight,
       count(*) over (partition by id) lang_num,
       ip_country,
       ad_country
from (SELECT id, (simplex_login ->> 'http_accept_language') lang_list,
             UNNEST   (coalesce (STRING_TO_ARRAY (simplex_login ->> 'http_accept_language',','), ARRAY [''] ) )  lang_with_weight,
             maxmind ->> 'countryCode' AS ip_country,
             country as ad_country
      FROM payments a
-- ***************
      where id=payment.id
-- ***************
) a )

,lang_country_match /* on commit drop */  
AS
(SELECT 
       lang_num,
       CASE
         WHEN lang_num=1 and ad_lang_match>0 THEN 'single_match'
         WHEN ad_lang_match > 0 THEN 'match'
         ELSE 'no_match'
       END ad_lang_match,
       CASE
         WHEN lang_num = 1 AND ip_lang_match >0 THEN 'single_match'
         WHEN ip_lang_match > 0 THEN 'match'
         ELSE 'no_match'
       END ip_lang_match
FROM (SELECT  lang_num,
             SUM(CASE WHEN ad_lang_match = 'match' THEN 1 ELSE 0 END) ad_lang_match,
             SUM(CASE WHEN ip_lang_match = 'match' THEN 1 ELSE 0 END) ip_lang_match
      FROM (SELECT a.*, b.country_code, b.language_code, c.country_code, c.language_code,
                   CASE
                     WHEN LOWER(ad_country) != 'us' AND LOWER(lang) LIKE LOWER('%' || ad_country || '%') THEN 'match'
                     WHEN lower(b.language_code) LIKE LOWER('%' || ad_country || '%') THEN 'match'
                     WHEN lower(lang) LIKE LOWER('%' || b.language_code || '%') THEN 'match'
                     ELSE 'no_match'
                   END ad_lang_match,
                   CASE
                     WHEN LOWER(ip_country) != 'us' AND LOWER(lang) LIKE LOWER('%' || ip_country || '%') THEN 'match'
                     WHEN lower(c.language_code) LIKE LOWER('%' || ip_country || '%') THEN 'match'
                     WHEN lower(lang) LIKE LOWER('%' || c.language_code || '%') THEN 'match'
                     ELSE 'no_match'
                   END ip_lang_match
            FROM lang_per_id a
              LEFT JOIN lang_table b
                     ON a.ad_country = b.country_code
              LEFT JOIN lang_table c
                     ON a.ip_country = c.country_code) aa
      GROUP BY 1) bb)

,parsed_user_agent /* on commit drop */
AS (
         SELECT CASE
         WHEN POSITION(';' IN user_agent) - POSITION('(' IN user_agent) < 0 THEN SUBSTRING(user_agent FROM POSITION('(' IN user_agent) +1 FOR POSITION(')' IN user_agent) - POSITION('(' IN user_agent) -1)
         ELSE SUBSTRING(user_agent FROM POSITION('(' IN user_agent) +1 FOR POSITION(';' IN user_agent) - POSITION('(' IN user_agent) -1)
         END user_agent_os
FROM (SELECT simplex_login ->> 'user_agent' user_agent
      FROM payments
      WHERE id=payment.id) a )


-- *******************  EMAIL **********************
,ea_attributes /* on commit drop */
as (
select email,inserted_at,
case when (ea_array ->> 'emailAge')='' then 0 else 1 end ea_is_age_created_at,
to_timestamp(regexp_replace(ea_array ->> 'firstVerificationDate','[TZ]', ' ','g'),'YYYY-MM-DD HH24:MI:SS') as ea_first_seen,
to_timestamp(regexp_replace(ea_array  ->> 'domainAge','[TZ]',' ','g'),'YYYY-MM-DD HH24:MI:SS') as ea_dom_created_at,
replace(ea_array  ->> 'eName','+',' ') ea_name,
ea_array  ->> 'status' ea_status,
ea_array  ->> 'country' ea_country,
cast(nullif(ea_array  ->> 'EAScore','') as numeric)  ea_score,
ea_array  ->> 'EAReason' ea_reason,
ea_array  ->> 'EARiskBandID' ea_risk_band,
ea_array  ->> 'dob' ea_dob,
ea_array  ->> 'gender' ea_gender,
replace(ea_array  ->> 'location','+',' ') ea_location,
cast(nullif(ea_array  ->> 'smfriends','') as numeric) ea_smfriends,
jsonb_array_length(ea_array  -> 'smlinks') ea_smlinks,
(nullif(ea_array  ->> 'totalhits','') ) ea_hits,
ea_array  ->> 'company' ea_company,
ea_array  ->> 'title' ea_title
from  (select email,inserted_at, DATA  #> '{query,results,0}' ea_array ,max(inserted_at) over (partition by email) max_inserted_at
from enrich_email_age
-- ***************
where email = payment.validation_request_body #>> '{email}'
-- ***************
) emailage
where inserted_at=max_inserted_at
)

,radar_proxy_detection /* on commit drop */
AS 
(
SELECT payment_id, 1000*cast(data #>> '{main,loose,diff}' as real) diff 
FROM (select *, max(inserted_at) over (partition by payment_id) max_inserted_at from proxy_detection
-- ***************
where payment_id = payment.payment_id
-- ***************
) pd where inserted_at=max_inserted_at
)

,cc_info_simplex_user /* on commit drop */
AS
(
select array_agg (credit_card) cards,
--       array_agg (case when max_status>1 then credit_card end) real_payments_cards
--       not taking into account status=8
       count(distinct credit_card) num_user_ccs,  
       sum (case when max_status = 0 then 1 else 0 end) num_status_0_ccs,
       -- first time users don't have last_payment_time (in this case num_status_0_ccs = num_new_status_0_ccs)
       sum (case when max_status = 0 and cc_first_seen > coalesce (last_payment_time, date '2000-01-01') then 1 else 0 end)   num_new_status_0_ccs
from (                
select distinct credit_card, max(status) max_status,
          min (created_at) cc_first_seen
      FROM (
            SELECT credit_card, 
            case when status = 16 then 0 else status end status,
             created_at,
            p.validation_request_body #>> '{email}' email
            FROM payments p
        where p.validation_request_body #>> '{email}' = payment.validation_request_body #>> '{email}' -- 'scottscanlon63@gmail.com'
            UNION ALL
            select credit_card, 0 status, created_at,
            pl.validation_request_body #>> '{email}' email
            FROM payments_log pl
        where pl.validation_request_body #>> '{email}'  = payment.validation_request_body #>> '{email}' --'scottscanlon63@gmail.com'
            UNION ALL
            select validation_request_body #>> '{credit_card}' credit_card, 0 status, created_at,
            pl.validation_request_body #>> '{email}' email
            FROM payments_log pl
        where pl.validation_request_body #>> '{email}' = payment.validation_request_body #>> '{email}' --'scottscanlon63@gmail.com'
            UNION ALL
            select masked_credit_card credit_card, 0 status, prv.created_at,
            p.validation_request_body #>> '{email}' email
            FROM proc_requests_view prv
            left join payments p on (prv.payment_id = p.id)
        where p.validation_request_body #>> '{email}' = payment.validation_request_body #>> '{email}' --'scottscanlon63@gmail.com'
) x
where credit_card is not null
and credit_card != '' 
-- &&&&&&&&&&&&&&
and created_at <= sim_time
-- &&&&&&&&&&&&&&
group by 1
)z
cross join payment_info
)

,phone_country_code_mismatch /* on commit drop */
AS
(
select simplex_end_user_id, true as mismatch from 
(
SELECT id simplex_end_user_id
FROM (SELECT *
      FROM (SELECT id,
                   country,
                   REPLACE(phone,'+','') phone
            FROM simplex_end_users
-- ***************
where id = payment.simplex_end_user_id
-- ***************
) se
        LEFT JOIN (SELECT *,
                          CHAR_LENGTH(phone_code::text) prefix_len
                   FROM phone_country_codes) ph ON LEFT (se.phone,ph.prefix_len)::INT = ph.phone_code) aa
GROUP BY 1
HAVING SUM(CASE WHEN country = country_code THEN 1 ELSE 0 END) = 0
) a
)


-- *******************  partner_end_user_id **********************

,KYC  /* on commit drop */ as (
select
case when (kyc_files->'address'->0) is not null then 1 else 0 end address_KYC, 
case when (kyc_files->'identity'->0) is not null then 1 else 0 end identity_KYC,
case when social_data_id>0 then 1 else 0 end  social_media_partner 
from partner_end_users
-- **************
where id= payment.partner_end_user_id
-- **************
)

,total_partner_deposits /* on commit drop */
AS
(SELECT 
       coalesce(SUM(amount_usd),0) fiat_amount,
       CASE
         WHEN SUM(alt_coin_deposits) > 0 THEN 1
         ELSE 0
       END alt_coin_deposits
FROM (SELECT
             CASE
               WHEN LOWER(currency) = 'ils' THEN amount*0.26
               WHEN LOWER(currency) = 'gbp' THEN amount*1.55
               WHEN LOWER(currency) = 'eur' THEN amount*1.12
               WHEN LOWER(currency) = 'usd' THEN amount
               ELSE NULL
             END amount_usd,
             CASE
               WHEN LOWER(currency) IN ('btc','ltc','drk','doge') THEN 1
               ELSE 0
             END alt_coin_deposits from 
(select cast(deposits#>>'{money,amount}' as real) amount,
        deposits#>>'{money,currency}' currency,
         cast(deposits#>>'{timestamp}' as timestamp) deposit_time
        from 
(SELECT
       CASE
         WHEN jsonb_array_length (deposits) > 0 THEN jsonb_array_elements (deposits)
         ELSE NULL
       END AS deposits
FROM partner_end_users
-- ***********
WHERE id = payment.partner_end_user_id
-- ***********
) a
) b
where deposit_time < sim_time
) c
)

, verification_requests as (
    select payment_id, min(inserted_at) min_verification_request_time
    from verification_requests
    where payment_id=payment.id
    and inserted_at < sim_time
    group by 1
)

--------------------------------------------------------------------------------------------------
-- Variables: payment_data_set -------------------------------------------------------------------
--------------------------------------------------------------------------------------------------
,payment_data_set /* on commit drop */
AS
(SELECT a.id payment_id,
       a.status,
       a.created_at,
       CASE
         WHEN lower(a.currency) = 'ils' THEN a.total_amount*0.26
         WHEN lower(a.currency) = 'gbp' THEN a.total_amount*1.55
         WHEN lower(a.currency) = 'eur' THEN a.total_amount*1.12
         WHEN lower(a.currency) = 'usd' THEN a.total_amount
         ELSE NULL
       END total_amount_usd,
       a.credit_card,
       a.country,
       a.simplex_end_user_id,
       a.partner_end_user_id,
       a.validation_request_body #>> '{email}' email,
-- *******
/*      prv.raw_response ->> 'status' 3d_status,
      prv.raw_response ->> 'status' 3d_enrolled,      */
-- *******
       prv.processor,
      case when prv.processor = 'compayments'    then prv.avs_code ->> 'avs_code'    end avs_code,
      case when prv.processor = 'secure_trading' then prv.avs_code ->> 'avs_address' end avs_address,
      case when prv.processor = 'secure_trading' then prv.avs_code ->> 'avs_zipcode' end avs_zipcode,
       
CASE     WHEN lower(b.first_name || ' ' || b.last_name) = lower(a.first_name_card || ' ' || a.last_name_card) THEN 'full_match'
         WHEN similarity (lower(b.first_name || ' ' || b.last_name),lower(a.first_name_card || ' ' || a.last_name_card)) >= 0.2 THEN 'partial_match'
         ELSE 'no_match'
       END name_on_card_match,
rpd.diff radar_diff,
coalesce(pccm.mismatch,false) phone_country_mismatch, 
a.blocked -> 'ip' ->> 'blocked' blocked,
CAST(a.maxmind ->> 'distance' AS REAL) AS mm_distance,
a.maxmind ->> 'countryMatch' AS mm_countryMatch,
a.maxmind ->> 'freeMail' AS mm_freeMail,
a.maxmind ->> 'anonymousProxy' AS mm_anonymousProxy,
a.maxmind ->> 'binMatch' AS mm_binMatch,
a.maxmind ->> 'countryCode' AS ip_country,
a.maxmind ->> 'binCountry' AS bin_country,
CAST(a.maxmind ->> 'proxyScore' AS REAL) AS mm_proxyScore,
a.maxmind ->> 'ip_userType' AS mm_ip_userType,
CASE
         WHEN CHAR_LENGTH(maxmind ->> 'ip_postalCode') > 0 THEN 'zip'
         WHEN CHAR_LENGTH(maxmind ->> 'ip_city') > 0 THEN 'city'
         WHEN CHAR_LENGTH(maxmind ->> 'ip_regionName') > 0 THEN 'region'
         ELSE 'country'
       END AS mm_match_type,
a.maxmind ->> 'ip_accuracyRadius' AS mm_ip_accuracyRadius,     
--a.maxmind->>'ip_domain' as mm_ip_domain, --use to match email domain?
--right(b.email,char_length(b.email)-position('@' in b.email)) as email_domain,
a.maxmind ->> 'ip_corporateProxy' AS mm_ip_corporateProxy,
a.maxmind ->> 'carderEmail' AS mm_carderEmail,
CAST(a.maxmind ->> 'riskScore' AS REAL) AS mm_riskScore,
a.maxmind ->> 'prepaid' AS mm_prepaid,
CASE WHEN SUBSTRING(Coalesce(address1||' '||address2,address1) FROM '[0-9]+') IS NULL THEN 1 ELSE 0 END no_numbers_ad,
a.first_name_card,
a.last_name_card,
CASE WHEN SUBSTRING(a.credit_card FROM 1 FOR 6) IN (SELECT * FROM virtual_bins) OR lower (maxmind ->> 'binName') IN ('entropay', 'teller','skrill', 'vanilla', 'nxpay') THEN true ELSE false END is_virtual_cc,
a.simplex_login->> 'uaid' cookie,
a.simplex_login->> 'ip' ip,
lower(a.address1 || ' ' || coalesce(a.address2,'') || ' ' || a.city || ' ' || a.country || ' ' || a.zipcode) address,
a.btc_address,    
c.two_fa_enabled,
b.first_name,
b.last_name,
partner_id,
case when a.user_comment <> '' then 1 else 0 end is_user_comment,
ccisu.cards,
ccisu.num_user_ccs,
ccisu.num_status_0_ccs,
ccisu.num_new_status_0_ccs,                 
CASE WHEN lower(ea.ea_reason) similar TO '%(risky|risk domain|risk email pattern|high risk|fraud|velocity)%' THEN 1 ELSE 0 END ea_reason_fraud,
case when extract(days FROM (a.created_at-ea.ea_first_seen)::interval)::real<0 then 0 else extract(days FROM (a.created_at-ea.ea_first_seen)::interval)::real end as ea_age,
ea.ea_name,
ea.ea_score,
ufa.name_count num_name_changes, ufa.name_on_card_count num_name_on_card_changes, ufa.address_count num_address_changes,
case when ea_smfriends>0 or ea_smlinks>0 or social_media_partner=1 then true else false end is_social_media,
---------------------------------------------------------------------------------------------------------------------------------------------------------
-- White Pages Data
simplex_phone_prepaid,
simplex_phone_line_type,       
partner_phone_prepaid,
partner_phone_line_type,
simplex_phone_not_valid,
partner_phone_not_valid,       
simplex_name_not_valid,
simplex_name_on_card_not_valid,
partner_name_not_valid,       
simplex_address_not_valid,
partner_address_not_valid,
---------------------------------------------------------------------------------------------------------------------------------------------------------
-- White Pages Matching
case when partner_phone_not_valid = false and partner_name_not_valid = false then partner_phone_name_match else 'not_valid' end as wp_partner_phone_name,
case when partner_phone_not_valid = false and partner_address_not_valid = false then partner_phone_address_match else 'not_valid' end as wp_partner_phone_address,
case when partner_name_not_valid = false and partner_address_not_valid = false then partner_address_name_match else 'not_valid' end as wp_partner_address_name,
-- simplex name
case when is_payment_phone_same_as_wp_phone = 1 and simplex_phone_not_valid = false and simplex_name_not_valid = false then simplex_phone_name_match else 'not_valid' end as wp_simplex_phone_name,
case when is_payment_phone_same_as_wp_phone = 1 and simplex_phone_not_valid = false and simplex_address_not_valid = false then simplex_phone_address_match else 'not_valid' end as wp_simplex_phone_address,
case when simplex_name_not_valid = false and simplex_address_not_valid = false then simplex_address_name_match else 'not_valid' end as wp_simplex_address_name,
-- simplex name on card
case when is_payment_phone_same_as_wp_phone = 1 and simplex_phone_not_valid = false and simplex_name_on_card_not_valid = false then simplex_phone_name_on_card_match else 'not_valid' end as wp_simplex_phone_name_on_card,
case when is_payment_phone_same_as_wp_phone = 1 and simplex_name_on_card_not_valid = false and simplex_address_not_valid = false then simplex_address_name_on_card_match else 'not_valid' end as wp_simplex_address_name_on_card,
----------------------------------------------------------------------------------------------------------------------------------------------------------
lcm.ip_lang_match,
lcm.ad_lang_match,
case when ad_lang_match = 'no_match' then true else false end lang_add_mismatch,  
case when ip_lang_match = 'no_match' then true else false end lang_ip_mismatch, 
tsa.total_approved_amount,
pua.user_agent_os,
d.is_first,
d.last_payment,
d.last_payment_time,
case when dis.dis_domain is null then false else true end is_email_disposable,
-- Genesis, Spondoolies, Bits of Gold, Bittylicious (perhaps others)
case when partner_id in (1, 3, 4, 7, 8, 9, 10) then ceil(tpd.fiat_amount - tsa.total_approved_amount) --ALL CASES!! MUST EXPLORE FURTHER
-- in the case of coinmama (and the rest?) partner_users holds only their deposits
else ceil(fiat_amount)  
end as past_usd_partner_deposits,
tpd.alt_coin_deposits,
identity_KYC,
address_KYC, 
partners.service_type partner_type,
vr.min_verification_request_time

FROM payments a
CROSS join cc_info_simplex_user ccisu
CROSS JOIN total_simplex_approved_amount tsa 
CROSS JOIN lang_country_match lcm
CROSS JOIN parsed_user_agent pua
CROSS JOIN total_partner_deposits tpd
CROSS JOIN KYC                              
LEFT JOIN proc_requests_view prv            on (prv.payment_id = a.id and prv.request_id = a.authorization_request_id )
LEFT JOIN WP_data wpd                       on (a.validation_request_body #>> '{email}' = wpd.email)
LEFT JOIN simplex_end_users b               ON a.simplex_end_user_id = b.id
left JOIN partner_end_users c               ON a.partner_end_user_id = c.id
LEFT JOIN ea_attributes ea                  ON a.validation_request_body #>> '{email}' = ea.email
CROSS JOIN payment_info d
LEFT JOIN disposable_email_domains dis      ON lower((SUBSTRING(b.email FROM (POSITION('@' IN b.email) +1)))) = dis.dis_domain
LEFT JOIN partners                          ON c.partner_id = partners.id
LEFT JOIN radar_proxy_detection rpd         ON rpd.payment_id = a.payment_id
LEFT JOIN phone_country_code_mismatch pccm  ON pccm.simplex_end_user_id = a.simplex_end_user_id
LEFT JOIN user_form_attempts ufa            ON a.id = ufa.id
LEFT JOIN WP_payment_phone_match wp_ppm     ON wp_ppm.payment_id = a.id
LEFT join verification_requests  vr         ON (a.id=vr.payment_id)
-- **************
WHERE a.id=payment.id
-- **************
)

------------------------   PAYMENT DATA SET --> FINAL DATA SET ----------------------------------------

-- never allow for bender to run in real time on payments where selfie has been sent 

,eligible_payment /* on commit drop */ as(
select min (is_eligible) is_eligible from (
select
case when
pd.payment_id <=69
or pd.email LIKE '%simplexcc.com'
-- ***********
-- this is supposedly not needed now because any selfie rrequest will have a line in verification_requests --> will be "not eligible"
--or (LOWER ((c.text_data)) LIKE ANY(ARRAY['%random charge%', '%selfie%']) and status=1)
-- ***********
or LOWER ((c.text_data)) LIKE ANY(ARRAY['test%','% test%','%declined by mistake%','%underage%'])
then 0 else 1 end as is_eligible
FROM payment_data_set pd
  left JOIN comments c               on (pd.payment_id= c.payment_id)
)z  
)

,cc_alerts /* on commit drop */
AS
(
-- MOVE FIRST LINE ONLY TO FINAL DATA SET!
SELECT case when sum (cc_status) > 0 then true else false end issuer_alert
             FROM (SELECT masked_credit_card credit_card,
             case when lower(status_description) like '%stolen%'
                    or lower(status_description) like '%fraud%'
                    or lower(status_description) like '%manipulation%'          
                    or lower(status_description) like '%lost%'
                    or lower(status_description) like '%banned card%'
                    or lower(status_description) like '%manual investigation required%'         
                    or lower(status_description) like '%max fraudscore exceeded%'
                    or lower(status_description) like '%pickup%'                    
             then 1 else 0 end cc_status
            FROM proc_requests_view prv
            left join payments p on (prv.payment_id = p.id)
            -- &&&&&&&&&&&&&&&&&&&
            WHERE prv.created_at < sim_time   
            -- &&&&&&&&&&&&&&&&&&&
            and p.validation_request_body #>> '{email}' in (
            select p.validation_request_body #>> '{email}' from proc_requests_view prv
            left join payments p on (prv.payment_id = p.id)            
            -- &&&&&&&&&&&&&&&&&&&
            WHERE prv.created_at < sim_time
            -- &&&&&&&&&&&&&&&&&&&
            and masked_credit_card in
            (select unnest(cards) from payment_data_set) )
) x
)

,shared_elements  /* on commit drop */
as (
select
      max (case when zz.element_type='ip'          then zz.num else null end) ip_num_users,
      max (case when zz.element_type='address'     then zz.num else null end) ad_num_users,
      max (case when zz.element_type='cookie'      then zz.num else null end) cookie_num_users,
      max (case when zz.element_type='btc_address' then zz.num else null end) btc_address_num_users
--          case when sh.element_type='bin'         then sh.num end bin_num_users,

from (

select distinct element_type , count(distinct partner_end_user_id) num
--  case when element_type = 'ip'     then count(distinct partner_end_user_id) end num_ip_users
from (
select p.partner_end_user_id, 'cookie' element_type from payments p
cross join payment_data_set pd
 where simplex_login->> 'uaid' = pd.cookie
-- $$$$$$$$$$$
and  p.created_at < sim_time
-- $$$$$$$$$$$      
UNION ALL 
select pl.partner_end_user_id, 'cookie' element_type from payments_log pl
cross join payment_data_set pd
 where simplex_login->> 'uaid' = pd.cookie 
-- $$$$$$$$$$$
and  pl.created_at < sim_time
-- $$$$$$$$$$$      
UNION ALL 
select p.partner_end_user_id,  'ip' element_type  from payments p
cross join payment_data_set pd
 where simplex_login->> 'ip' <> '' and simplex_login->> 'ip' = pd.ip
-- $$$$$$$$$$$
and  p.created_at < sim_time
-- $$$$$$$$$$$      
UNION ALL 
select pl.partner_end_user_id, 'ip' element_type  from payments_log pl
cross join payment_data_set pd
where simplex_login->> 'ip' <> '' and simplex_login->> 'ip' = pd.ip
-- $$$$$$$$$$$
and  pl.created_at < sim_time
-- $$$$$$$$$$$      
UNION ALL 
select p.partner_end_user_id, 'address' element_type  from payments p
cross join payment_data_set pd
where lower(p.address1 || ' ' || p.city || ' ' || p.country || ' ' || p.zipcode) = pd.address
-- $$$$$$$$$$$
and  p.created_at < sim_time
-- $$$$$$$$$$$      
UNION ALL 
select pl.partner_end_user_id, 'address' element_type  from payments_log pl
cross join payment_data_set pd
where lower(pl.address1 || ' ' || pl.city || ' ' || pl.country || ' ' || pl.zipcode) = pd.address
-- $$$$$$$$$$$
and  pl.created_at < sim_time
-- $$$$$$$$$$$      
UNION ALL 
select p.partner_end_user_id, 'btc_address' element_type  from payments p
cross join payment_data_set pd
 where p.btc_address = pd.btc_address
-- $$$$$$$$$$$
and  p.created_at < sim_time
-- $$$$$$$$$$$      
UNION ALL 
select pl.partner_end_user_id, 'btc_address' element_type  from payments_log pl
cross join payment_data_set pd
 where pl.btc_address = pd.btc_address
-- $$$$$$$$$$$
and  pl.created_at < sim_time
-- $$$$$$$$$$$      
/*
-- PD.BIN DOES NOT EXIST AT THE MOMENT
select p.partner_end_user_id, 'bin' element_type  from payments p
cross join payment_data_set pd
 where left(credit_card,6) bin = pd.bin
UNION
select p.partner_end_user_id, 'bin' element_type  from payments p
cross join payment_data_set pd
 where left(credit_card,6) bin = pd.bin
*/
) b group by 1
)zz
)

,email_name_match  /* on commit drop */
as (
select
greatest(aa.first_match,aa.last_match,aa.full_match,aa.ea_full_match,aa.ea_first_match,aa.ea_last_match,aa.first_dom_match,aa.last_dom_match,aa.full_dom_match) email_name_match_score
 from (
select
--regexp_replace(SUBSTRING(email FROM 1 FOR (POSITION('@' IN email) -1)), '[^a-zA-Z]+', '','g')    ,
similarity(regexp_replace(SUBSTRING(email FROM 1 FOR (POSITION('@' IN email) -1)), '[^a-zA-Z]+', '','g'),replace(first_name,' ','')) first_match,
similarity(regexp_replace(SUBSTRING(email FROM 1 FOR (POSITION('@' IN email) -1)), '[^a-zA-Z]+', '','g'),replace(last_name,' ','')) last_match,
similarity(regexp_replace(SUBSTRING(email FROM 1 FOR (POSITION('@' IN email) -1)), '[^a-zA-Z]+', '','g'),replace(first_name || last_name,' ','')) full_match,
similarity(replace(first_name || last_name,' ',''),replace(ea_name,' ','')) ea_full_match,
similarity(replace(first_name,' ',''),replace(ea_name,' ','')) ea_first_match,
similarity(replace(last_name,' ',''),replace(ea_name,' ','')) ea_last_match,
similarity(regexp_replace(SUBSTRING(email FROM (POSITION('@' IN email) +1)), '[^a-zA-Z]+', '','g'),replace(first_name,' ','')) first_dom_match,
similarity(regexp_replace(SUBSTRING(email FROM (POSITION('@' IN email) +1)), '[^a-zA-Z]+', '','g'),replace(last_name,' ','')) last_dom_match,
similarity(regexp_replace(SUBSTRING(email FROM (POSITION('@' IN email) +1)), '[^a-zA-Z]+', '','g'),replace(first_name || last_name,' ','')) full_dom_match
from payment_data_set) aa)

-- ******************** PAYMENT_ID *******************************

,verified_phone /* on commit drop */
AS
(
select coalesce (max(case when verified_at is null then 0 else 1 end), 0) verified_phone
from phone_verifications pv
left join payments p on (p.id = pv.payment_id)
-- ***********                     
WHERE p.partner_end_user_id= payment.partner_end_user_id
-- ***********
)

-- ******************** CREDIT_CARD *******************************

,cc_info_credit_card /* on commit drop */
AS
(
SELECT count(distinct x.email) cc_num_users
      FROM (SELECT validation_request_body #>> '{email}' email
            FROM payments p2
-- ******************
            WHERE credit_card = payment.credit_card
-- ******************
            UNION ALL
            SELECT validation_request_body #>> '{email}' email
            FROM payments_log pl
-- ******************
            WHERE credit_card = payment.credit_card
-- ******************
            UNION ALL
            SELECT validation_request_body #>> '{email}' email
            FROM payments_log pl
-- ******************
            WHERE (validation_request_body ->> 'credit_card') = payment.credit_card
-- ******************
            UNION ALL
            SELECT p.validation_request_body #>> '{email}'
            FROM proc_requests_view prv
            left join payments p on (prv.payment_id = p.id)
-- ******************
            WHERE masked_credit_card = payment.credit_card
-- ******************
) x
)

-- ******************** SIMPLEX_END_USER_ID *******************************

, verifications_info
AS
(         SELECT distinct credit_card, max(verification_time)  over (partition by credit_card) max_verification_time
          from (
          select credit_card, handling_at verification_time
          FROM payments p right join decisions d on (p.id= d.payment_id)
          WHERE reason in ('Verified', 'verified by bender')
          AND d.created_at  < sim_time 
          AND   batch_id IS NULL
          -- ***************
          AND  simplex_end_user_id = payment.simplex_end_user_id
          -- ***************
          UNION ALL
          SELECT vh.credit_card,   handling_at verification_time -- MUST CHANGE
          FROM verifications_history vh 
          left join payments p on
          (p.credit_card = vh.credit_card)
          -- ***************
          WHERE vh.simplex_end_user_id = payment.simplex_end_user_id
          -- ***************
          AND handling_at  < sim_time 
          UNION ALL
          -- verification might happen after the payment was declined, in that case the verification will appear in comments, not in decision
          SELECT credit_card, c.updated_at verification_time
          from payments p join comments c
          ON c.payment_id = p.id 
          WHERE text_data LIKE '%verified\_card%' 
          -- ***************
          AND simplex_end_user_id = payment.simplex_end_user_id   
          -- ***************
          AND c.updated_at  < sim_time
          )z
          group by credit_card, verification_time
)

,verifications /* on commit drop */
AS
(
select verified_cards,
       case when array_length(verified_cards, 1) > 0 then true else false end verified_user from (
          SELECT array_agg (distinct credit_card) verified_cards
          from verifications_info
)z
)

,users_history /* on commit drop */
AS
(
SELECT coalesce (SUM(CASE WHEN status = 2 THEN 1 ELSE 0 END), 0)  num_approves,
       coalesce (SUM(CASE WHEN status = 11 THEN 1 ELSE 0 END), 0)  num_declines,
       coalesce (SUM(CASE WHEN status = 16 THEN 1 ELSE 0 END), 0)  num_cancelations
      FROM payments p LEFT JOIN (SELECT payment_id, lower(STRING_AGG(REPLACE(text_data,E'\n',' '),',')) text_data FROM comments GROUP BY payment_id) c ON p.id = c.payment_id 
            WHERE text_data NOT LIKE '%declined due to technical errors%' 
-- **********************            
            AND simplex_end_user_id = payment.simplex_end_user_id
-- **********************      
            and  p.handling_at < sim_time

)

-- ******************** SIMPLEX_END_USER_ID & PARTNER_END_USER_ID *******************************

,user_phones /* on commit drop */
AS
(
select count(distinct phone) num_user_phones
--FORMERLY: from phone_info
from
(
SELECT phone
FROM (SELECT    RIGHT (SUBSTRING(phone FROM '[0-9]+'),9) phone
--             'simplex' source
      FROM simplex_end_users
      -- ***********
      where id=payment.simplex_end_user_id
      and updated_at < sim_time
      -- ***************
      UNION ALL
      SELECT   RIGHT (SUBSTRING(phone FROM '[0-9]+'),9) phone
--             'simplex_log' source
      FROM simplex_end_users_log
      -- ***********
      where current_simplex_user_id=payment.simplex_end_user_id
      and updated_at < sim_time
      -- ***************
      UNION ALL
      SELECT   RIGHT (SUBSTRING(phone FROM '[0-9]+'),9) phone
--             'partner' source
      FROM partner_end_users peu
      -- ***********
      where id=payment.partner_end_user_id
      and updated_at < sim_time
      -- ***************
      AND   phone IS NOT NULL
      UNION ALL
      SELECT RIGHT (SUBSTRING((api_requests -> 'nexmo' -> 'request_data' ->> 'number') FROM '[0-9]+'),9) phone
--             'browser_events' source
      FROM user_browser_events ube
        JOIN payments p ON (p.id = ube.payment_id)
      -- ***********
      where simplex_end_user_id=payment.simplex_end_user_id
      and inserted_at < sim_time
      -- ***************
      AND (api_requests -> 'nexmo' -> 'request_data' ->> 'number')::text != ''
            ) z
WHERE char_length (phone) > 3
and phone is not null
-- sometimes only 2-3 nums of country appear
)z
 )

-- ******************** EMAIL *******************************

,override /* on commit drop */ as (
select max(case when lower (text_data) LIKE ANY(ARRAY['%override bender%']) then 1 else 0 end) override
FROM payments p
  join comments c on (p.id=c.payment_id)
where 
-- **********************
p.validation_request_body #>> '{email}' = payment.validation_request_body #>> '{email}'
-- **********************
)

,user_min_decision /* on commit drop */
AS
(SELECT simplex_end_user_id,
       MIN(decision_score) user_min_decision
FROM (SELECT *,
             CASE
               WHEN decision = 'declined' AND (strength = 'Strong' OR application_name = 'Bender_Auto_Decide') THEN 1
               WHEN decision = 'approved' AND (strength = 'Strong' OR application_name = 'Bender_Auto_Decide') THEN 4
               WHEN decision = 'declined' AND strength = 'Weak' THEN 2
               WHEN decision = 'approved' AND strength = 'Weak' THEN 3

-- important: see that logic does not conflict with this default value
               else 0
             END AS decision_score
      FROM (SELECT p.simplex_end_user_id, application_name,
--                   d.payment_id,
                   d.created_at,
                   d.decision decision,
                   d.variables #>> '{strength}' strength
            --d.reason 
            FROM decisions d
              LEFT JOIN payments p ON p.id = d.payment_id
              LEFT JOIN (SELECT payment_id, lower(STRING_AGG(REPLACE(text_data,E'\n',' '),',')) text_data FROM comments GROUP BY payment_id) c ON p.id = c.payment_id 
             WHERE (application_name = 'Manual' or (application_name = 'Bender_Auto_Decide' and decision in ('declined', 'approved')))
            AND   text_data NOT LIKE '%declined due to technical errors%' 
-- **********************
            AND simplex_end_user_id=payment.simplex_end_user_id
            AND p.id<>payment.id -- not current payment
-- **********************            
and d.created_at < sim_time
) a) b
GROUP BY 1
)

,user_cc_last_decision /* on commit drop */
AS
(SELECT simplex_end_user_id,
 reason last_decision --('Didn't Respond to Verification', 'Refused Verification')
 FROM 
(SELECT d.payment_id, d.created_at,reason,simplex_end_user_id,
       max(d.created_at) over (partition by simplex_end_user_id) max_created_at
FROM decisions d
  LEFT JOIN payments p ON p.id = d.payment_id
LEFT JOIN (SELECT payment_id, lower(STRING_AGG(REPLACE(text_data,E'\n',' '),',')) text_data FROM comments GROUP BY payment_id) c ON p.id = c.payment_id 
            WHERE (application_name = 'Manual' or (application_name = 'Bender_Auto_Decide' and decision in ('declined', 'approved')))
            AND   text_data NOT LIKE '%declined due to technical errors%' 
-- **********************
and simplex_end_user_id = payment.simplex_end_user_id
and credit_card = payment.credit_card
-- **********************
-- $$$$$$$$$$$$$$$$$$$$$$
and d.created_at < sim_time
-- $$$$$$$$$$$$$$$$$$$$$$
--p.id<>payment.id -- not current payment
) a where created_at = max_created_at
-- $$$$$$$$$$$$$$$$$$$$$$
--    and   max_created_at < sim_time
-- $$$$$$$$$$$$$$$$$$$$$$
)

----------------------------------------------
-- number of pending user payments 
, user_pending_payments /* on commit drop */
AS (
select count(id) num from payments
-- ********************** 
where simplex_end_user_id = payment.simplex_end_user_id
and created_at < sim_time
-- in no case count this payment as another(!) peding one
and id != payment.id
-- taking care of run_time / simulation:
and (
  status=1 
  or status=8 
  or (handling_at > sim_time) 
  )
-- **********************
)
--number of pending user + cc payments
, user_cc_pending_payments /* on commit drop */
AS (
select count(id) num from payments
-- ********************** 
where simplex_end_user_id = payment.simplex_end_user_id
and credit_card = payment.credit_card
and created_at < sim_time
-- in no case count this payment as another(!) peding one
and id != payment.id
-- taking care of run_time / simulation:
and (status=1 or status=8 or (handling_at >sim_time) )
)
----------------------------------------------
-- count number of times user + card 'Didn't Respond to Verification' or 'Refused Verification'
,user_cc_num_refused_verification /* on commit drop */
AS
(SELECT count(distinct(p.id)) num_verification_refused
FROM decisions d
  LEFT JOIN payments p ON p.id = d.payment_id
  LEFT JOIN verifications_info vi ON p.credit_card = vi.credit_card
WHERE (application_name in ('Manual', 'EndUser') or (application_name = 'Bender_Auto_Decide' and decision in ('declined', 'approved')))
-- **********************
and simplex_end_user_id = payment.simplex_end_user_id 
and p.credit_card = payment.credit_card
--and vi.credit_card = payment.credit_card
-- **********************  
and (reason like  'Didn%t Respond to Verification'  or reason in ('Refused Verification' , 'Unable to Verify', 'User asked'))
and d.created_at < sim_time                                
-- counting verification tries only since last verification of this card
and d.created_at > coalesce (max_verification_time, date '2000-01-01')
)

, user_manually_verified -- skipping "verifications_history" table
AS
(SELECT count(p.id) num_manual_verifications
FROM decisions d
  JOIN payments p ON (d.payment_id = p.id)
WHERE application_name = 'Manual'
AND   reason = 'Verified'
-- *****************
AND   validation_request_body #>> '{email}' = payment.validation_request_body #>> '{email}'
AND   d.created_at < sim_time
-- *****************
)

, threeds_info
AS
(
SELECT threeds_enrolled,
             threeds_status
      FROM proc_requests_view
      WHERE payment_id = payment.id
      AND request_id = payment.authorization_request_id
)
--------------------------------------------------------

--------------------------------------------------------------------------------------------------
-- Variables: final_data_set ---------------------------------------------------------------------
--------------------------------------------------------------------------------------------------
,final_data_set  /* on commit drop */
as (
SELECT  pd.payment_id id,
       --pd.status,
       --pd.total_amount_usd,
       --pd.mm_binmatch,
       --pd.country,
       --pd.ip_country,
       --pd.bin_country,
       CASE
         WHEN pd.mm_proxyscore > 0 or
         pd.mm_anonymousproxy = 'Yes' or
         pd.blocked='YES' THEN 1
         ELSE 0
       END is_proxy_external,
       -- RADAR --
       --radar_diff,
       CASE WHEN radar_diff>25 THEN 1
       ELSE 0
       END is_proxy_radar,
    -- total proxy indicator
    CASE WHEN pd.mm_proxyscore > 0 or pd.mm_anonymousproxy = 'Yes' or pd.blocked='YES' or radar_diff>25 then true else false end is_proxy,
CASE WHEN pd.mm_ip_usertype in ('school','traveler','college') then 'other' else pd.mm_ip_usertype END mm_ip_user_type,
case
       when processor = 'compayments' then -- COMPAYMENTS
                CASE 
                when pd.avs_code is null then 'not_valid'
                WHEN pd.avs_code = 'F' then 'full_match' 
                when pd.avs_code = 'P' then 'partial_match' 
                when pd.avs_code = 'N' then 'no_match' 
                when pd.avs_code = 'U' then 'not_valid'
                end
       when processor = 'secure_trading' then
            case
            when     (pd.avs_address is null or pd.avs_address ='')
                 and (pd.avs_zipcode is null or pd.avs_zipcode ='') then 'not_valid'            
            when (pd.avs_address) in ('0', '1') and pd.avs_zipcode in ('0', '1') then 'not_valid'
            when (pd.avs_address) = '2' and pd.avs_zipcode = '2' then 'full_match'
            when (pd.avs_address) = '2' or  pd.avs_zipcode = '2' then 'partial_match'           
            when (pd.avs_address) = '4' and pd.avs_zipcode = '4' then 'no_match'                        
--            when pd.avs_address in ('0', '1') and pd.avs_zipcode in ('0', '1') then 'partial_match'           
            end
      end avs_match,    
   
CASE     WHEN pd.mm_match_type = 'zip' AND pd.mm_distance <= 5 THEN 'super_close'
         WHEN pd.mm_match_type IN ('zip','city') AND pd.mm_distance <= 30 THEN 'close'
         WHEN pd.mm_match_type IN ('zip','city') AND pd.mm_distance <= 100 THEN 'in_area'
         WHEN pd.mm_countryMatch = 'Yes' THEN 'country'
         ELSE 'no_match'
       END AS ip_ad_match,
CASE     WHEN pd.email similar TO '%@%(gov|edu|mil|org).%' THEN 'ctrld'
         WHEN lower(pd.mm_carderemail) LIKE 'yes' THEN 'carder'
         WHEN lower(pd.mm_freemail) LIKE 'yes' THEN 'free'
         ELSE 'none'
       END AS email_type,
case when name_on_card_match = 'no_match' then true else false end name_on_card_mismatch,
case when uh.num_approves > 0 then 1 else 0 end approved_user,
case when uh.num_declines > 0 then 1 else 0 end declined_user,
uh.num_cancelations,

umd.user_min_decision,
uld.last_decision,
-- presently not differntiating btw cancelation and refusal / cannot send etc...
urv.num_verification_refused,
upp.num   user_pending_payments,
ucpp.num  user_cc_pending_payments,
up.num_user_phones,
ovr.override, 
cca.issuer_alert is_issuer_alert,     
cicc.cc_num_users,      
vp.verified_phone,      
ep.is_eligible,
em.email_name_match_score,
      --ea_smfriends,

       ---***---***---***---***---***---      
--        CASE
--          WHEN lower(first_name || ' ' || last_name) = lower(first_name_card || ' ' || last_name_card) THEN 'full_match'
--          WHEN similarity (lower(first_name || ' ' || last_name),lower(first_name_card || ' ' || last_name_card)) >= 0.2 THEN 'partial_match'
--          ELSE 'no_match'
--        END name_on_card_match,
       --name_on_card_match,
       ---***---***---***---***---***---
       --identity_KYC,
      --address_KYC,
       --two_fa_enabled,
       --ad_lang_match,
       --ip_lang_match,
/*       case when sum_past_partner_deposits=0 then 'none'
       when sum_past_partner_deposits>200 then 'medium'
       else 'high'
       end past_partner_deposits, */
       --user_agent_os,
       --is_first,

       --**--
--ea_reason_fraud,
--**--
case when pd.ea_age > 90 and em.email_name_match_score>0.5 then true else false end old_email_with_name_match,
case when pd.num_new_status_0_ccs > 1 then true else false end new_cards_since_last_payment,
sh.ip_num_users,
sh.ad_num_users,
sh.cookie_num_users,
sh.btc_address_num_users,
case when pd.credit_card like any (v.verified_cards) then true else false end verified_card, 
v.verified_user,
------------------------
case when umv.num_manual_verifications > 0 then true else false end user_manually_verified,
------------------------
ti.threeds_enrolled,
ti.threeds_status,
------------------------
-- case when v.max_verification_time > pin.last_payment_time then true else false end verified_after_last_payment (not correct as is becaause last_payment_time derives from "created_at" - not "handling_at" as required here
--------------------------------------------------------------------------------------
-- White Pages Indicators
case when wp_simplex_address_name = 'no_match' then true else false end                         wp_address_name_mismatch,
case when wp_simplex_address_name in ('full_match', 'partial_match') then true else false end   wp_address_name_match,
case when wp_simplex_phone_name = 'no_match' then true else false end                           wp_phone_name_mismatch,
case when wp_simplex_phone_name in ('full_match', 'partial_match') then true else false end     wp_phone_name_match,
case when wp_simplex_phone_address = 'no_match' then true else false end                        wp_phone_address_mismatch,
case when wp_simplex_phone_address in ('full_match', 'partial_match') then true else false end  wp_phone_address_match,
--------------------------------------------------------------------------------------
case when num_name_changes > 2 or  num_name_on_card_changes > 2 or num_address_changes > 3 then true else false end changes_in_user_info_on_form,
case when identity_KYC = 1 and  name_on_card_match <> 'no_match' and is_virtual_cc = false and bin_country = country then 1 else 0 end suitable_for_selfie,
case WHEN country IN   ('IR', 'KP', 'DZ', 'MM', 'AF', 'AO', 'BA', 'EC', 'GY', 'LA','PA', 'PG', 'SD', 'SY', 'UG', 'YE', 'LB', 'IQ')
     OR bin_country IN ('IR', 'KP', 'DZ', 'MM', 'AF', 'AO', 'BA', 'EC', 'GY', 'LA','PA', 'PG', 'SD', 'SY', 'UG', 'YE', 'LB', 'IQ')
     OR ip_country IN  ('IR', 'KP', 'DZ', 'MM', 'AF', 'AO', 'BA', 'EC', 'GY', 'LA','PA', 'PG', 'SD', 'SY', 'UG', 'YE', 'LB', 'IQ') THEN true else false end is_fatf, 
case when mm_riskscore>60 then true else false end high_maxmind_risk_score,                          
case WHEN country IN ('UA','RU','MX','SA') OR bin_country IN ('UA','RU','MX','SA') OR ip_country IN ('UA','RU','MX','SA') then 1 else 0 end is_risky_county,
case WHEN ea_reason_fraud = 1 OR ea_score>500 then true else false end emailage_alert,
case WHEN sh.cookie_num_users>1 OR sh.ip_num_users>1 OR sh.ad_num_users>1 OR cicc.cc_num_users>1 or sh.btc_address_num_users>1 then true else false end linked_to_another_user,

case when min_verification_request_time is not null then 1 else 0 end pending_verification

---***---***---***---***---***---
FROM payment_data_set pd
CROSS JOIN eligible_payment ep
CROSS JOIN users_history uh
CROSS JOIN user_phones up
CROSS JOIN override ovr
cross JOIN cc_alerts  cca
CROSS JOIN cc_info_credit_card cicc
CROSS JOIN verified_phone vp
cross join verifications v
CROSS JOIN shared_elements sh             
CROSS JOIN email_name_match em          
LEFT  JOIN user_min_decision umd        ON umd.simplex_end_user_id = pd.simplex_end_user_id -- KEEP IT LEFT JOIN BECAUSE MIN() returns a null response (and when we select simplex_end_user_id we just get nothing)
LEFT JOIN user_cc_last_decision uld     ON uld.simplex_end_user_id = pd.simplex_end_user_id -- KEEP IT LEFT JOIN BECAUSE MIN() returns a null response (and when we select simplex_end_user_id we just get nothing)
CROSS JOIN user_cc_num_refused_verification urv
CROSS JOIN user_cc_pending_payments         ucpp
CROSS JOIN user_pending_payments            upp  
cross join payment_info   pin
cross join user_manually_verified           umv
cross join threeds_info                     ti
)

-------------------------------------------------------------------------------------------------
-- Verifications --------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------
,verification_data_set  /* on commit drop */
as (
SELECT id id_tmp,
-- photo selfie 
CASE 
when suitable_for_selfie = 1 and user_min_decision = 4                  then true
when suitable_for_selfie = 1 and user_min_decision = 3                  then false
when is_first = 1 and suitable_for_selfie = 1 and total_amount_usd<=500 then true
else false end as photo_selfie,
-- video selfie 
CASE 
when suitable_for_selfie = 1 and user_min_decision = 4                  then  false
when suitable_for_selfie = 1 and user_min_decision = 3                  then true
when is_first = 1 and suitable_for_selfie = 1 and total_amount_usd>500  then true
else false end as video_selfie,
-- random charge
true as random_charge,
-- verification_format
CASE 
when is_first = 0 and verified_user = false and user_min_decision = 4                           then 'strong approve - first time verification'
when is_first = 0 and verified_user = false and user_min_decision = 3                           then 'weak approve - first time verification'
when is_first = 0 and verified_user = true and verified_card = false  then 'verified user - new card'
when is_first = 1                                                     then 'first payment'
else null 
end as verification_format
--
from final_data_set cross join payment_data_set
)

-------------------------------------------------------------------------------------------------
-- Rules -----------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------
,simplex_rules /* on commit drop */
AS (
--------------------------------------------------------------------------------------------------
SELECT id, status,
case
--------------------------------------------------------------------------------------------------
-- override bender
when override= 1      then 'manual - override bender'
-- not eligible
when is_eligible = 0  then 'not_eligible - not eligible for Bender'

--------------------------------------------------------------------------------------------------
-- decline - auto decline strong decline
when is_fatf = true                                then 'declined - fatf'
when is_issuer_alert = true and  approved_user = 0 then 'declined - issuer alert'
when mm_carderemail = 'Yes' and  approved_user = 0 then 'declined - carder email'

-- PENDING VERIFICATION
------------------------------------------
when pending_verification = 1 then 'manual - awaiting verification'
when num_cancelations > 3 and approved_user=0 then 'manual - too many cancelations'
-- FIRST_TIME_USERS - decline
------------------------------------------
when num_status_0_ccs >3 and is_first = 1 then 'declined - too many status 0 cards for 1st payment'
----------------------------------------------
-- returning - decline
------------------------------------------
-- returning + didn't respond to verification more than 3 times
when is_first = 0 and verified_card = false 
and (last_decision like 'Didn%t Respond to Verification' or  last_decision in ('Refused Verification', 'Verification Session Closed', 'Verification Timed Out', 'User asked')
or user_cc_pending_payments>=1) 
and num_verification_refused + user_cc_pending_payments > 3
  then 'declined - too many verification attempts - non-verified card'
/*
when is_first = 0 and verified_card = true
and (last_decision like 'Didn%t Respond to Verification' or  last_decision = 'Refused Verification' or user_cc_pending_payments>=1) 
and num_verification_try + user_cc_pending_payments >= 3
  then 'declined - over 3 verification attempts - formerly verified card'
*/

-- decline - recommend decline
when num_new_status_0_ccs > 0 and declined_user = 1   then 'recommend_decline - too many new status 0 cards and decline history'
when num_user_ccs > 4 and verified_user = false       then 'recommend_decline - too many cards and never verified'
when mm_riskscore > 69 and declined_user=0            then 'recommend_decline - high mm risk score' -- CHANGE SOMEHOW (
when changes_in_user_info_on_form = true              then 'recommend_decline - user changed details in form'
--------------------------------------------------------------------------------------------------
-- manual - even if verified
when linked_to_another_user = true  then 'manual - linking'
when num_user_phones > 2            then 'manual - too many phones'
when avs_match = 'no_match'         then 'manual - avs mismatch'
when num_new_status_0_ccs > 1       then 'manual - too many new status 0 ccs'
when emailage_alert = true          then 'manual - emailage alert'
when is_issuer_alert = true         then 'manual - approved user with issuer alert'
when mm_carderemail = 'Yes'         then 'manual - approved user with maxmind carder email'
--when num_user_ccs > 4               then 'manual - too many ccs'
--------------------------------------------------------------------------------------------------
-- this should be changed when verification process is more sophisticated (since user could have already sent us a selfie but has not been verified yet)
when user_pending_payments > 0      then 'manual - another pending payment'

------------------------------------
-- auto verification
----------------------------------
-- returning + strong approve + over limit 
when  (is_first = 0 and verified_card = false and user_min_decision = 4 and (total_amount_usd+total_approved_amount)>=1200)  
  then 'verify - returning strong over limit'
-- returning + weak approve + over limit
when    (is_first = 0 and verified_card = false and user_min_decision = 3 and (total_amount_usd+total_approved_amount)>=400) 
  then 'verify - returning weak over limit' 

-- returning with new card
-- returning + verified user + new card
when    (is_first = 0 and verified_user = true    and verified_card = false AND NOT(threeds_enrolled = 'Y' AND threeds_status = 'Y'))                         
  then 'verify - returning with new card'

-- returning + didn't respond to verification (decision or still pending)
when is_first = 0 --and verified_card = false 
and (last_decision like 'Didn%t Respond to Verification' or  last_decision in ('Refused Verification', 'Verification Session Closed', 'Verification Timed Out', 'User asked')
 or user_cc_pending_payments>=1 ) 
and num_verification_refused + user_cc_pending_payments < 4 -- support ticket
  then 'verify - did not respond'

-----------------------------------------------------
-- first time verification for new users 
-----------------------------------------------------
when is_first = 1 
-- not bad
and num_status_0_ccs < 2 and num_user_ccs <=2  and is_social_media = false
-- name_on_card_match in ('full_match', 'partial_match')
and
(
-- email is not good enough for approve:
(ea_age < 30 and email_name_match_score < 0.5)
-- phone not verified and something else is not right
or
(verified_phone = 0 and (avs_match = 'not_valid' or (is_proxy = true or ip_ad_match = 'country' or ip_ad_match = 'no_match')))
-- phone_country_mismatch = 1
or
(verified_phone = 1 and phone_country_mismatch = true)
-- wp mismatch and ip not good
or
(wp_simplex_address_name  = 'no_match' and wp_simplex_phone_address = 'no_match' and wp_simplex_phone_name = 'no_match' and (is_proxy = true or ip_ad_match = 'country' or ip_ad_match = 'no_match'))
--
)
then 'verify - first'


--------------------------------------------------------------------------------------------------
-- auto approve returning user
--------------------------------------------------------------------------------------------------

-- OVER LIMIT -> manual
-- returning, verified by bender + over limit - move to manual
when is_first = 0 and verified_user = true and verified_card = true and user_manually_verified = false and (total_amount_usd+total_approved_amount)>=1200 -- returning + verified BY BENDER + over limit
  then 'manual - verified by bender over limit'
-- returning, verified, over limit - move to manual
when is_first = 0 and verified_user = true and verified_card = true and (total_amount_usd+total_approved_amount)>=4000  -- returning + verified + over limit
  then 'manual - verified over limit' 

-- UNDER LIMIT -> auto approve
-- returning, verified by bender only (not manually) --> set lower limit (800)
when is_first = 0 and verified_user = true and verified_card = true and user_manually_verified = false and (total_amount_usd+total_approved_amount)<1200
  then 'approved - verified only by bender'
-- auto approve returning, verified, under limit
when is_first = 0 and verified_user = true and verified_card = true  and (total_amount_usd+total_approved_amount)<4000
  then 'approved - verified'

-- returning, were strong approve, under limit
when is_first = 0 and verified_card = false and user_min_decision = 4 and (total_amount_usd+total_approved_amount)<1200 -- and new_card = 0
  then 'approved - returning strong approve under limit'
-- returning, were weak approve, under limit
when is_first = 0 and verified_card = false and user_min_decision = 3 and (total_amount_usd+total_approved_amount)<400
  then 'approved - returning weak approve under limit'

--------------------------------------------------------------------------------------------------
-- auto approve new user
--------------------------------------------------------------------------------------------------

-- 3D - "Y + Y" -----
WHEN    is_first = 1
    AND ea_age > 120
    AND avs_match in  ( 'full_match', 'partial_match')
    AND email_type  != 'carder'
    AND ip_ad_match != 'no_match'
    AND threeds_enrolled = 'Y'
    AND threeds_status   = 'Y'
then 'approved - verified by bender'

-- ID match --
when is_first = 1
and total_amount_usd < 1200
and avs_match in ('full_match', 'partial_match')
and (
(verified_phone = 1 and
(wp_simplex_phone_address in ('full_match', 'partial_match')
or (wp_simplex_phone_name in ('full_match', 'partial_match') and wp_simplex_address_name in ('full_match', 'partial_match'))
or (wp_simplex_phone_name_on_card in ('full_match', 'partial_match') and wp_simplex_address_name_on_card in ('full_match', 'partial_match') ) ) )
or (email_name_match_score > 0.4 and ea_age > 90 and wp_simplex_address_name in ('full_match', 'partial_match'))
) then 'approved - ID match'
--------------------------------------------------------------------------------------------------
-- phone verification cycle
when is_first = 1
and name_on_card_match in ('full_match', 'partial_match')
and is_proxy=false
and verified_phone = 1 
and num_user_phones=1
and wp_simplex_phone_name in ('full_match', 'partial_match')
and ea_age > 90 
and email_name_match_score > 0.5
and ip_ad_match != 'no_match'
then 'approved - verified phone match'
-- address-ip cycle
when is_first = 1
and name_on_card_match in ('full_match', 'partial_match')
and avs_match in ('full_match', 'partial_match')
and is_proxy=false
and verified_phone  = 1 
and ea_age > 90 
and email_name_match_score > 0.5
and ip_ad_match in ('super_close', 'close','in_area') 
and wp_simplex_address_name in ('full_match', 'partial_match')
then 'approved - address ip match'
--------------------------------------------------------------------------------------------------


--------------------------------------------------------------------------------------------------
ELSE 'manual - none' 
END as rule_desc
FROM final_data_set 
CROSS JOIN payment_data_set
CROSS JOIN verification_data_set )

--------------------------------------------------------------------------------------------------
-- Bender execution ------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------
SELECT payment_pk payment_id,
      left(rule_desc, position('-' in rule_desc)-2)::decision_type AS decision,
      (variables::json->0)::varchar ::json variables,
      split_part(rule_desc, '-', 2) reason,
      'Analytic' AS application_name,
      '2.3.2' AS analytic_code_version,
      timezone('utc',NOW()) AS executed_at
INTO model_decision
FROM simplex_rules sr
  LEFT JOIN (
    SELECT var.id,
             json_agg(var.*) variables
             FROM (select a.*,b.*,c.*
             from final_data_set a
             join payment_data_set b
                         on a.id=b.payment_id
             join verification_data_set c 
                         on a.id=c.id_tmp
) var
             GROUP BY 1) var_agg ON sr.id = var_agg.id
-- where status in (1, 6)
where status >0
AND sr.id = payment_pk
;
-- END OF ANALYTIC CODE;
RETURN model_decision;
END;
$fun$;

