CREATE FUNCTION plus_one()
  RETURNS integer
LANGUAGE plpgsql
AS $$
DECLARE
  r integer;

BEGIN
r:=0;
r:=r+1;

RETURN r;

END;

$$;

