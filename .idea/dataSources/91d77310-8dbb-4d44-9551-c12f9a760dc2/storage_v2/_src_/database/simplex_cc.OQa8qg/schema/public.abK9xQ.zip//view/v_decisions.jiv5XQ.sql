CREATE VIEW v_decisions AS
  SELECT decisions.id,
    decisions.application_name,
    decisions.analytic_code_version,
    decisions.payment_id,
    decisions.executed_at,
    decisions.decision,
    decisions.variables,
    decisions.created_at,
    decisions.batch_id,
    decisions.reason,
    decisions.request_id,
    decisions.r_payment_id,
    decisions.reason_code
   FROM decisions
  WHERE (decisions.executed_at > (now() - '2 days'::interval));

