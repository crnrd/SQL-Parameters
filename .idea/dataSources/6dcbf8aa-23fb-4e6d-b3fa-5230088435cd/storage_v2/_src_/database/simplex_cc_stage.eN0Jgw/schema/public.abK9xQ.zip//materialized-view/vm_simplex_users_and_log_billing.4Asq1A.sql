CREATE MATERIALIZED VIEW vm_simplex_users_and_log_billing AS SELECT v_simplex_users_and_log_billing.id,
    v_simplex_users_and_log_billing.updated_at,
    v_simplex_users_and_log_billing.email,
    v_simplex_users_and_log_billing.first_name,
    v_simplex_users_and_log_billing.last_name,
    v_simplex_users_and_log_billing.phone,
    v_simplex_users_and_log_billing.address,
    v_simplex_users_and_log_billing.city,
    v_simplex_users_and_log_billing.state,
    v_simplex_users_and_log_billing.country,
    v_simplex_users_and_log_billing.zip
   FROM v_simplex_users_and_log_billing
  ORDER BY v_simplex_users_and_log_billing.id, v_simplex_users_and_log_billing.updated_at;

CREATE INDEX vm_simplex_users_and_log_billing_id_key
  ON vm_simplex_users_and_log_billing (id, updated_at);

