CREATE VIEW v_simplex_users_and_log_billing AS
  SELECT simplex_end_users.id,
    simplex_end_users.updated_at,
    simplex_end_users.email,
    simplex_end_users.first_name,
    simplex_end_users.last_name,
    simplex_end_users.phone,
    simplex_end_users.address,
    simplex_end_users.city,
    simplex_end_users.state,
    simplex_end_users.country,
    simplex_end_users.zip
   FROM simplex_end_users
UNION ALL
 SELECT simplex_end_users_log.current_simplex_user_id AS id,
    simplex_end_users_log.updated_at,
    simplex_end_users_log.email,
    simplex_end_users_log.first_name,
    simplex_end_users_log.last_name,
    simplex_end_users_log.phone,
    simplex_end_users_log.address,
    simplex_end_users_log.city,
    simplex_end_users_log.state,
    simplex_end_users_log.country,
    simplex_end_users_log.zip
   FROM simplex_end_users_log;

