CREATE MATERIALIZED VIEW vm_migration_by_seu AS SELECT v_migration_by_seu.id,
    v_migration_by_seu.status,
    v_migration_by_seu.updated_at,
    v_migration_by_seu.email,
    v_migration_by_seu.first_name,
    v_migration_by_seu.last_name,
    v_migration_by_seu.phone,
    v_migration_by_seu.address,
    v_migration_by_seu.city,
    v_migration_by_seu.state,
    v_migration_by_seu.country,
    v_migration_by_seu.zip,
    v_migration_by_seu.time_point,
    v_migration_by_seu.seu_id
   FROM v_migration_by_seu;

CREATE INDEX vm_migration_by_seu_id_key
  ON vm_migration_by_seu (id);

