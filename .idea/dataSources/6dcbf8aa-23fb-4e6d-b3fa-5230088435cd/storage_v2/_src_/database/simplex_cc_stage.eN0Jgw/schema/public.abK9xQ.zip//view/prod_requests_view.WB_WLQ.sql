CREATE VIEW prod_requests_view AS
  SELECT proc_requests.id,
    proc_requests.created_at,
    proc_requests.updated_at,
    proc_requests.payment_id,
    proc_requests.request_id,
    proc_requests.tx_type,
    proc_requests.processor,
    proc_requests.status,
    replace((proc_requests.raw_response ->> 'maskedpan'::text), '#'::text, '*'::text) AS masked_credit_card,
    ("substring"(((proc_requests.raw_response -> 'expirydate'::text))::text, 2, 2))::integer AS card_expiry_month,
    ("substring"(((proc_requests.raw_response -> 'expirydate'::text))::text, 5, 4))::integer AS card_expiry_year,
    (proc_requests.raw_response ->> 'status'::text) AS status_description,
    ( SELECT row_to_json(avs.*) AS row_to_json
           FROM ( SELECT (proc_requests.raw_response ->> 'securityresponseaddress'::text) AS avs_address,
                    (proc_requests.raw_response ->> 'securityresponsepostcode'::text) AS avs_zipcode) avs) AS avs_code,
    (proc_requests.raw_response ->> 'securityresponsesecuritycode'::text) AS csc_code
   FROM proc_requests
  WHERE (proc_requests.processor = 'secure_trading'::processor)
UNION ALL
 SELECT proc_requests.id,
    proc_requests.created_at,
    proc_requests.updated_at,
    proc_requests.payment_id,
    proc_requests.request_id,
    proc_requests.tx_type,
    proc_requests.processor,
    proc_requests.status,
    (proc_requests.raw_response ->> 'masked_account_number'::text) AS masked_credit_card,
    ((proc_requests.raw_response ->> 'expiration_year'::text))::integer AS card_expiry_month,
    ((proc_requests.raw_response ->> 'expiration_month'::text))::integer AS card_expiry_year,
    (proc_requests.raw_response ->> 'status_description_1'::text) AS status_description,
    ( SELECT row_to_json(t.*) AS row_to_json
           FROM ( SELECT (proc_requests.raw_response ->> 'avs_code'::text) AS avs_code) t) AS avs_code,
    (proc_requests.raw_response ->> 'csc_code'::text) AS csc_code
   FROM proc_requests
  WHERE (proc_requests.processor = 'compayments'::processor);

