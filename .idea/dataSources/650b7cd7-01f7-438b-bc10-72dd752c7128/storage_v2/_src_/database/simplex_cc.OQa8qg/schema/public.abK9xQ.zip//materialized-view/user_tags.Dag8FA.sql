CREATE MATERIALIZED VIEW user_tags AS SELECT user_tags_live.id,
    user_tags_live.partner_end_user_id,
    user_tags_live.tag_rule_id,
    user_tags_live.tagging_percentile,
    user_tags_live.created_at,
    user_tags_live.active,
    user_tags_live.activation_updated_at
   FROM user_tags_live;

CREATE UNIQUE INDEX user_tags_pk
  ON user_tags (id);

CREATE INDEX user_tags_partner_end_user_id_tag_rule_id_idx
  ON user_tags (partner_end_user_id, tag_rule_id);

