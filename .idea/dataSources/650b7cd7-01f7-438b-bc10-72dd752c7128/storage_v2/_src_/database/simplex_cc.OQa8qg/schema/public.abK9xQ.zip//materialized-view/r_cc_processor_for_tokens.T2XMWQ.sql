CREATE MATERIALIZED VIEW r_cc_processor_for_tokens AS SELECT r_cc_processor_for_tokens_live.id,
    r_cc_processor_for_tokens_live.name,
    r_cc_processor_for_tokens_live.partner_processor_id,
    r_cc_processor_for_tokens_live.partner_id,
    r_cc_processor_for_tokens_live.inserted_at
   FROM r_cc_processor_for_tokens_live;

CREATE UNIQUE INDEX r_cc_processor_for_tokens_pkey
  ON r_cc_processor_for_tokens (id);

CREATE UNIQUE INDEX r_cc_proc_tokens_part_proc_id_partner_id_idx
  ON r_cc_processor_for_tokens (partner_processor_id, partner_id);

