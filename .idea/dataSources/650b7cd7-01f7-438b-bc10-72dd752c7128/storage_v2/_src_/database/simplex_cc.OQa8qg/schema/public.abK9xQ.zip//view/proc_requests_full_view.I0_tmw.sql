CREATE VIEW proc_requests_full_view AS
  SELECT proc_requests.id,
    proc_requests.created_at,
    proc_requests.updated_at,
    proc_requests.payment_id,
    proc_requests.request_id,
    proc_requests.tx_type,
    proc_requests.processor,
    proc_requests.status,
    NULL::text AS status_code,
    NULL::text AS status_severity,
    (proc_requests.raw_response ->> 'status'::text) AS status_description,
    (proc_requests.raw_response ->> 'billingfirstname'::text) AS first_name,
    (proc_requests.raw_response ->> 'billinglastname'::text) AS last_name,
    proc_requests.masked_credit_card,
    (proc_requests.raw_response ->> 'securityresponsesecuritycode'::text) AS csc_code,
    ("substring"(((proc_requests.raw_response -> 'expirydate'::text))::text, 2, 2))::integer AS card_expiry_month,
    ("substring"(((proc_requests.raw_response -> 'expirydate'::text))::text, 5, 4))::integer AS card_expiry_year,
    (proc_requests.raw_response ->> 'billingstreet'::text) AS street1,
    ''::text AS street2,
    (proc_requests.raw_response ->> 'billingpostcode'::text) AS post_code,
    (proc_requests.raw_response ->> 'billingtown'::text) AS city,
    (proc_requests.raw_response ->> 'billingcountryiso2a'::text) AS country,
    ( SELECT row_to_json(avs.*) AS row_to_json
           FROM ( SELECT (proc_requests.raw_response ->> 'securityresponseaddress'::text) AS avs_address,
                    (proc_requests.raw_response ->> 'securityresponsepostcode'::text) AS avs_zipcode) avs) AS avs_code,
    (proc_requests.raw_response ->> 'billingtelephone'::text) AS phone,
    (proc_requests.raw_response ->> 'mainamount'::text) AS requested_amount,
    (proc_requests.raw_response ->> 'currencyiso3a'::text) AS requested_amount_currency,
    (proc_requests.raw_response ->> 'enrolled'::text) AS threeds_enrolled,
    (proc_requests.raw_response ->> 'status'::text) AS threeds_status,
    (proc_requests.raw_response ->> 'errorcode'::text) AS threeds_errorcode,
    (proc_requests.raw_response ->> 'eci'::text) AS threeds_eci
   FROM proc_requests
  WHERE (proc_requests.processor = 'secure_trading'::processor)
UNION ALL
 SELECT proc_requests.id,
    proc_requests.created_at,
    proc_requests.updated_at,
    proc_requests.payment_id,
    proc_requests.request_id,
    proc_requests.tx_type,
    proc_requests.processor,
    proc_requests.status,
        CASE
            WHEN (((proc_requests.raw_response #> '{statuses,status}'::text[]))::json IS NULL) THEN (proc_requests.raw_response ->> 'status_code_1'::text)
            ELSE (((proc_requests.raw_response #> '{statuses,status}'::text[]) -> 0) ->> 'code'::text)
        END AS status_code,
        CASE
            WHEN (((proc_requests.raw_response #> '{statuses,status}'::text[]))::json IS NULL) THEN (proc_requests.raw_response ->> 'status_severity_1'::text)
            ELSE (((proc_requests.raw_response #> '{statuses,status}'::text[]) -> 0) ->> 'severity'::text)
        END AS status_severity,
        CASE
            WHEN (((proc_requests.raw_response #> '{statuses,status}'::text[]))::json IS NULL) THEN (proc_requests.raw_response ->> 'status_description_1'::text)
            ELSE (((proc_requests.raw_response #> '{statuses,status}'::text[]) -> 0) ->> 'description'::text)
        END AS status_description,
        CASE
            WHEN (((proc_requests.raw_response #> '{statuses,status}'::text[]))::json IS NULL) THEN (proc_requests.raw_response ->> 'first_name'::text)
            ELSE ((proc_requests.raw_response -> 'account-holder'::text) ->> 'first-name'::text)
        END AS first_name,
        CASE
            WHEN (((proc_requests.raw_response #> '{statuses,status}'::text[]))::json IS NULL) THEN (proc_requests.raw_response ->> 'last_name'::text)
            ELSE ((proc_requests.raw_response -> 'account-holder'::text) ->> 'last-name'::text)
        END AS last_name,
    proc_requests.masked_credit_card,
        CASE
            WHEN (((proc_requests.raw_response #> '{statuses,status}'::text[]))::json IS NULL) THEN (proc_requests.raw_response ->> 'csc_code'::text)
            ELSE (proc_requests.raw_response ->> 'csc-code'::text)
        END AS csc_code,
        CASE
            WHEN (((proc_requests.raw_response #> '{statuses,status}'::text[]))::json IS NULL) THEN ((proc_requests.raw_response ->> 'expiration_month'::text))::integer
            ELSE ((proc_requests.raw_response #>> '{card,expiration-month}'::text[]))::integer
        END AS card_expiry_month,
        CASE
            WHEN (((proc_requests.raw_response #> '{statuses,status}'::text[]))::json IS NULL) THEN ((proc_requests.raw_response ->> 'expiration_year'::text))::integer
            ELSE ((proc_requests.raw_response #>> '{card,expiration-year}'::text[]))::integer
        END AS card_expiry_year,
        CASE
            WHEN (((proc_requests.raw_response #> '{statuses,status}'::text[]))::json IS NULL) THEN (proc_requests.raw_response ->> 'street1'::text)
            ELSE (((proc_requests.raw_response -> 'account-holder'::text) -> 'address'::text) ->> 'street1'::text)
        END AS street1,
        CASE
            WHEN (((proc_requests.raw_response #> '{statuses,status}'::text[]))::json IS NULL) THEN (proc_requests.raw_response ->> 'street2'::text)
            ELSE (((proc_requests.raw_response -> 'account-holder'::text) -> 'address'::text) ->> 'street2'::text)
        END AS street2,
        CASE
            WHEN (((proc_requests.raw_response #> '{statuses,status}'::text[]))::json IS NULL) THEN (proc_requests.raw_response ->> 'post_code'::text)
            ELSE (((proc_requests.raw_response -> 'account-holder'::text) -> 'address'::text) ->> 'postal-code'::text)
        END AS post_code,
        CASE
            WHEN (((proc_requests.raw_response #> '{statuses,status}'::text[]))::json IS NULL) THEN (proc_requests.raw_response ->> 'city'::text)
            ELSE (((proc_requests.raw_response -> 'account-holder'::text) -> 'address'::text) ->> 'city'::text)
        END AS city,
        CASE
            WHEN (((proc_requests.raw_response #> '{statuses,status}'::text[]))::json IS NULL) THEN (proc_requests.raw_response ->> 'country'::text)
            ELSE (((proc_requests.raw_response -> 'account-holder'::text) -> 'address'::text) ->> 'country'::text)
        END AS country,
        CASE
            WHEN (((proc_requests.raw_response #> '{statuses,status}'::text[]))::json IS NULL) THEN ( SELECT row_to_json(t.*) AS row_to_json
               FROM ( SELECT (proc_requests.raw_response ->> 'avs_code'::text) AS avs_code) t)
            ELSE ( SELECT row_to_json(t.*) AS row_to_json
               FROM ( SELECT (proc_requests.raw_response ->> 'avs-code'::text) AS avs_code) t)
        END AS avs_code,
        CASE
            WHEN (((proc_requests.raw_response #> '{statuses,status}'::text[]))::json IS NULL) THEN (proc_requests.raw_response ->> 'phone'::text)
            ELSE ((proc_requests.raw_response -> 'account-holder'::text) ->> 'phone'::text)
        END AS phone,
        CASE
            WHEN (((proc_requests.raw_response #> '{statuses,status}'::text[]))::json IS NULL) THEN (proc_requests.raw_response ->> 'requested_amount'::text)
            ELSE ((proc_requests.raw_response -> 'requested-amount'::text) ->> 'value'::text)
        END AS requested_amount,
        CASE
            WHEN (((proc_requests.raw_response #> '{statuses,status}'::text[]))::json IS NULL) THEN (proc_requests.raw_response ->> 'requested_amount_currency'::text)
            ELSE ((proc_requests.raw_response -> 'requested-amount'::text) ->> 'currency'::text)
        END AS requested_amount_currency,
    NULL::text AS threeds_enrolled,
    NULL::text AS threeds_status,
    NULL::text AS threeds_errorcode,
    NULL::text AS threeds_eci
   FROM proc_requests
  WHERE (proc_requests.processor = 'compayments'::processor);

