CREATE MATERIALIZED VIEW uploads AS SELECT uploads_live.id,
    uploads_live.filename,
    uploads_live.original_filename,
    uploads_live.inserted_at,
    uploads_live.simplex_end_user_id,
    uploads_live.http_session_id,
    uploads_live.verification_request_id,
    uploads_live.edited_at
   FROM uploads_live;

CREATE UNIQUE INDEX uploads_id_pk
  ON uploads (id);

