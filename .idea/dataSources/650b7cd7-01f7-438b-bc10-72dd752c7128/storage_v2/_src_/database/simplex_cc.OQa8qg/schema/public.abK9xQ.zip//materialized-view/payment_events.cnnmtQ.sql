CREATE MATERIALIZED VIEW payment_events AS SELECT payment_events_live.payment,
    payment_events_live.name,
    payment_events_live.created_at,
    payment_events_live.event_id,
    payment_events_live.partner_id,
    payment_events_live.id
   FROM payment_events_live;

CREATE UNIQUE INDEX payment_events_event_id
  ON payment_events (event_id);

CREATE UNIQUE INDEX payment_events_pk
  ON payment_events (id);

CREATE UNIQUE INDEX payment_events_pkey
  ON payment_events (id);

CREATE INDEX payment_events_partner_id_idx
  ON payment_events (partner_id);

