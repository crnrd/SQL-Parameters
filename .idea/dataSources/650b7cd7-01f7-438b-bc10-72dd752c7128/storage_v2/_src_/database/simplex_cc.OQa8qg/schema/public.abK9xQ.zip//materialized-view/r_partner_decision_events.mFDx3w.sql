CREATE MATERIALIZED VIEW r_partner_decision_events AS SELECT r_partner_decision_events_live.id,
    r_partner_decision_events_live.inserted_at,
    r_partner_decision_events_live.published_at,
    r_partner_decision_events_live.created_at,
    r_partner_decision_events_live.payment_id,
    r_partner_decision_events_live.partner_specific,
    r_partner_decision_events_live.decision
   FROM r_partner_decision_events_live;

CREATE UNIQUE INDEX r_partner_decision_events_pkey
  ON r_partner_decision_events (id);

CREATE INDEX r_partner_decision_events_payment_id_idx
  ON r_partner_decision_events (payment_id);

