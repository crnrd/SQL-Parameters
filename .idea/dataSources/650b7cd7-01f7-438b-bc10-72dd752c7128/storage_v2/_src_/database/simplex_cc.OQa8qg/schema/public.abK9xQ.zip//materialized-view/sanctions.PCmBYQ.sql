CREATE MATERIALIZED VIEW sanctions AS SELECT sanctions_live.id,
    sanctions_live.payment_id,
    sanctions_live.inserted_at,
    sanctions_live.request_data,
    sanctions_live.response_data,
    sanctions_live.passed
   FROM sanctions_live;

CREATE UNIQUE INDEX sanctions_pk
  ON sanctions (id);

