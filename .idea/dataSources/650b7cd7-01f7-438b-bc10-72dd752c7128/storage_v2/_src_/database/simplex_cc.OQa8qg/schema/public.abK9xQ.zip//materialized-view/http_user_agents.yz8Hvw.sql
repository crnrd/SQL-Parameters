CREATE MATERIALIZED VIEW http_user_agents AS SELECT http_user_agents_live.id,
    http_user_agents_live.user_agent
   FROM http_user_agents_live;

CREATE UNIQUE INDEX http_user_agents_id_pk
  ON http_user_agents (id);

CREATE UNIQUE INDEX http_user_agents_user_agent_idx
  ON http_user_agents (user_agent);

CREATE UNIQUE INDEX http_user_agents_user_agent_unique
  ON http_user_agents (user_agent);

