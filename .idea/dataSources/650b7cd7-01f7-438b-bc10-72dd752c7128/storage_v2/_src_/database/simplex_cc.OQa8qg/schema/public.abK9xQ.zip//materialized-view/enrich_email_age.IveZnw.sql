CREATE MATERIALIZED VIEW enrich_email_age AS SELECT enrich_email_age_live.id,
    enrich_email_age_live.email,
    enrich_email_age_live.ip,
    enrich_email_age_live.inserted_at,
    enrich_email_age_live.data
   FROM enrich_email_age_live;

CREATE UNIQUE INDEX email_age_pk
  ON enrich_email_age (id);

CREATE UNIQUE INDEX enrich_email_age_email_inserted_at_idx
  ON enrich_email_age (email, inserted_at);

CREATE INDEX enrich_email_age_lower_email_inserted_at_idx
  ON enrich_email_age (lower(email), inserted_at);

