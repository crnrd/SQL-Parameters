CREATE MATERIALIZED VIEW payment_events_log AS SELECT payment_events_log_live.id,
    payment_events_log_live.payment_id,
    payment_events_log_live.name,
    payment_events_log_live.created_at,
    payment_events_log_live.event_id,
    payment_events_log_live.partner_id,
    payment_events_log_live.consumed_at,
    payment_events_log_live.payment
   FROM payment_events_log_live;

CREATE UNIQUE INDEX payment_events_log_pk
  ON payment_events_log (id);

CREATE INDEX payment_events_log_payment_id_fk_idx
  ON payment_events_log (payment_id);

CREATE INDEX payment_events_log_event_id_idx
  ON payment_events_log (event_id);

CREATE INDEX payment_events_log_partner_id_fk_idx
  ON payment_events_log (partner_id);

