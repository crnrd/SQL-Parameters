CREATE MATERIALIZED VIEW proc_requests_raw AS SELECT proc_requests_raw_live.proc_request_id,
    proc_requests_raw_live.raw_request_json,
    proc_requests_raw_live.raw_request_xml
   FROM proc_requests_raw_live;

CREATE UNIQUE INDEX proc_requests_raw_pk
  ON proc_requests_raw (proc_request_id);

