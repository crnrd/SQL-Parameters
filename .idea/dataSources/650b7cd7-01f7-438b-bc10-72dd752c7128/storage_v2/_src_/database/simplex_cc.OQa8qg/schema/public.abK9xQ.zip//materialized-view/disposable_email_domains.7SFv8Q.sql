CREATE MATERIALIZED VIEW disposable_email_domains AS SELECT disposable_email_domains_live.id,
    disposable_email_domains_live.dis_domain
   FROM disposable_email_domains_live;

CREATE UNIQUE INDEX disposable_email_domains_id_pk
  ON disposable_email_domains (id);

CREATE INDEX disposable_email_domains_dis_domain_idx
  ON disposable_email_domains (dis_domain);

