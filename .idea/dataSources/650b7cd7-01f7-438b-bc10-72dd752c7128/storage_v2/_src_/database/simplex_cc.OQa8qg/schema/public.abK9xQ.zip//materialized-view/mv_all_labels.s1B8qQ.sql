CREATE MATERIALIZED VIEW mv_all_labels AS SELECT all_labels.payment_id,
    all_labels.r_payment_id,
    all_labels.first_decision,
    all_labels.last_decision,
    all_labels.last_state,
    all_labels.user_label,
    all_labels.user_master_label
   FROM ( SELECT DISTINCT ON (pfd.payment_id) pfd.payment_id,
            rp.id AS r_payment_id,
            pfd.payment_label AS first_decision,
            pld.payment_label AS last_decision,
            pls.payment_label AS last_state,
            ul.user_label,
            uml.user_master_label
           FROM ((((((mv_payment_first_decision_label pfd
             LEFT JOIN mv_payment_last_decision_label pld ON ((pld.payment_id = pfd.payment_id)))
             LEFT JOIN mv_payment_last_state_label pls ON ((pls.payment_id = pfd.payment_id)))
             LEFT JOIN payments p ON ((p.id = pfd.payment_id)))
             LEFT JOIN mv_user_label ul ON (((ul.email)::text = (p.email)::text)))
             LEFT JOIN mv_user_master_label uml ON (((uml.email)::text = (ul.email)::text)))
             LEFT JOIN r_payments rp ON ((rp.simplex_payment_id = pfd.payment_id)))) all_labels;

