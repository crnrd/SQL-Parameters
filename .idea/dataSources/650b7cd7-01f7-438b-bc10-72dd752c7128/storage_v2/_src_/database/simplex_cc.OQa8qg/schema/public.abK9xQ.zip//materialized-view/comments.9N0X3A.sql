CREATE MATERIALIZED VIEW comments AS SELECT comments_live.id,
    comments_live.text_data,
    comments_live.payment_id,
    comments_live.author_id,
    comments_live.created_at,
    comments_live.updated_at
   FROM comments_live;

CREATE UNIQUE INDEX comments_pkey
  ON comments (id);

CREATE UNIQUE INDEX comments_pkey_idx
  ON comments (id);

CREATE INDEX comments_payment_id_idx
  ON comments (payment_id);

CREATE INDEX comments_author_id_idx
  ON comments (author_id);

