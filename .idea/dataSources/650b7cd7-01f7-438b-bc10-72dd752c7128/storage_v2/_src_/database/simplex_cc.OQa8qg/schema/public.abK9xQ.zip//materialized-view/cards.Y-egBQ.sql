CREATE MATERIALIZED VIEW cards AS SELECT cards_live.id,
    cards_live.token,
    cards_live.cap_data,
    cards_live.created_at,
    cards_live.updated_at
   FROM cards_live;

CREATE UNIQUE INDEX credit_cards_id_idx
  ON cards (id);

CREATE UNIQUE INDEX credit_cards_id_primary_key
  ON cards (id);

CREATE UNIQUE INDEX credit_cards_token_idx
  ON cards (token);

CREATE UNIQUE INDEX credit_cards_token_key
  ON cards (token);

