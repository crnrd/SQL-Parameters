CREATE MATERIALIZED VIEW cc_identifiers AS SELECT cc_identifiers_live.id,
    cc_identifiers_live.credit_card,
    cc_identifiers_live.identifier
   FROM cc_identifiers_live;

CREATE UNIQUE INDEX cc_identifiers_pk
  ON cc_identifiers (id);

CREATE UNIQUE INDEX cc_identifiers_credit_card_key
  ON cc_identifiers (credit_card);

CREATE UNIQUE INDEX cc_identifiers_identifier_key
  ON cc_identifiers (identifier);

CREATE INDEX cc_identifiers_cc_idx
  ON cc_identifiers (credit_card);

CREATE INDEX cc_identifiers_uuid
  ON cc_identifiers (identifier);

