CREATE MATERIALIZED VIEW payments_log AS SELECT payments_log_live.id,
    payments_log_live.current_payment_id,
    payments_log_live.payment_id,
    payments_log_live.partner_end_user_id,
    payments_log_live.btc_address,
    payments_log_live.amount,
    payments_log_live.credit_card,
    payments_log_live.max_allowed_deposits,
    payments_log_live.created_at,
    payments_log_live.status,
    payments_log_live.maxmind,
    payments_log_live.balances,
    payments_log_live.partner_login,
    payments_log_live.simplex_login,
    payments_log_live.exchange_rates,
    payments_log_live.simplex_end_user_id,
    payments_log_live.clearance_id,
    payments_log_live.updated_at,
    payments_log_live.currency,
    payments_log_live.first_name_card,
    payments_log_live.last_name_card,
    payments_log_live.handling_user_id,
    payments_log_live.total_amount,
    payments_log_live.country,
    payments_log_live.state,
    payments_log_live.city,
    payments_log_live.address1,
    payments_log_live.address2,
    payments_log_live.zipcode,
    payments_log_live.authorization_request_id,
    payments_log_live.authorization_transaction_id,
    payments_log_live.handling_at,
    payments_log_live.card_id,
    payments_log_live.is_proc_status_called,
    payments_log_live.avs_code,
    payments_log_live.csc_code,
    payments_log_live.capture_request_id,
    payments_log_live.capture_transaction_id,
    payments_log_live.auth_transaction_status,
    payments_log_live.blocked,
    payments_log_live.order_id,
    payments_log_live.processor_cc_token_id,
    payments_log_live.is_tampering_attempt,
    payments_log_live.payment_request_body,
    payments_log_live.validation_request_body,
    payments_log_live.processor_auth_data,
    payments_log_live.capture_transaction_status,
    payments_log_live.processor_id,
    payments_log_live.completed_at,
    payments_log_live.fee,
    payments_log_live.user_reported_vcc,
    payments_log_live.user_comment,
    payments_log_live.card_expiry_year,
    payments_log_live.card_expiry_month,
    payments_log_live.quote_id,
    payments_log_live.pay_to_partner_id,
    payments_log_live.affiliate_fee,
    payments_log_live.original_http_ref_url,
    payments_log_live.email,
    payments_log_live.first_name,
    payments_log_live.last_name,
    payments_log_live.phone,
    payments_log_live.update_event,
    payments_log_live.update_event_inserted_at,
    payments_log_live.date_of_birth,
    payments_log_live.crypto_currency,
    payments_log_live.crypto_currency_address,
    payments_log_live.total_amount_usd,
    payments_log_live.usd_rate,
    payments_log_live.conversion_time,
    payments_log_live.cc_identifier,
    payments_log_live.cc_expiry_identifier,
    payments_log_live.bin
   FROM payments_log_live;

CREATE UNIQUE INDEX payment_log_pk
  ON payments_log (id);

CREATE UNIQUE INDEX payment_log_pk_uniq
  ON payments_log (id);

CREATE INDEX payments_log_lower_email_idx
  ON payments_log (lower(email :: TEXT));

CREATE INDEX payments_log_partner_login_ip_idx
  ON payments_log ((partner_login ->> 'ip' :: TEXT));

CREATE INDEX payments_log_validation_request_body_credit_card_idx
  ON payments_log ((validation_request_body ->> 'credit_card' :: TEXT));

CREATE INDEX payments_log_validation_request_body_email_idx
  ON payments_log ((validation_request_body ->> 'email' :: TEXT));

CREATE INDEX current_payment_id
  ON payments_log (current_payment_id);

CREATE INDEX payments_log_btc_address_idx
  ON payments_log (btc_address);

CREATE INDEX payments_log_credit_card_idx
  ON payments_log (credit_card);

CREATE INDEX payments_log_created_at_idx
  ON payments_log (created_at);

CREATE INDEX payments_log_simplex_end_user_id_idx
  ON payments_log (simplex_end_user_id);

CREATE INDEX payments_log_updated_at_idx
  ON payments_log (updated_at);

CREATE INDEX payments_log_email_idx
  ON payments_log (email);

CREATE INDEX payments_log_phone_idx
  ON payments_log (phone);

