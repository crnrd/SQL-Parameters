CREATE MATERIALIZED VIEW status_meaning AS SELECT status_meaning_live.code,
    status_meaning_live.description
   FROM status_meaning_live;

CREATE UNIQUE INDEX status_meaning_pk
  ON status_meaning (code);

