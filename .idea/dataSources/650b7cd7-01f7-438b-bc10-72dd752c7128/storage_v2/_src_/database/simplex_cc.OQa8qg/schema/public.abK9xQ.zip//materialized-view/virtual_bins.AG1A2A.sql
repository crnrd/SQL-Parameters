CREATE MATERIALIZED VIEW virtual_bins AS SELECT virtual_bins_live.bin
   FROM virtual_bins_live;

