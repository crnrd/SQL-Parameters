CREATE MATERIALIZED VIEW r_peu AS SELECT r_peu_live.id,
    r_peu_live.partner_id,
    r_peu_live.partner_generated_user_id,
    r_peu_live.inserted_at
   FROM r_peu_live;

CREATE UNIQUE INDEX r_peu_pkey
  ON r_peu (id);

CREATE UNIQUE INDEX r_peu_generated_user_id_peu_partner_id_idx
  ON r_peu (partner_generated_user_id, partner_id);

