CREATE MATERIALIZED VIEW r_payments AS SELECT r_payments_live.id,
    r_payments_live.simplex_payment_id,
    r_payments_live.api_payment_uuid,
    r_payments_live.partner_order_id,
    r_payments_live.inserted_at,
    r_payments_live.created_at
   FROM r_payments_live;

CREATE UNIQUE INDEX r_payments_pkey
  ON r_payments (id);

CREATE UNIQUE INDEX r_payments_simplex_api_payment_uuid_idx
  ON r_payments (api_payment_uuid);

CREATE INDEX r_payments_simplex_payment_id_idx
  ON r_payments (simplex_payment_id);

CREATE INDEX r_payments_simplex_partner_order_id_idx
  ON r_payments (partner_order_id);

