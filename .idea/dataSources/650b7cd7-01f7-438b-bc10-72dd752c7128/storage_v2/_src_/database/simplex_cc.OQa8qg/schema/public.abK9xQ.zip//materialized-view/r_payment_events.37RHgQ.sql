CREATE MATERIALIZED VIEW r_payment_events AS SELECT r_payment_events_live.id,
    r_payment_events_live.payment_id,
    r_payment_events_live.event_type,
    r_payment_events_live.peu_id,
    r_payment_events_live.created_at,
    r_payment_events_live.inserted_at,
    r_payment_events_live.partner_session,
    r_payment_events_live.simplex_session,
    r_payment_events_live.amount_to_charge,
    r_payment_events_live.currency_to_charge,
    r_payment_events_live.first_name_cc_raw,
    r_payment_events_live.last_name_cc_raw,
    r_payment_events_live.country_raw,
    r_payment_events_live.state_raw,
    r_payment_events_live.city_raw,
    r_payment_events_live.address1_raw,
    r_payment_events_live.address2_raw,
    r_payment_events_live.zipcode_raw,
    r_payment_events_live.cc_auth_id,
    r_payment_events_live.card_token_id,
    r_payment_events_live.email_raw,
    r_payment_events_live.first_name_raw,
    r_payment_events_live.last_name_raw,
    r_payment_events_live.phone_raw,
    r_payment_events_live.year_of_birth,
    r_payment_events_live.partner_seller_id,
    r_payment_events_live.partner_specific,
    r_payment_events_live.cc_identifier,
    r_payment_events_live.cc_expiry_identifier,
    r_payment_events_live.bin
   FROM r_payment_events_live;

CREATE UNIQUE INDEX r_payment_events_pkey
  ON r_payment_events (id);

CREATE INDEX r_payment_events_lower_email_raw_idx
  ON r_payment_events (lower(email_raw :: TEXT));

CREATE INDEX r_payment_events_partner_session_ip_idx
  ON r_payment_events ((partner_session ->> 'ip' :: TEXT));

CREATE INDEX r_payment_events_simplex_session_ip_idx
  ON r_payment_events ((simplex_session ->> 'ip' :: TEXT));

CREATE INDEX r_payment_events_simplex_session_uaid_idx
  ON r_payment_events ((simplex_session ->> 'uaid' :: TEXT));

CREATE INDEX r_payment_events_payment_id_inserted_at_idx
  ON r_payment_events (payment_id, inserted_at);

CREATE INDEX r_payment_events_peu_id_idx
  ON r_payment_events (peu_id);

CREATE INDEX r_payment_events_created_at_idx
  ON r_payment_events (created_at);

CREATE INDEX r_payment_events_country_raw_state_raw_idx
  ON r_payment_events (country_raw, state_raw);

CREATE INDEX r_payment_events_cc_auth_id_idx
  ON r_payment_events (cc_auth_id);

CREATE INDEX r_payment_events_email_raw_idx
  ON r_payment_events (email_raw);

CREATE INDEX r_payment_events_phone_raw_idx
  ON r_payment_events (phone_raw);

CREATE INDEX r_payment_events_partner_seller_id_created_at_idx
  ON r_payment_events (partner_seller_id, created_at);

