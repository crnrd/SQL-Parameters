CREATE MATERIALIZED VIEW phone_verifications AS SELECT phone_verifications_live.id,
    phone_verifications_live.phone,
    phone_verifications_live.payment_id,
    phone_verifications_live.partner_end_user_id,
    phone_verifications_live.verification_request_id,
    phone_verifications_live.verified_at,
    phone_verifications_live.inserted_at,
    phone_verifications_live.api_request_data,
    phone_verifications_live.api_response_data,
    phone_verifications_live.is_current
   FROM phone_verifications_live;

CREATE UNIQUE INDEX phone_verifications_pk
  ON phone_verifications (id);

CREATE INDEX phone_verifications_phone_idx
  ON phone_verifications (phone);

CREATE INDEX phone_verifications_payment_id_inserted_at_idx
  ON phone_verifications (payment_id, inserted_at);

CREATE INDEX phone_verifications_partner_end_user_id_idx
  ON phone_verifications (partner_end_user_id);

