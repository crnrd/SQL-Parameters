CREATE MATERIALIZED VIEW kyc_extra_data AS SELECT kyc_extra_data_live.id,
    kyc_extra_data_live.simplex_end_user_id,
    kyc_extra_data_live.partner_end_user_id,
    kyc_extra_data_live.verification_request_id,
    kyc_extra_data_live.inserted_at,
    kyc_extra_data_live.user_data
   FROM kyc_extra_data_live;

CREATE UNIQUE INDEX kyc_identities_pk
  ON kyc_extra_data (id);

CREATE INDEX kyc_extra_data_inserted_at_idx
  ON kyc_extra_data (inserted_at);

