CREATE MATERIALIZED VIEW partners AS SELECT partners_live.id,
    partners_live.name,
    partners_live.created_at,
    partners_live.redirect_back_to,
    partners_live.service_type,
    partners_live.full_name,
    partners_live.min_amount,
    partners_live.max_amount,
    partners_live.support_email,
    partners_live.verification_request_email,
    partners_live.config,
    partners_live.policy,
    partners_live.updated_at
   FROM partners_live;

CREATE UNIQUE INDEX partners_pk
  ON partners (id);

CREATE UNIQUE INDEX partners_pk_idx
  ON partners (id);

CREATE UNIQUE INDEX partners_name_key
  ON partners (name);

