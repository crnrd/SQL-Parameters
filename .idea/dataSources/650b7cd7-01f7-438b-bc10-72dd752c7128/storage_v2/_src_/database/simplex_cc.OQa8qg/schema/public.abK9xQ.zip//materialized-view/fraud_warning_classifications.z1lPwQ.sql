CREATE MATERIALIZED VIEW fraud_warning_classifications AS SELECT fraud_warning_classifications_live.id,
    fraud_warning_classifications_live.inserted_at,
    fraud_warning_classifications_live.decider_user_id,
    fraud_warning_classifications_live.payment_id,
    fraud_warning_classifications_live.fraud_type
   FROM fraud_warning_classifications_live;

CREATE UNIQUE INDEX fraud_warning_classifications_pkey
  ON fraud_warning_classifications (id);

CREATE INDEX fraud_warning_classifications_payment_id_idx
  ON fraud_warning_classifications (payment_id);

