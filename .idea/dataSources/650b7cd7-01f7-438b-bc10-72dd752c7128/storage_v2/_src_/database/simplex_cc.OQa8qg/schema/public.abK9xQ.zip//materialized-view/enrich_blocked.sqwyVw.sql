CREATE MATERIALIZED VIEW enrich_blocked AS SELECT enrich_blocked_live.id,
    enrich_blocked_live.inserted_at,
    enrich_blocked_live.ip,
    enrich_blocked_live.response_data
   FROM enrich_blocked_live;

CREATE UNIQUE INDEX enrich_blocked_pkey
  ON enrich_blocked (id);

CREATE UNIQUE INDEX enrich_blocked_ip_inserted_at_idx
  ON enrich_blocked (ip, inserted_at);

