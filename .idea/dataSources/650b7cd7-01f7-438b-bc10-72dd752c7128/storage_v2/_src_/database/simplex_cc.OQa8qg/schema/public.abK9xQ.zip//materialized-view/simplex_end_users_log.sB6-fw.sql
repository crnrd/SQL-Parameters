CREATE MATERIALIZED VIEW simplex_end_users_log AS SELECT simplex_end_users_log_live.id,
    simplex_end_users_log_live.current_simplex_user_id,
    simplex_end_users_log_live.email,
    simplex_end_users_log_live.encrypted_password,
    simplex_end_users_log_live.first_name,
    simplex_end_users_log_live.last_name,
    simplex_end_users_log_live.address,
    simplex_end_users_log_live.city,
    simplex_end_users_log_live.state,
    simplex_end_users_log_live.country,
    simplex_end_users_log_live.zip,
    simplex_end_users_log_live.phone,
    simplex_end_users_log_live.created_at,
    simplex_end_users_log_live.updated_at,
    simplex_end_users_log_live.has_support_ticket,
    simplex_end_users_log_live.user_risk_status
   FROM simplex_end_users_log_live;

CREATE UNIQUE INDEX simplex_end_users_log_pk_idx
  ON simplex_end_users_log (id);

CREATE UNIQUE INDEX simplex_user_log_pk
  ON simplex_end_users_log (id);

CREATE INDEX simplex_end_users_log_lower_email_updated_at_idx
  ON simplex_end_users_log (lower(email :: TEXT), updated_at);

CREATE INDEX current_simplex_user_id
  ON simplex_end_users_log (current_simplex_user_id);

CREATE INDEX simplex_end_users_log_phone_idx
  ON simplex_end_users_log (phone);

