CREATE MATERIALIZED VIEW dss_queue_events AS SELECT dss_queue_events_live.id,
    dss_queue_events_live.event_name,
    dss_queue_events_live.user_id,
    dss_queue_events_live.details,
    dss_queue_events_live.inserted_at,
    dss_queue_events_live.payment_id
   FROM dss_queue_events_live;

CREATE UNIQUE INDEX dss_queue_events_id_pk
  ON dss_queue_events (id);

CREATE INDEX dss_queue_events_event_name_idx
  ON dss_queue_events (event_name);

CREATE INDEX fki_dss_queue_events_user_id_fk
  ON dss_queue_events (user_id);

CREATE INDEX fki_dss_queue_events_payment_id_fk
  ON dss_queue_events (payment_id);

