CREATE MATERIALIZED VIEW phone_country_codes AS SELECT phone_country_codes_live.phone_code,
    phone_country_codes_live.country_code
   FROM phone_country_codes_live;

