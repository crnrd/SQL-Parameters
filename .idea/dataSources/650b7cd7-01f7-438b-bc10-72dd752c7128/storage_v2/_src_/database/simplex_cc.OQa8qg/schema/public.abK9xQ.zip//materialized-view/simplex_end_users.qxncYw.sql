CREATE MATERIALIZED VIEW simplex_end_users AS SELECT simplex_end_users_live.id,
    simplex_end_users_live.email,
    simplex_end_users_live.encrypted_password,
    simplex_end_users_live.first_name,
    simplex_end_users_live.last_name,
    simplex_end_users_live.address,
    simplex_end_users_live.city,
    simplex_end_users_live.state,
    simplex_end_users_live.country,
    simplex_end_users_live.zip,
    simplex_end_users_live.phone,
    simplex_end_users_live.created_at,
    simplex_end_users_live.updated_at,
    simplex_end_users_live.has_support_ticket,
    simplex_end_users_live.user_risk_status
   FROM simplex_end_users_live;

CREATE UNIQUE INDEX simplex_end_users_pk_idx
  ON simplex_end_users (id);

CREATE UNIQUE INDEX simplex_user_pk
  ON simplex_end_users (id);

CREATE UNIQUE INDEX simplex_end_users_email_idx
  ON simplex_end_users (email);

CREATE UNIQUE INDEX simplex_end_users_email_key
  ON simplex_end_users (email);

CREATE INDEX simplex_end_users_lower_email_updated_at_idx
  ON simplex_end_users (lower(email :: TEXT), updated_at);

CREATE INDEX tsachi_simplex_end_users_lower_email_idx
  ON simplex_end_users (lower(email :: TEXT));

CREATE INDEX simplex_end_users_phone_idx
  ON simplex_end_users (phone);

