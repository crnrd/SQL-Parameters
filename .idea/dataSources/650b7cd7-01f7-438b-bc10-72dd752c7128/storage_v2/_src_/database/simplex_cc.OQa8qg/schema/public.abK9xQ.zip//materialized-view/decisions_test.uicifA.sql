CREATE MATERIALIZED VIEW decisions_test AS SELECT decisions_etl.id,
    decisions_etl.application_name,
    decisions_etl.analytic_code_version,
    decisions_etl.payment_id,
    decisions_etl.executed_at,
    decisions_etl.decision,
    decisions_etl.variables,
    decisions_etl.created_at,
    decisions_etl.batch_id,
    decisions_etl.reason,
    decisions_etl.request_id,
    decisions_etl.r_payment_id,
    decisions_etl.reason_code
   FROM decisions_etl;

