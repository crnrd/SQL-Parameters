CREATE MATERIALIZED VIEW processor_notification_events AS SELECT processor_notification_events_live.id,
    processor_notification_events_live.inserted_at,
    processor_notification_events_live.payment_id,
    processor_notification_events_live.proc_request_id,
    processor_notification_events_live.notification_response_data
   FROM processor_notification_events_live;

CREATE UNIQUE INDEX processor_notification_events_pk
  ON processor_notification_events (id);

CREATE INDEX processor_notification_events_payment_id_inserted_at_idx
  ON processor_notification_events (payment_id, inserted_at);

