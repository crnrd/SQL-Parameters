CREATE MATERIALIZED VIEW fraud_only_events_audit AS SELECT fraud_only_events_audit_live.id,
    fraud_only_events_audit_live.payment_uuid,
    fraud_only_events_audit_live.request,
    fraud_only_events_audit_live.response,
    fraud_only_events_audit_live.inserted_at,
    fraud_only_events_audit_live.updated_at,
    fraud_only_events_audit_live.partner_id
   FROM fraud_only_events_audit_live;

CREATE UNIQUE INDEX fraud_only_events_audit_pk
  ON fraud_only_events_audit (id);

CREATE INDEX fraud_only_events_audit_payment_uuid_partner_id_idx
  ON fraud_only_events_audit (payment_uuid, partner_id);

