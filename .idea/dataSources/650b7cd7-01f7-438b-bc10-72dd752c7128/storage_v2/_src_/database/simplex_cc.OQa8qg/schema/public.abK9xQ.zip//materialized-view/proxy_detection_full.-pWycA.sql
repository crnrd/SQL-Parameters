CREATE MATERIALIZED VIEW proxy_detection_full AS SELECT proxy_detection_full_live.id,
    proxy_detection_full_live.payment_id,
    proxy_detection_full_live.partner_end_user_id,
    proxy_detection_full_live.inserted_at,
    proxy_detection_full_live.data,
    proxy_detection_full_live.measurements_data
   FROM proxy_detection_full_live;

CREATE UNIQUE INDEX proxy_detection_full_pk
  ON proxy_detection_full (id);

