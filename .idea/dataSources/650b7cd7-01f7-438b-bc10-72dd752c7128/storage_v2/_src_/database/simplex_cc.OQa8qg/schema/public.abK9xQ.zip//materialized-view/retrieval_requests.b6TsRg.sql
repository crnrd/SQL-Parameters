CREATE MATERIALIZED VIEW retrieval_requests AS SELECT retrieval_requests_live.id,
    retrieval_requests_live.payment_id,
    retrieval_requests_live.inserted_at,
    retrieval_requests_live.posted_at,
    retrieval_requests_live.reason_code,
    retrieval_requests_live.user_id
   FROM retrieval_requests_live;

CREATE UNIQUE INDEX retrieval_requests_pk
  ON retrieval_requests (id);

CREATE UNIQUE INDEX retrieval_requests_payment_id_inserted_at_idx
  ON retrieval_requests (payment_id DESC, inserted_at DESC);

