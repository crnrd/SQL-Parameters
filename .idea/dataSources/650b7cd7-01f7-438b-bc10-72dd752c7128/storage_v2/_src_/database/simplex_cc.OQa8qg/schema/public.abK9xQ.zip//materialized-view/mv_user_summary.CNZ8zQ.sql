CREATE MATERIALIZED VIEW mv_user_summary AS WITH p_ids AS (
         SELECT payments.id,
            payments.email
           FROM payments
          WHERE (payments.status = ANY (ARRAY[2, 13, 15, 11, 16, 22]))
        ), email_p_ids AS (
         SELECT payments.id,
            payments.created_at,
            payments.email
           FROM payments
          WHERE (((payments.email)::text IN ( SELECT p_ids.email
                   FROM p_ids)) AND (payments.status = ANY (ARRAY[2, 13, 15, 11, 16, 22])))
        ), all_labels AS (
         SELECT DISTINCT ON (pfd.payment_id) pfd.payment_id,
            pfd.payment_label AS first_decision,
            pld.payment_label AS last_decision,
            pls.payment_label AS last_state
           FROM ((mv_payment_first_decision_label pfd
             LEFT JOIN mv_payment_last_decision_label pld ON ((pld.payment_id = pfd.payment_id)))
             LEFT JOIN mv_payment_last_state_label pls ON ((pls.payment_id = pfd.payment_id)))
          WHERE (pfd.payment_id IN ( SELECT email_p_ids.id
                   FROM email_p_ids))
        ), user_risk_status AS (
         SELECT simplex_end_users.email,
            simplex_end_users.user_risk_status
           FROM simplex_end_users
          WHERE ((simplex_end_users.email)::text IN ( SELECT email_p_ids.email
                   FROM email_p_ids))
        ), user_last_manual_decision AS (
         SELECT manual_decisions.email,
            manual_decisions.id,
            manual_decisions.created_at,
            manual_decisions.last_decision
           FROM ( SELECT DISTINCT ON (email_p_ids.email) email_p_ids.email,
                    email_p_ids.id,
                    email_p_ids.created_at,
                    al.last_decision
                   FROM (email_p_ids
                     JOIN ( SELECT all_labels.payment_id,
                            all_labels.last_decision
                           FROM all_labels
                          WHERE (all_labels.last_decision = ANY (ARRAY['approved'::text, 'declined_fraud'::text, 'declined_potential_fraud'::text]))) al ON ((al.payment_id = email_p_ids.id)))
                  ORDER BY email_p_ids.email, email_p_ids.created_at DESC) manual_decisions
          WHERE (manual_decisions.last_decision IS NOT NULL)
        ), user_last_decision AS (
         SELECT decisions.email,
            decisions.created_at,
            decisions.last_decision
           FROM ( SELECT DISTINCT ON (email_p_ids.email) email_p_ids.email,
                    email_p_ids.created_at,
                    al.last_decision
                   FROM (email_p_ids
                     LEFT JOIN ( SELECT all_labels.payment_id,
                            all_labels.last_decision
                           FROM all_labels) al ON ((al.payment_id = email_p_ids.id)))
                  ORDER BY email_p_ids.email, email_p_ids.created_at DESC) decisions
        )
 SELECT DISTINCT user_payment_stats.email,
    uld.last_decision AS user_last_decision,
    ulmd.last_decision AS user_last_manual_decision,
    user_payment_stats.user_risk_status,
    sum(user_payment_stats.fraud_payment) AS fraud_payments,
    sum(user_payment_stats.third_party_fraud_payment) AS third_party_fraud_payment,
    sum(user_payment_stats.friendly_fraud_payment) AS friendly_fraud_payment,
    sum(user_payment_stats.service_cb_or_refund_payment) AS service_cb_or_refund_payments,
    sum(user_payment_stats.old_approved_payment) AS old_approved_payments,
    sum(user_payment_stats.approved_payment) AS approved_payments
   FROM ((( SELECT p.email,
            p.id,
            urs.user_risk_status,
            al.first_decision,
            al.last_decision,
            al.last_state,
                CASE
                    WHEN (al.last_state = 'fraud'::text) THEN 1
                    ELSE 0
                END AS fraud_payment,
                CASE
                    WHEN (al.last_state = '3rd Party Fraud'::text) THEN 1
                    ELSE 0
                END AS third_party_fraud_payment,
                CASE
                    WHEN (al.last_state = 'Friendly Fraud'::text) THEN 1
                    ELSE 0
                END AS friendly_fraud_payment,
                CASE
                    WHEN (al.last_state = ANY (ARRAY['service_cb'::text, 'refund'::text])) THEN 1
                    ELSE 0
                END AS service_cb_or_refund_payment,
                CASE
                    WHEN (al.last_state = 'approved_old'::text) THEN 1
                    ELSE 0
                END AS old_approved_payment,
                CASE
                    WHEN (al.last_state = 'approved'::text) THEN 1
                    ELSE 0
                END AS approved_payment
           FROM ((email_p_ids p
             LEFT JOIN user_risk_status urs ON (((urs.email)::text = (p.email)::text)))
             LEFT JOIN all_labels al ON ((al.payment_id = p.id)))) user_payment_stats
     LEFT JOIN user_last_decision uld ON (((uld.email)::text = (user_payment_stats.email)::text)))
     LEFT JOIN user_last_manual_decision ulmd ON (((ulmd.email)::text = (user_payment_stats.email)::text)))
  GROUP BY user_payment_stats.email, uld.last_decision, ulmd.last_decision, user_payment_stats.user_risk_status;

