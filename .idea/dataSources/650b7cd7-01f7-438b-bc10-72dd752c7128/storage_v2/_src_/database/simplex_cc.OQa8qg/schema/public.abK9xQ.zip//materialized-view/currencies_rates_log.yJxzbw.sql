CREATE MATERIALIZED VIEW currencies_rates_log AS SELECT currencies_rates_log_live.id,
    currencies_rates_log_live.created_at,
    currencies_rates_log_live.rates,
    currencies_rates_log_live.rates_source
   FROM currencies_rates_log_live;

