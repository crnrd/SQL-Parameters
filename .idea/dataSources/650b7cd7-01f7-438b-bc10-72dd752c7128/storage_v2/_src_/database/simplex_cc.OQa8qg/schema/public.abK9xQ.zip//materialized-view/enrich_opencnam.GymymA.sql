CREATE MATERIALIZED VIEW enrich_opencnam AS SELECT enrich_opencnam_live.id,
    enrich_opencnam_live.inserted_at,
    enrich_opencnam_live.phone,
    enrich_opencnam_live.data
   FROM enrich_opencnam_live;

CREATE UNIQUE INDEX enrich_opencnam_pk
  ON enrich_opencnam (id);

CREATE UNIQUE INDEX enrich_opencnam_phone_inserted_at_idx
  ON enrich_opencnam (phone, inserted_at);

