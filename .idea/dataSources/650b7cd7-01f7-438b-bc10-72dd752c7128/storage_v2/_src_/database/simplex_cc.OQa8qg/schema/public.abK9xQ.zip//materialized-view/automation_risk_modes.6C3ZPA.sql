CREATE MATERIALIZED VIEW automation_risk_modes AS SELECT automation_risk_modes_live.id,
    automation_risk_modes_live.risk_mode,
    automation_risk_modes_live.changing_user_id,
    automation_risk_modes_live.inserted_at
   FROM automation_risk_modes_live;

CREATE UNIQUE INDEX automation_risk_modes_pk
  ON automation_risk_modes (id);

CREATE UNIQUE INDEX automation_risk_modes_inserted_at_idx
  ON automation_risk_modes (inserted_at DESC);

