CREATE MATERIALIZED VIEW social_data AS SELECT social_data_live.id,
    social_data_live.data,
    social_data_live.created_at
   FROM social_data_live;

CREATE UNIQUE INDEX social_data_pk
  ON social_data (id);

