CREATE MATERIALIZED VIEW mv_payment_last_state_label AS WITH p_ids AS (
         SELECT payments.id,
            payments.status,
            payments.created_at
           FROM payments
          WHERE (payments.status = ANY (ARRAY[2, 13, 15, 11, 16, 22]))
        )
 SELECT labels.payment_id,
    labels.r_payment_id,
    labels.payment_label
   FROM ( SELECT pld.payment_id,
            rp.id AS r_payment_id,
                CASE
                    WHEN (((fr.cb_type = ANY (ARRAY['Fraud'::text, 'Real'::text, 'Real, internal'::text])) OR (fr.refund_type = 'Fraud'::text)) OR (fr.fw_type = ANY (ARRAY['Real'::fraud_types, 'Real, internal'::fraud_types]))) THEN 'fraud'::text
                    WHEN ((fr.cb_type = ANY (ARRAY['Service'::text, 'Service Level'::text])) OR (fr.fw_type = 'Service Level'::fraud_types)) THEN 'service_cb'::text
                    WHEN ((fr.cb_type = '3rd Party Fraud'::text) OR (fr.fw_type = '3rd Party Fraud'::fraud_types)) THEN '3rd Party Fraud'::text
                    WHEN ((fr.cb_type = 'Friendly Fraud'::text) OR (fr.fw_type = 'Friendly Fraud'::fraud_types)) THEN 'Friendly Fraud'::text
                    WHEN (fr.refund_type = 'Service'::text) THEN 'refund'::text
                    WHEN ((p_ids.status = 2) AND (p_ids.created_at < (now() - '45 days'::interval))) THEN 'approved_old'::text
                    ELSE pld.payment_label
                END AS payment_label
           FROM (((mv_payment_last_decision_label pld
             LEFT JOIN p_ids ON ((pld.payment_id = p_ids.id)))
             LEFT JOIN mv_fraud_inputs fr ON ((fr.payment_id = p_ids.id)))
             LEFT JOIN r_payments rp ON ((rp.simplex_payment_id = p_ids.id)))
          WHERE (pld.payment_id IN ( SELECT p_ids_1.id
                   FROM p_ids p_ids_1))) labels;

