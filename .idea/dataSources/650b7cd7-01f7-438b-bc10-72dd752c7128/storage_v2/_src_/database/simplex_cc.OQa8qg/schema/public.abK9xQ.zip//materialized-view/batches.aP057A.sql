CREATE MATERIALIZED VIEW batches AS SELECT batches_live.id,
    batches_live.name,
    batches_live.created_at,
    batches_live.file,
    batches_live.finished_at,
    batches_live.actor_id,
    batches_live.notes,
    batches_live.status,
    batches_live.line_count
   FROM batches_live;

CREATE UNIQUE INDEX batches_id_pk
  ON batches (id);

CREATE INDEX batches_actor_id_fk_idx
  ON batches (actor_id);

