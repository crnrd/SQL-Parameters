CREATE MATERIALIZED VIEW enrich_whitepages AS SELECT enrich_whitepages_live.id,
    enrich_whitepages_live.payment_id,
    enrich_whitepages_live.inserted_at,
    enrich_whitepages_live.data,
    enrich_whitepages_live.request_data
   FROM enrich_whitepages_live;

CREATE UNIQUE INDEX whitepages_pk
  ON enrich_whitepages (id);

CREATE UNIQUE INDEX enrich_whitepages_payment_id_inserted_at_idx
  ON enrich_whitepages (payment_id, inserted_at);

