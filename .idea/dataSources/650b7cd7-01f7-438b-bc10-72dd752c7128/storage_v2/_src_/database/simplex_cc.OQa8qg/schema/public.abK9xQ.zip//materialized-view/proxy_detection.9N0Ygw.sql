CREATE MATERIALIZED VIEW proxy_detection AS SELECT proxy_detection_live.id,
    proxy_detection_live.payment_id,
    proxy_detection_live.partner_end_user_id,
    proxy_detection_live.inserted_at,
    proxy_detection_live.data
   FROM proxy_detection_live;

CREATE UNIQUE INDEX proxy_detection_pk
  ON proxy_detection (id);

CREATE INDEX proxy_detection_payment_id_fk_idx
  ON proxy_detection (payment_id);

