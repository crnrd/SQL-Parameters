CREATE MATERIALIZED VIEW refunds AS SELECT refunds_live.id,
    refunds_live.payment_id,
    refunds_live.inserted_at,
    refunds_live.support_ticket_id,
    refunds_live.simplex_end_user_id,
    refunds_live.descriptive_reason,
    refunds_live.user_id
   FROM refunds_live;

CREATE UNIQUE INDEX refunds_pk
  ON refunds (id);

CREATE UNIQUE INDEX refunds_payment_id_simplex_end_user_id_inserted_at_idx
  ON refunds (payment_id DESC, simplex_end_user_id DESC, inserted_at DESC);

