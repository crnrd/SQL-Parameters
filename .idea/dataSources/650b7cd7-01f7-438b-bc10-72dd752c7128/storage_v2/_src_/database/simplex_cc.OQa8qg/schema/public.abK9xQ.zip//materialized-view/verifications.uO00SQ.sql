CREATE MATERIALIZED VIEW verifications AS SELECT verifications_live.id,
    verifications_live.simplex_end_user_id,
    verifications_live.requesting_user_id,
    verifications_live.verification_type,
    verifications_live.finalizing_user_id,
    verifications_live.status,
    verifications_live.partner_end_user_id,
    verifications_live.initial_payment_id,
    verifications_live.inserted_at,
    verifications_live.finalized_at
   FROM verifications_live;

CREATE UNIQUE INDEX verifications_id_pk
  ON verifications (id);

CREATE INDEX verifications_simplex_end_user_id_idx
  ON verifications (simplex_end_user_id);

