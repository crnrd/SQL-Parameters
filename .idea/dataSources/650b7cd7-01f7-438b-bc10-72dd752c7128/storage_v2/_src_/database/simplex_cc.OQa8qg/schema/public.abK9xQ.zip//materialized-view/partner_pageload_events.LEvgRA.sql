CREATE MATERIALIZED VIEW partner_pageload_events AS SELECT partner_pageload_events_live.id,
    partner_pageload_events_live.partner_id,
    partner_pageload_events_live.session_id,
    partner_pageload_events_live.uaid,
    partner_pageload_events_live.created_at,
    partner_pageload_events_live.params
   FROM partner_pageload_events_live;

CREATE UNIQUE INDEX partner_pageload_events_id_pk
  ON partner_pageload_events (id);

CREATE INDEX partner_pageload_events_partner_id_params_session_id_idx
  ON partner_pageload_events (partner_id, (params ->> 'session_id' :: TEXT));

