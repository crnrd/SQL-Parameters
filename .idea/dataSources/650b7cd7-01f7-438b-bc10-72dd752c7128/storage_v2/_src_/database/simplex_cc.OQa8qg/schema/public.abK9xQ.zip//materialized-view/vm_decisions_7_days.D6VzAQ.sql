CREATE MATERIALIZED VIEW vm_decisions_7_days AS SELECT d.id,
    d.application_name,
    d.analytic_code_version,
    d.payment_id,
    d.executed_at,
    d.decision,
    d.variables,
    d.created_at,
    d.batch_id,
    d.reason,
    d.request_id,
    d.r_payment_id,
    d.reason_code
   FROM v_decisions_7_days_live d;

CREATE UNIQUE INDEX vm_decisions_7_days_id_pk
  ON vm_decisions_7_days (id);

CREATE INDEX vm_decisions_7_days_payment_id_fk_idx
  ON vm_decisions_7_days (payment_id);

CREATE INDEX vm_decisions_7_days7_days_executed_at_application_name_idx
  ON vm_decisions_7_days (executed_at, application_name);

CREATE INDEX vm_decisions_7_days_execute_at_idx
  ON vm_decisions_7_days (executed_at);

CREATE INDEX vm_decisions_7_days_batch_id_fk_idx
  ON vm_decisions_7_days (batch_id);

