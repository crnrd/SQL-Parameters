CREATE MATERIALIZED VIEW r_cc_authorizations AS SELECT r_cc_authorizations_live.id,
    r_cc_authorizations_live.inserted_at,
    r_cc_authorizations_live.published_at,
    r_cc_authorizations_live.payment_id,
    r_cc_authorizations_live.raw_response,
    r_cc_authorizations_live.r_cc_processor_for_tokens_id,
    r_cc_authorizations_live.status,
    r_cc_authorizations_live.payment_event_id
   FROM r_cc_authorizations_live;

CREATE UNIQUE INDEX r_cc_authorizations_pkey
  ON r_cc_authorizations (id);

CREATE INDEX r_cc_authorizations_payment_id_idx
  ON r_cc_authorizations (payment_id);

