CREATE MATERIALIZED VIEW r_partners AS SELECT r_partners_live.id,
    r_partners_live.name,
    r_partners_live.inserted_at
   FROM r_partners_live;

CREATE UNIQUE INDEX r_partners_pkey
  ON r_partners (id);

CREATE UNIQUE INDEX r_partners_name_key
  ON r_partners (name);

