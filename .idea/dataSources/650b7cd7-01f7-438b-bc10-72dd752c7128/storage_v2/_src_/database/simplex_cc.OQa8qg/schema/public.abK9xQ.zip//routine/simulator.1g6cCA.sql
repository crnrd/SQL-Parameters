CREATE FUNCTION simulator(username character varying, application_name character varying, analytic_code_version character varying, from_payment integer, to_payment integer)
  RETURNS integer
LANGUAGE plpgsql
AS $$
DECLARE	payment_ids_curs CURSOR FOR 
select payment_id, analytic_executed_at from (

SELECT DISTINCT ON (payment_id) payment_id, analytic_executed_at
FROM (SELECT DISTINCT ON (payment_id) payment_id,
             analytic_executed_at,
             1 time_type
      FROM (SELECT payment_id, TO_TIMESTAMP(analytic_executed_at,'YYYY MM DD HH24:MI:SS.MS')::TIMESTAMP WITHOUT TIME ZONE analytic_executed_at
            FROM (
     -- OPTION 1 : executed_at as appears in the analytical model where Bender executed the run
     							-- (the 2nd refers to different json pattern which was once used)
                 SELECT d.payment_id, COALESCE ((d.variables #>> '{Analytic, executed_at}'),(d.variables #>> '{0, executed_at}')::text) AS analytic_executed_at 
                 FROM decisions d
              JOIN payments p ON (d.payment_id = p.id)
            WHERE d.application_name = 'Bender'
            AND   p.status > 0) z WHERE z.analytic_executed_at IS NOT NULL
            -- take only the earliest time for each payment	
            ORDER BY payment_id,
                     analytic_executed_at) a
      -- OPTION 2: other options for time (used only if the first query returns nothing)
      UNION ALL
      SELECT DISTINCT ON (payment_id) payment_id, analytic_executed_at, 2 time_type
      FROM (SELECT payment_id,
                   analytic_executed_at analytic_executed_at
            FROM (SELECT d.payment_id,
                         d.created_at AS analytic_executed_at
                  FROM decisions d
                    JOIN payments p ON (d.payment_id = p.id)
                  WHERE p.status > 0
                  AND   d.created_at IS NOT NULL
                  UNION ALL
                  SELECT d.payment_id,
                         d.executed_at AS analytic_executed_at
                  FROM decisions d
                    JOIN payments p ON (d.payment_id = p.id)
                  WHERE p.status > 0
                  AND   d.executed_at IS NOT NULL
                  UNION ALL
                  SELECT p.id payment_id,
                         p.handling_at AS analytic_executed_at
                  FROM payments p
                  WHERE status > 0
                  AND   p.handling_at IS NOT NULL
                  -- add 5 minutes only here
                  UNION ALL
                  SELECT p.id payment_id,
                         p.created_at  + INTERVAL '5 minutes' AS analytic_executed_at
                  FROM payments p
                  WHERE status > 0) x
            -- take only the earliest (non null) time for each payment
            ORDER BY payment_id,
                     analytic_executed_at) z
      -- taking only the best result: the best (=minimal) "time_type" + the earliest
      -- ("earliest" should be an overkill - because there should not be a case in which type-type 1 exists and is later than an existing time_type 2)
      -- however, there are some cases (in previous versions of the model) which this did is explicitly no the case (see payments 7060)
      ORDER BY payment_id,
               time_type,
               analytic_executed_at) aa
)g
where g.payment_id between from_payment and to_payment;

	
	decision SqlDecisionType;
	counts integer;
	run_id integer;
	err_str1 text;
	err_str2 text;
	err_str3 text;
BEGIN
	INSERT INTO simulation_runs ( "username",  "application_name",  "analytic_code_version" )
	VALUES (  username,  application_name,  analytic_code_version)
	RETURNING id into run_id;

	counts := 0;
	--select count(*) into counts from (select id,bender_noam(run_id, id)  from payments where status in (1,6) and id between 16812 and 16820)a;
	FOR payment_rec in payment_ids_curs LOOP
		BEGIN		
			select 
				f.payment_id,
	 	    f.decision,
	  	  f.variables,
		    f.reason,
		    f.application_name,
		    f.analytic_code_version,
		    f.executed_at 
			into decision from bender_2_3_2 (payment_rec.payment_id, payment_rec.analytic_executed_at) f;
			BEGIN
				INSERT INTO simulations(  "run_id",  "payment_id",  "reason", "decision",  "variables" ) 
								VALUES (run_id, decision.payment_id, decision.reason, decision.decision, decision.variables);
			EXCEPTION WHEN not_null_violation THEN
				RAISE NOTICE 'Error runnign analytic model on payment(%)', payment_rec.id;
			END;
		EXCEPTION WHEN OTHERS THEN
			GET STACKED DIAGNOSTICS err_str1 = MESSAGE_TEXT,
                          err_str2 = PG_EXCEPTION_DETAIL,
                          err_str3 = PG_EXCEPTION_HINT;
      RAISE NOTICE 'Error runnign analytic model on payment(%) \n (%) \n (%) \n (%) \n', payment_rec.id, err_str1, err_str2, err_str3;
		END;
		
		--insert into simulation_results(payment_id, decision) values (payment_rec.id, decision);
		counts = counts + 1;
	END LOOP;

RETURN counts;

END;
$$;

