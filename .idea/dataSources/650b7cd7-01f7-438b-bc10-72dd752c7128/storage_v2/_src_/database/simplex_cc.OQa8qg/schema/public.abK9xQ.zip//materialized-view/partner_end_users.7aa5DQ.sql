CREATE MATERIALIZED VIEW partner_end_users AS SELECT partner_end_users_live.id,
    partner_end_users_live.partner_id,
    partner_end_users_live.partner_account_id,
    partner_end_users_live.verified_at,
    partner_end_users_live.risk_score,
    partner_end_users_live.account_tier,
    partner_end_users_live.account_tier_updated_at,
    partner_end_users_live.first_name,
    partner_end_users_live.last_name,
    partner_end_users_live.email,
    partner_end_users_live.address_line_1,
    partner_end_users_live.phone,
    partner_end_users_live.country,
    partner_end_users_live.state,
    partner_end_users_live.date_of_birth,
    partner_end_users_live.gender,
    partner_end_users_live.two_fa_enabled,
    partner_end_users_live.two_fa_updated_at,
    partner_end_users_live.passport_details,
    partner_end_users_live.utility_bill_details,
    partner_end_users_live.created_at,
    partner_end_users_live.updated_at,
    partner_end_users_live.deposits,
    partner_end_users_live.withdrawals,
    partner_end_users_live.first_logins,
    partner_end_users_live.last_logins,
    partner_end_users_live.bank_accounts,
    partner_end_users_live.city,
    partner_end_users_live.zip,
    partner_end_users_live.middle_name,
    partner_end_users_live.address_line_2,
    partner_end_users_live.risk_score_updated_at,
    partner_end_users_live.signup_login,
    partner_end_users_live.kyc_files,
    partner_end_users_live.kyc_updated_at,
    partner_end_users_live.is_vip,
    partner_end_users_live.verification_token,
    partner_end_users_live.token_created_at,
    partner_end_users_live.cap_data,
    partner_end_users_live.social_data_id,
    partner_end_users_live.past_tx_data,
    partner_end_users_live.last_verified_email
   FROM partner_end_users_live;

CREATE UNIQUE INDEX partner_end_user_pk_idx
  ON partner_end_users (id);

CREATE UNIQUE INDEX partner_end_users_pk
  ON partner_end_users (id);

CREATE UNIQUE INDEX partner_end_users_partner_id_partner_account_id_key
  ON partner_end_users (partner_id, partner_account_id);

CREATE INDEX partner_end_user_partner_id_account_id
  ON partner_end_users (partner_id, partner_account_id);

CREATE INDEX partner_end_users_email_updated_at_idx
  ON partner_end_users (email, updated_at);

CREATE INDEX partner_end_users_phone_idx
  ON partner_end_users (phone);

CREATE INDEX partner_end_users_verification_token_idx
  ON partner_end_users (verification_token);

