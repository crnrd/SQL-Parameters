CREATE FUNCTION simulator()
  RETURNS integer
LANGUAGE plpgsql
AS $$
DECLARE
	payment_ids_curs CURSOR FOR select id from payments where status in (1,6) and id between 16811 and 16814;
	decision text;
	counts integer;
BEGIN
counts := 0;
perform (select count(*) from (select id,bender(id)  from payments where status in (1,6) and id between 16811 and 16814)b) a;
-- FOR payment_rec in payment_ids_curs LOOP
-- 	select bender_noam(payment_rec.id) into decision;
-- 	--insert into simulation_results(payment_id, decision) values (payment_rec.id, decision);
-- 	counts = counts + 1;
-- END LOOP;

RETURN counts;

END;
$$;

