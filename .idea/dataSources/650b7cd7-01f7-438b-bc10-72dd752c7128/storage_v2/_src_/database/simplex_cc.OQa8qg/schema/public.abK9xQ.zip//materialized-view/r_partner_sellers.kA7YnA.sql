CREATE MATERIALIZED VIEW r_partner_sellers AS SELECT r_partner_sellers_live.id,
    r_partner_sellers_live.partner_id,
    r_partner_sellers_live.partner_generated_seller_id,
    r_partner_sellers_live.inserted_at
   FROM r_partner_sellers_live;

CREATE UNIQUE INDEX r_partner_sellers_pkey
  ON r_partner_sellers (id);

CREATE UNIQUE INDEX r_partner_sellers_generated_user_id_peu_partner_id_idx
  ON r_partner_sellers (partner_generated_seller_id, partner_id);

