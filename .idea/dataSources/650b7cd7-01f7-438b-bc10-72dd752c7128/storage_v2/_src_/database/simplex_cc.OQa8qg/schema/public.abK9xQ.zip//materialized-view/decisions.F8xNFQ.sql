CREATE MATERIALIZED VIEW decisions AS SELECT decisions_etl.id,
    decisions_etl.application_name,
    decisions_etl.analytic_code_version,
    decisions_etl.payment_id,
    decisions_etl.executed_at,
    decisions_etl.decision,
    decisions_etl.variables,
    decisions_etl.created_at,
    decisions_etl.batch_id,
    decisions_etl.reason,
    decisions_etl.request_id,
    decisions_etl.r_payment_id,
    decisions_etl.reason_code
   FROM decisions_etl;

CREATE INDEX auto_decisions_id_pk_idx
  ON decisions (id);

CREATE INDEX auto_decisions_payment_id_fk_idx
  ON decisions (payment_id);

CREATE INDEX decisions_decision_executed_at_application_name_idx
  ON decisions (decision, executed_at, application_name);

CREATE INDEX auto_decisions_batch_id_fk_idx
  ON decisions (batch_id);

