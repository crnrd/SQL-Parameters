CREATE VIEW proc_requests_view AS
  SELECT proc_requests.id,
    proc_requests.created_at,
    proc_requests.updated_at,
    proc_requests.payment_id,
    proc_requests.request_id,
    proc_requests.tx_type,
    proc_requests.processor,
    proc_requests.status,
    (proc_requests.raw_response ->> 'acquirerresponsemessage'::text) AS status_description,
    proc_requests.masked_credit_card,
    ( SELECT row_to_json(avs.*) AS row_to_json
           FROM ( SELECT (proc_requests.raw_response ->> 'securityresponseaddress'::text) AS avs_address,
                    (proc_requests.raw_response ->> 'securityresponsepostcode'::text) AS avs_zipcode) avs) AS avs_code,
    (proc_requests.raw_response ->> 'enrolled'::text) AS threeds_enrolled,
    (proc_requests.raw_response ->> 'status'::text) AS threeds_status,
    (proc_requests.raw_response ->> 'errorcode'::text) AS threeds_errorcode,
    (proc_requests.raw_response ->> 'eci'::text) AS threeds_eci
   FROM proc_requests
  WHERE (proc_requests.processor = 'secure_trading'::processor)
UNION ALL
 SELECT proc_requests.id,
    proc_requests.created_at,
    proc_requests.updated_at,
    proc_requests.payment_id,
    proc_requests.request_id,
    proc_requests.tx_type,
    proc_requests.processor,
    proc_requests.status,
        CASE
            WHEN (((proc_requests.raw_response #> '{statuses,status}'::text[]))::json IS NULL) THEN (proc_requests.raw_response ->> 'status_description_1'::text)
            ELSE (((proc_requests.raw_response #> '{statuses,status}'::text[]) -> 0) ->> 'description'::text)
        END AS status_description,
    proc_requests.masked_credit_card,
        CASE
            WHEN (((proc_requests.raw_response #> '{statuses,status}'::text[]))::json IS NULL) THEN ( SELECT row_to_json(t.*) AS row_to_json
               FROM ( SELECT (proc_requests.raw_response ->> 'avs_code'::text) AS avs_code) t)
            ELSE ( SELECT row_to_json(t.*) AS row_to_json
               FROM ( SELECT (proc_requests.raw_response ->> 'avs-code'::text) AS avs_code) t)
        END AS avs_code,
    NULL::text AS threeds_enrolled,
    NULL::text AS threeds_status,
    NULL::text AS threeds_errorcode,
    NULL::text AS threeds_eci
   FROM proc_requests
  WHERE (proc_requests.processor = 'compayments'::processor);

