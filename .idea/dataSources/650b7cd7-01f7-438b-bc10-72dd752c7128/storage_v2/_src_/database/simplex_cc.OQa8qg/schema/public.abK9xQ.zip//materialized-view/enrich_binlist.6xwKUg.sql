CREATE MATERIALIZED VIEW enrich_binlist AS SELECT enrich_binlist_live.id,
    enrich_binlist_live.inserted_at,
    enrich_binlist_live.bin,
    enrich_binlist_live.response_data
   FROM enrich_binlist_live;

CREATE INDEX enrich_binlist_bin_inserted_at
  ON enrich_binlist (bin ASC, inserted_at DESC);

