CREATE MATERIALIZED VIEW random_charges AS SELECT random_charges_live.id,
    random_charges_live.partner_end_user_id,
    random_charges_live.card_id,
    random_charges_live.payment_id,
    random_charges_live.auth_amount,
    random_charges_live.currency,
    random_charges_live.inserted_at,
    random_charges_live.finalized_at,
    random_charges_live.charge_type,
    random_charges_live.capture_amount,
    random_charges_live.status,
    random_charges_live.verifications
   FROM random_charges_live;

CREATE UNIQUE INDEX random_charges_pk
  ON random_charges (id);

CREATE INDEX random_charges_partner_end_user_id_idx
  ON random_charges (partner_end_user_id);

CREATE INDEX random_charges_card_id_idx
  ON random_charges (card_id);

CREATE INDEX random_charges_payment_id_idx
  ON random_charges (payment_id);

