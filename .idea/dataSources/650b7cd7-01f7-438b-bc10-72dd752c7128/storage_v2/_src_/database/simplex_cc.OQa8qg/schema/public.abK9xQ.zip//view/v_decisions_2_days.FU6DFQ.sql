CREATE VIEW v_decisions_2_days AS
  SELECT decisions_live.id,
    decisions_live.application_name,
    decisions_live.analytic_code_version,
    decisions_live.payment_id,
    decisions_live.executed_at,
    decisions_live.decision,
    decisions_live.variables,
    decisions_live.created_at,
    decisions_live.batch_id,
    decisions_live.reason,
    decisions_live.request_id,
    decisions_live.r_payment_id,
    decisions_live.reason_code
   FROM decisions_live
  WHERE (decisions_live.executed_at > (now() - '2 days'::interval));

