CREATE MATERIALIZED VIEW payments AS SELECT payments_live.id,
    payments_live.payment_id,
    payments_live.partner_end_user_id,
    payments_live.btc_address,
    payments_live.amount,
    payments_live.credit_card,
    payments_live.max_allowed_deposits,
    payments_live.created_at,
    payments_live.status,
    payments_live.maxmind,
    payments_live.balances,
    payments_live.partner_login,
    payments_live.simplex_login,
    payments_live.exchange_rates,
    payments_live.simplex_end_user_id,
    payments_live.clearance_id,
    payments_live.updated_at,
    payments_live.currency,
    payments_live.first_name_card,
    payments_live.last_name_card,
    payments_live.handling_user_id,
    payments_live.total_amount,
    payments_live.country,
    payments_live.state,
    payments_live.city,
    payments_live.address1,
    payments_live.address2,
    payments_live.zipcode,
    payments_live.authorization_request_id,
    payments_live.authorization_transaction_id,
    payments_live.handling_at,
    payments_live.card_id,
    payments_live.is_proc_status_called,
    payments_live.avs_code,
    payments_live.csc_code,
    payments_live.capture_request_id,
    payments_live.capture_transaction_id,
    payments_live.auth_transaction_status,
    payments_live.blocked,
    payments_live.order_id,
    payments_live.processor_cc_token_id,
    payments_live.is_tampering_attempt,
    payments_live.payment_request_body,
    payments_live.validation_request_body,
    payments_live.processor_auth_data,
    payments_live.chargeback_at,
    payments_live.chargeback_reason,
    payments_live.capture_transaction_status,
    payments_live.processor_id,
    payments_live.completed_at,
    payments_live.fee,
    payments_live.user_reported_vcc,
    payments_live.user_comment,
    payments_live.card_expiry_year,
    payments_live.card_expiry_month,
    payments_live.quote_id,
    payments_live.pay_to_partner_id,
    payments_live.affiliate_fee,
    payments_live.original_http_ref_url,
    payments_live.email,
    payments_live.first_name,
    payments_live.last_name,
    payments_live.phone,
    payments_live.update_event,
    payments_live.update_event_inserted_at,
    payments_live.date_of_birth,
    payments_live.crypto_currency,
    payments_live.crypto_currency_address,
    payments_live.total_amount_usd,
    payments_live.usd_rate,
    payments_live.conversion_time,
    payments_live.cc_identifier,
    payments_live.cc_expiry_identifier,
    payments_live.bin
   FROM payments_live;

CREATE UNIQUE INDEX payment_attempt_pk
  ON payments (id);

CREATE UNIQUE INDEX payments_pk_idx
  ON payments (id);

CREATE UNIQUE INDEX payments_payment_id_key
  ON payments (payment_id);

CREATE INDEX payments_lower_email_idx
  ON payments (lower(email :: TEXT));

CREATE INDEX payments_partner_login_ip_idx
  ON payments ((partner_login ->> 'ip' :: TEXT));

CREATE INDEX payments_simplex_login_ip_idx
  ON payments ((simplex_login ->> 'ip' :: TEXT));

CREATE INDEX payments_simplex_login_uaid_idx
  ON payments ((simplex_login ->> 'uaid' :: TEXT));

CREATE INDEX payments_validation_request_body_email_idx
  ON payments ((validation_request_body #>> '{email}' :: TEXT []));

CREATE INDEX fki_partner_end_user_fk
  ON payments (partner_end_user_id);

CREATE INDEX payments_btc_address_idx
  ON payments (btc_address);

CREATE INDEX payments_credit_card_idx
  ON payments (credit_card);

CREATE INDEX payments_create_at_idx
  ON payments (created_at);

CREATE INDEX payments_status_idx
  ON payments (status);

CREATE INDEX payments_simplex_end_user_id_idx
  ON payments (simplex_end_user_id);

CREATE INDEX payments_updated_at_idx
  ON payments (updated_at);

CREATE INDEX payments_address_idx
  ON payments (address1, city, zipcode, country, state, address2);

CREATE INDEX payments_order_id_idx
  ON payments (order_id);

CREATE INDEX payments_email_idx
  ON payments (email);

CREATE INDEX payments_phone_idx
  ON payments (phone);

