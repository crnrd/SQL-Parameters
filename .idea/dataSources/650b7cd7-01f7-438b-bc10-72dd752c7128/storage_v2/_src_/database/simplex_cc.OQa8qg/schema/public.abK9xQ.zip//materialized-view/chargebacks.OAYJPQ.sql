CREATE MATERIALIZED VIEW chargebacks AS SELECT chargebacks_live.id,
    chargebacks_live.payment_id,
    chargebacks_live.inserted_at,
    chargebacks_live.posted_at,
    chargebacks_live.reason_code,
    chargebacks_live.is_simplex_liable,
    chargebacks_live.simplex_end_user_id,
    chargebacks_live.user_id,
    chargebacks_live.raw_data,
    chargebacks_live.status,
    chargebacks_live.batch_id
   FROM chargebacks_live;

CREATE UNIQUE INDEX chargebacks_pk
  ON chargebacks (id);

CREATE UNIQUE INDEX chargebacks_payment_id_simplex_end_user_id_inserted_at_idx
  ON chargebacks (payment_id DESC, simplex_end_user_id DESC, inserted_at DESC);

CREATE INDEX chargebacks_payment_id_status_inserted_at_idx
  ON chargebacks (payment_id, status, inserted_at);

