CREATE MATERIALIZED VIEW fraud_only_partner_payment_ids AS SELECT fraud_only_partner_payment_ids_live.id,
    fraud_only_partner_payment_ids_live.api_payment_id,
    fraud_only_partner_payment_ids_live.payment_uuid,
    fraud_only_partner_payment_ids_live.partner_id,
    fraud_only_partner_payment_ids_live.inserted_at
   FROM fraud_only_partner_payment_ids_live;

CREATE UNIQUE INDEX fraud_only_partner_payment_ids_pk
  ON fraud_only_partner_payment_ids (id);

CREATE UNIQUE INDEX fraud_only_partner_payment_ids_api_payment_id_partner_id_idx
  ON fraud_only_partner_payment_ids (api_payment_id, partner_id);

