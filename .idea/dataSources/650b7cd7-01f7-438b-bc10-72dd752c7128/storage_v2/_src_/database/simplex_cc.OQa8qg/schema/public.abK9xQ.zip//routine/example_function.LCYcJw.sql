CREATE FUNCTION example_function()
  RETURNS text
LANGUAGE plpgsql
AS $$
DECLARE
    
    -- Declare a constant integer with a
    -- default value of 5.
    five CONSTANT INTEGER := 5;
    
    -- Declare an integer with a default
    -- value of 100 that cannot be NULL.
    ten INTEGER NOT NULL := 10;
    
    -- Declare a character with
    -- a default value of "a".
    letter CHAR DEFAULT 'a';
  
  BEGIN
  return letter;
  END;
$$;

