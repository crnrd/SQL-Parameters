CREATE MATERIALIZED VIEW cc_expiry_identifiers AS SELECT cc_expiry_identifiers_live.id,
    cc_expiry_identifiers_live.credit_card,
    cc_expiry_identifiers_live.expiry_year,
    cc_expiry_identifiers_live.expiry_month,
    cc_expiry_identifiers_live.identifier
   FROM cc_expiry_identifiers_live;

CREATE UNIQUE INDEX cc_expiry_identifiers_pk
  ON cc_expiry_identifiers (id);

CREATE UNIQUE INDEX cc_expiry_identifiers_credit_card_expiry_year_expiry_month_key
  ON cc_expiry_identifiers (credit_card, expiry_year, expiry_month);

CREATE UNIQUE INDEX cc_expiry_identifiers_identifier_key
  ON cc_expiry_identifiers (identifier);

CREATE INDEX cc_expiry_identifiers_cc_expiry_idx
  ON cc_expiry_identifiers (credit_card, expiry_year, expiry_month);

CREATE INDEX cc_expiry_identifiers_uuid
  ON cc_expiry_identifiers (identifier);

