CREATE MATERIALIZED VIEW r_refunds AS SELECT r_refunds_live.id,
    r_refunds_live.inserted_at,
    r_refunds_live.published_at,
    r_refunds_live.payment_id,
    r_refunds_live.peu_id,
    r_refunds_live.partner_reason_raw
   FROM r_refunds_live;

CREATE UNIQUE INDEX r_refunds_pkey
  ON r_refunds (id);

CREATE INDEX r_refunds_payment_id_idx
  ON r_refunds (payment_id);

CREATE INDEX r_refunds_peu_id_idx
  ON r_refunds (peu_id);

