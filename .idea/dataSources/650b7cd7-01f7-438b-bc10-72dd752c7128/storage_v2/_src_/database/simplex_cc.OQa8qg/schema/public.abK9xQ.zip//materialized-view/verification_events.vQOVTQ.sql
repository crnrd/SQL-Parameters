CREATE MATERIALIZED VIEW verification_events AS SELECT verification_events_live.id,
    verification_events_live.verification_id,
    verification_events_live.name,
    verification_events_live.inserted_at
   FROM verification_events_live;

CREATE UNIQUE INDEX verification_events_id_pk
  ON verification_events (id);

CREATE INDEX verification_events_verification_id_idx
  ON verification_events (verification_id);

