CREATE MATERIALIZED VIEW r_peu_snap_events AS SELECT r_peu_snap_events_live.id,
    r_peu_snap_events_live.peu_id,
    r_peu_snap_events_live.partner_specific,
    r_peu_snap_events_live.created_at,
    r_peu_snap_events_live.inserted_at,
    r_peu_snap_events_live.published_at,
    r_peu_snap_events_live.first_name_raw,
    r_peu_snap_events_live.last_name_raw,
    r_peu_snap_events_live.middle_name_raw,
    r_peu_snap_events_live.email_raw,
    r_peu_snap_events_live.phone_raw,
    r_peu_snap_events_live.address1_raw,
    r_peu_snap_events_live.address2_raw,
    r_peu_snap_events_live.country_raw,
    r_peu_snap_events_live.state_raw,
    r_peu_snap_events_live.city_raw,
    r_peu_snap_events_live.zipcode_raw,
    r_peu_snap_events_live.year_of_birth,
    r_peu_snap_events_live.gender
   FROM r_peu_snap_events_live;

CREATE UNIQUE INDEX r_peu_snap_events_pkey
  ON r_peu_snap_events (id);

CREATE INDEX r_peu_snap_events_peu_id_idx
  ON r_peu_snap_events (peu_id);

CREATE INDEX r_peu_snap_events_email_inserted_at_idx
  ON r_peu_snap_events (email_raw, inserted_at);

CREATE INDEX r_peu_snap_events_phone_idx
  ON r_peu_snap_events (phone_raw);

