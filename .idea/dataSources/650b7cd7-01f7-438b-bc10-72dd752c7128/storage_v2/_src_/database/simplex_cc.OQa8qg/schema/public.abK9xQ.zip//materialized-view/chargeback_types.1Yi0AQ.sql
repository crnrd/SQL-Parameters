CREATE MATERIALIZED VIEW chargeback_types AS SELECT chargeback_types_live.reason_code,
    chargeback_types_live.chargeback_type,
    chargeback_types_live.card_present
   FROM chargeback_types_live;

CREATE UNIQUE INDEX chargeback_classifications_reason_code_pk
  ON chargeback_types (reason_code);

