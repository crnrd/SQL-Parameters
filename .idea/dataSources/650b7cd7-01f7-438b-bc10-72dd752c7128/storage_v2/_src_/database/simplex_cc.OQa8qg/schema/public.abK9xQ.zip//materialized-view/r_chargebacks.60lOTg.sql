CREATE MATERIALIZED VIEW r_chargebacks AS SELECT r_chargebacks_live.id,
    r_chargebacks_live.inserted_at,
    r_chargebacks_live.published_at,
    r_chargebacks_live.payment_id,
    r_chargebacks_live.peu_id,
    r_chargebacks_live.type_raw
   FROM r_chargebacks_live;

CREATE UNIQUE INDEX r_chargebacks_pkey
  ON r_chargebacks (id);

CREATE INDEX r_chargebacks_payment_id_idx
  ON r_chargebacks (payment_id);

CREATE INDEX r_chargebacks_peu_id_idx
  ON r_chargebacks (peu_id);

