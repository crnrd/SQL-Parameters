CREATE MATERIALIZED VIEW mv_payment_first_decision_label AS WITH p_ids AS (
         SELECT payments.id
           FROM payments
          WHERE (payments.status = ANY (ARRAY[2, 13, 15, 11, 16, 22]))
          ORDER BY payments.id
        ), ver_req AS (
         SELECT DISTINCT ON (verification_requests.payment_id) verification_requests.payment_id,
            verification_requests.inserted_at,
                CASE
                    WHEN (verification_requests.requesting_user_id <= 0) THEN 'Auto'::text
                    ELSE 'Manual'::text
                END AS ver_requesting_user
           FROM verification_requests
          WHERE ((verification_requests.payment_id IN ( SELECT p_ids.id
                   FROM p_ids)) AND ((verification_requests.allow_verifications #>> '{0}'::text[]) = ANY (ARRAY['photo_selfie'::text, 'video_selfie'::text])))
          ORDER BY verification_requests.payment_id, verification_requests.inserted_at
        )
 SELECT labels.payment_id,
    labels.payment_label
   FROM ( SELECT pd.payment_id,
                CASE
                    WHEN ((pd.post_auth_decision = 'declined'::decision_type) OR (pd.post_kyc_decision = 'declined'::decision_type)) THEN 'auto_declined'::text
                    WHEN ((pd.post_auth_decision = 'approved'::decision_type) OR (pd.post_kyc_decision = 'approved'::decision_type)) THEN 'auto_approved'::text
                    WHEN ((pd.post_auth_decision = 'verify'::decision_type) AND ((pd.post_auth_reason)::text = ANY ((ARRAY['Policy require photo selfie with *THIS PAYMENT* credit card with *SAME PERSON* name on card'::character varying, 'should have kyc identity'::character varying])::text[]))) THEN 'auto_policy_verify'::text
                    WHEN (pd.post_auth_decision = 'verify'::decision_type) THEN 'auto_risk_verify'::text
                    WHEN (ver_req.ver_requesting_user = 'Manual'::text) THEN 'verify'::text
                    WHEN ((pd.manual_decision = 'declined'::decision_type) AND ((pd.manual_strength = 'Strong'::text) OR ((pd.manual_reason)::text = ANY ((ARRAY['Carder'::character varying, 'Fraud Ring'::character varying, 'Identity Issues'::character varying, 'Fake Selfie'::character varying, 'External Indicators'::character varying, 'Strong Link To Fraud'::character varying])::text[])))) THEN 'declined_fraud'::text
                    WHEN ((pd.manual_decision = 'declined'::decision_type) AND ((pd.manual_strength = 'Weak'::text) OR ((pd.manual_reason)::text = ANY ((ARRAY['Suspicious Behavior in Form'::character varying, 'Suspicious Payment, Failed Verification'::character varying, 'Online Bad Indicators'::character varying, 'Shady Person, Linking Indicates Bad'::character varying, 'Nothing Good'::character varying])::text[])))) THEN 'declined_potential_fraud'::text
                    WHEN ((pd.manual_decision = 'declined'::decision_type) AND ((pd.manual_strength ~~* 'policy'::text) OR ((pd.manual_reason)::text = ANY ((ARRAY['Partner Policy'::character varying, 'Underage'::character varying, 'Undesired Users - Policy'::character varying, 'Aggressive User'::character varying, '3rd Party Scam'::character varying])::text[])))) THEN 'declined_policy'::text
                    WHEN (pd.manual_decision = 'approved'::decision_type) THEN 'approved'::text
                    WHEN ((pd.cutoff_decision = 'approved'::decision_type) OR (pd.batch_decision = 'approved'::decision_type)) THEN 'cutoff_approved'::text
                    WHEN ((pd.cutoff_decision = 'declined'::decision_type) OR (pd.batch_decision = 'declined'::decision_type)) THEN 'cutoff_declined'::text
                    ELSE 'other'::text
                END AS payment_label
           FROM (mv_payment_decisions pd
             LEFT JOIN ver_req ON ((pd.payment_id = ver_req.payment_id)))
          WHERE (pd.payment_id IN ( SELECT p_ids.id
                   FROM p_ids))) labels;

