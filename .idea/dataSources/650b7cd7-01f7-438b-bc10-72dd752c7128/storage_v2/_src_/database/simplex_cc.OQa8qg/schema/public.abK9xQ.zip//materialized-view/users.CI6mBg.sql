CREATE MATERIALIZED VIEW users AS SELECT users_live.id,
    users_live.email,
    users_live.test_mode
   FROM users_live;

CREATE UNIQUE INDEX users_pk
  ON users (id);

CREATE UNIQUE INDEX users_pk_idx
  ON users (id);

CREATE UNIQUE INDEX users_email_key
  ON users (email);

