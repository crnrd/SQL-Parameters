CREATE MATERIALIZED VIEW lang_table AS SELECT lang_table_live.id,
    lang_table_live.country_code,
    lang_table_live.language_code
   FROM lang_table_live;

CREATE UNIQUE INDEX lang_table_id_pk
  ON lang_table (id);

CREATE INDEX lang_table_id_idx
  ON lang_table (id);

