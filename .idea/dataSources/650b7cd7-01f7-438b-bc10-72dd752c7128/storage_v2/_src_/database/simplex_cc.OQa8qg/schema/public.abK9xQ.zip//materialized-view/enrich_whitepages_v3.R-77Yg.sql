CREATE MATERIALIZED VIEW enrich_whitepages_v3 AS SELECT enrich_whitepages_v3_live.id,
    enrich_whitepages_v3_live.request_data,
    enrich_whitepages_v3_live.encoded_request_data,
    enrich_whitepages_v3_live.data,
    enrich_whitepages_v3_live.inserted_at
   FROM enrich_whitepages_v3_live;

CREATE UNIQUE INDEX enrich_whitepages_v3_pk
  ON enrich_whitepages_v3 (id);

CREATE UNIQUE INDEX enrich_whitepages_v3_request_data_inserted_at
  ON enrich_whitepages_v3 (request_data, inserted_at);

