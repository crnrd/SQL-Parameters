CREATE MATERIALIZED VIEW verifications_history AS SELECT verifications_history_live.simplex_end_user_id,
    verifications_history_live.credit_card
   FROM verifications_history_live;

