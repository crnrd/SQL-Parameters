CREATE MATERIALIZED VIEW radar_measurements AS SELECT radar_measurements_live.id,
    radar_measurements_live.payment_id,
    radar_measurements_live.sample_timestamp,
    radar_measurements_live.ip_client,
    radar_measurements_live.ip_server,
    radar_measurements_live.inserted_at,
    radar_measurements_live.data
   FROM radar_measurements_live;

CREATE UNIQUE INDEX radar_measurements_pk
  ON radar_measurements (id);

CREATE INDEX radar_measurements_payment_id_fk_idx
  ON radar_measurements (payment_id);

