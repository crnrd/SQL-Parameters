CREATE MATERIALIZED VIEW fraud_warnings_imports AS SELECT fraud_warnings_imports_live.id,
    fraud_warnings_imports_live.started_at,
    fraud_warnings_imports_live.ended_at,
    fraud_warnings_imports_live.file_name,
    fraud_warnings_imports_live.records_count,
    fraud_warnings_imports_live.records_failed_validation,
    fraud_warnings_imports_live.record_match_payment_count,
    fraud_warnings_imports_live.success_record_imported,
    fraud_warnings_imports_live.raw_data_table_name
   FROM fraud_warnings_imports_live;

CREATE UNIQUE INDEX fraud_warnings_imports_pkey
  ON fraud_warnings_imports (id);

