CREATE MATERIALIZED VIEW proc_requests AS SELECT proc_requests_live.id,
    proc_requests_live.created_at,
    proc_requests_live.updated_at,
    proc_requests_live.payment_id,
    proc_requests_live.request_id,
    proc_requests_live.raw_response,
    proc_requests_live.tx_type,
    proc_requests_live.processor,
    proc_requests_live.status,
    proc_requests_live.random_charge_id,
    proc_requests_live.request_data,
    proc_requests_live.masked_credit_card,
    proc_requests_live.init_response_data,
    proc_requests_live.notification_response_data
   FROM proc_requests_live;

CREATE UNIQUE INDEX proc_requests_pk
  ON proc_requests (id);

CREATE INDEX proc_requests_payment_id_idx
  ON proc_requests (payment_id);

CREATE INDEX proc_requests_request_id_idx
  ON proc_requests (request_id);

CREATE INDEX proc_requests_random_charge_id_idx
  ON proc_requests (random_charge_id);

CREATE INDEX proc_requests_masked_credit_card_idx
  ON proc_requests (masked_credit_card);

