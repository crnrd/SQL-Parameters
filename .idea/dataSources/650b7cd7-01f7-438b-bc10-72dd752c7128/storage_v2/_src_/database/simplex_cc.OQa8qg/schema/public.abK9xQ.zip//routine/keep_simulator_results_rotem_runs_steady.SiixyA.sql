CREATE FUNCTION keep_simulator_results_rotem_runs_steady()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
                            IF (SELECT count(distinct(run_id)) FROM simulator_results_rotem) > 5
                            THEN
                                RAISE EXCEPTION 'Too many simulator runs. Please delete old simulations.';
                            END IF;
                            RETURN NEW;
                        END;
$$;

