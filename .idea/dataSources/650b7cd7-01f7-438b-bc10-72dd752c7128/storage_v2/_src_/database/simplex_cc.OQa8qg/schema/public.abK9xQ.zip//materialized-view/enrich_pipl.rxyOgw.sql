CREATE MATERIALIZED VIEW enrich_pipl AS SELECT enrich_pipl_live.id,
    enrich_pipl_live.email,
    enrich_pipl_live.data,
    enrich_pipl_live.inserted_at
   FROM enrich_pipl_live;

CREATE UNIQUE INDEX enrich_pipl_pk
  ON enrich_pipl (id);

CREATE UNIQUE INDEX enrich_pipl_email_inserted_at_idx
  ON enrich_pipl (email, inserted_at);

