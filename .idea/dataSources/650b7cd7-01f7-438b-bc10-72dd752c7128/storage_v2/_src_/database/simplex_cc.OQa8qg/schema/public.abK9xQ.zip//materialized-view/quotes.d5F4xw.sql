CREATE MATERIALIZED VIEW quotes AS SELECT quotes_live.quote_id,
    quotes_live.broker_id,
    quotes_live.wallet_id,
    quotes_live.digital_currency,
    quotes_live.fiat_currency,
    quotes_live.digital_amount,
    quotes_live.fiat_amount,
    quotes_live.valid_until,
    quotes_live.broker_rate,
    quotes_live.payment_id
   FROM quotes_live;

CREATE UNIQUE INDEX quotes_pk
  ON quotes (quote_id);

CREATE INDEX quotes_broker_id_idx
  ON quotes (broker_id);

CREATE INDEX quotes_payment_id_idx
  ON quotes (payment_id);

