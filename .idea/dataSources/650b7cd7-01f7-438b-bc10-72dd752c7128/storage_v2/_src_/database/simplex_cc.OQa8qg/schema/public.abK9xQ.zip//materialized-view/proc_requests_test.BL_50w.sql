CREATE MATERIALIZED VIEW proc_requests_test AS SELECT proc_requests_test_live.id,
    proc_requests_test_live.created_at,
    proc_requests_test_live.updated_at,
    proc_requests_test_live.payment_id,
    proc_requests_test_live.request_id,
    proc_requests_test_live.raw_response,
    proc_requests_test_live.tx_type,
    proc_requests_test_live.processor,
    proc_requests_test_live.status
   FROM proc_requests_test_live;

CREATE UNIQUE INDEX proc_requests_test_pk
  ON proc_requests_test (id);

CREATE INDEX proc_requests_test_payment_id_idx
  ON proc_requests_test (payment_id);

CREATE INDEX proc_requests_test_request_id_idx
  ON proc_requests_test (request_id);

