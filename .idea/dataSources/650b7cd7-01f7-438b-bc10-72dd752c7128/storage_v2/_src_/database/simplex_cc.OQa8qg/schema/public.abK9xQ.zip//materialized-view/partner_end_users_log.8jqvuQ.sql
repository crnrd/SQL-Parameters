CREATE MATERIALIZED VIEW partner_end_users_log AS SELECT partner_end_users_log_live.id,
    partner_end_users_log_live.current_end_user_id,
    partner_end_users_log_live.partner_id,
    partner_end_users_log_live.partner_account_id,
    partner_end_users_log_live.verified_at,
    partner_end_users_log_live.risk_score,
    partner_end_users_log_live.account_tier,
    partner_end_users_log_live.account_tier_updated_at,
    partner_end_users_log_live.first_name,
    partner_end_users_log_live.last_name,
    partner_end_users_log_live.email,
    partner_end_users_log_live.address_line_1,
    partner_end_users_log_live.phone,
    partner_end_users_log_live.country,
    partner_end_users_log_live.state,
    partner_end_users_log_live.date_of_birth,
    partner_end_users_log_live.gender,
    partner_end_users_log_live.two_fa_enabled,
    partner_end_users_log_live.two_fa_updated_at,
    partner_end_users_log_live.passport_details,
    partner_end_users_log_live.utility_bill_details,
    partner_end_users_log_live.created_at,
    partner_end_users_log_live.updated_at,
    partner_end_users_log_live.deposits,
    partner_end_users_log_live.withdrawals,
    partner_end_users_log_live.first_logins,
    partner_end_users_log_live.last_logins,
    partner_end_users_log_live.bank_accounts,
    partner_end_users_log_live.city,
    partner_end_users_log_live.zip,
    partner_end_users_log_live.middle_name,
    partner_end_users_log_live.address_line_2,
    partner_end_users_log_live.risk_score_updated_at,
    partner_end_users_log_live.signup_login,
    partner_end_users_log_live.kyc_files,
    partner_end_users_log_live.kyc_updated_at,
    partner_end_users_log_live.is_vip,
    partner_end_users_log_live.verification_token,
    partner_end_users_log_live.token_created_at,
    partner_end_users_log_live.cap_data,
    partner_end_users_log_live.social_data_id,
    partner_end_users_log_live.past_tx_data
   FROM partner_end_users_log_live;

CREATE UNIQUE INDEX partner_end_user_log_pk_idx
  ON partner_end_users_log (id);

CREATE UNIQUE INDEX partner_end_users_log_pk
  ON partner_end_users_log (id);

CREATE INDEX current_end_user_id
  ON partner_end_users_log (current_end_user_id);

CREATE INDEX partner_end_users_log_email_updated_at_idx
  ON partner_end_users_log (email, updated_at);

CREATE INDEX partner_end_users_log_email_idx
  ON partner_end_users_log (email);

CREATE INDEX partner_end_users_log_phone_idx
  ON partner_end_users_log (phone);

