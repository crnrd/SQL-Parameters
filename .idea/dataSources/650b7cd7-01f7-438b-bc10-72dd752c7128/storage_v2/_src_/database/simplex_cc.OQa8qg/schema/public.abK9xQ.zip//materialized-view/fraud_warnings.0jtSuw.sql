CREATE MATERIALIZED VIEW fraud_warnings AS SELECT fraud_warnings_live.id,
    fraud_warnings_live.inserted_at,
    fraud_warnings_live.import_id,
    fraud_warnings_live.payment_created_at,
    fraud_warnings_live.reported_at,
    fraud_warnings_live.payment_id,
    fraud_warnings_live.processor,
    fraud_warnings_live.card_scheme,
    fraud_warnings_live.masked_credit_card,
    fraud_warnings_live.fraud_type_raw,
    fraud_warnings_live.fraud_amount,
    fraud_warnings_live.fraud_currency,
    fraud_warnings_live.transaction_amount,
    fraud_warnings_live.transaction_currency,
    fraud_warnings_live.chargeback_occured,
    fraud_warnings_live.account_closed
   FROM fraud_warnings_live;

CREATE UNIQUE INDEX fraud_warnings_pkey
  ON fraud_warnings (id);

CREATE INDEX fraud_warnings_inserted_at_idx
  ON fraud_warnings (inserted_at);

CREATE INDEX fraud_warnings_payment_id_inserted_at_idx
  ON fraud_warnings (payment_id, inserted_at);

