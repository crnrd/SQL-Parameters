CREATE MATERIALIZED VIEW mv_payment_decisions AS WITH p_ids AS (
         SELECT payments.id
           FROM payments
          WHERE (payments.status = ANY (ARRAY[2, 13, 15, 11, 16, 22]))
          ORDER BY payments.id
        ), pre_auth_decision AS (
         SELECT DISTINCT ON (decisions.payment_id) decisions.payment_id,
            decisions.decision,
            decisions.reason
           FROM decisions
          WHERE ((decisions.application_name)::text = 'Bender_Pre_Auth_Decide'::text)
          ORDER BY decisions.payment_id, decisions.created_at DESC
        ), post_auth_decision AS (
         SELECT decisions.payment_id,
            decisions.decision,
            decisions.reason
           FROM decisions
          WHERE ((decisions.payment_id IN ( SELECT p_ids_1.id
                   FROM p_ids p_ids_1)) AND ((decisions.application_name)::text = 'Bender_Auto_Decide'::text))
        ), cutoff_decision AS (
         SELECT decisions.payment_id,
            decisions.decision,
            decisions.reason
           FROM decisions
          WHERE ((decisions.payment_id IN ( SELECT p_ids_1.id
                   FROM p_ids p_ids_1)) AND ((decisions.application_name)::text = 'Bender_Pending_Payment_Manual'::text))
        ), batch_decision AS (
         SELECT decisions.payment_id,
            decisions.decision,
            decisions.reason
           FROM decisions
          WHERE ((decisions.payment_id IN ( SELECT p_ids_1.id
                   FROM p_ids p_ids_1)) AND ((decisions.application_name)::text = 'Bender_Manual'::text))
        ), post_kyc_decision AS (
         SELECT decisions.payment_id,
            decisions.decision,
            decisions.reason
           FROM decisions
          WHERE ((decisions.payment_id IN ( SELECT p_ids_1.id
                   FROM p_ids p_ids_1)) AND ((decisions.application_name)::text = 'Nibbler_post_kyc'::text))
        ), manual_decision AS (
         SELECT decisions.payment_id,
            decisions.decision,
            decisions.reason,
            (decisions.variables #>> '{strength}'::text[]) AS strength
           FROM decisions
          WHERE (((decisions.payment_id IN ( SELECT p_ids_1.id
                   FROM p_ids p_ids_1)) AND ((decisions.application_name)::text = 'Manual'::text)) AND (decisions.decision = ANY (ARRAY['approved'::decision_type, 'declined'::decision_type])))
        ), manual_offline_decision AS (
         SELECT decisions.payment_id,
            decisions.decision,
            (decisions.variables #>> '{strength}'::text[]) AS strength,
            decisions.reason
           FROM decisions
          WHERE (((decisions.payment_id IN ( SELECT p_ids_1.id
                   FROM p_ids p_ids_1)) AND ((decisions.application_name)::text = 'Offline Manual'::text)) AND (decisions.decision = ANY (ARRAY['approved'::decision_type, 'declined'::decision_type])))
        ), ver_req AS (
         SELECT DISTINCT ON (verification_requests.payment_id) verification_requests.payment_id,
            verification_requests.inserted_at,
                CASE
                    WHEN (verification_requests.requesting_user_id <= 0) THEN 'Auto'::text
                    ELSE 'Manual'::text
                END AS ver_requesting_user
           FROM verification_requests
          WHERE ((verification_requests.payment_id IN ( SELECT p_ids_1.id
                   FROM p_ids p_ids_1)) AND ((verification_requests.allow_verifications #>> '{0}'::text[]) = ANY (ARRAY['photo_selfie'::text, 'video_selfie'::text])))
          ORDER BY verification_requests.payment_id, verification_requests.inserted_at
        )
 SELECT p_ids.id AS payment_id,
    prad.decision AS pre_auth_decision,
    prad.reason AS pre_auth_reason,
    pad.decision AS post_auth_decision,
    pad.reason AS post_auth_reason,
    md.decision AS manual_decision,
    md.reason AS manual_reason,
    md.strength AS manual_strength,
    omd.decision AS offline_manual_decision,
    omd.reason AS offline_manual_reason,
    omd.strength AS offline_manual_strength,
    pkyc.decision AS post_kyc_decision,
    pkyc.reason AS post_kyc_reason,
    cd.decision AS cutoff_decision,
    cd.reason AS cutoff_reason,
    bd.decision AS batch_decision,
    bd.reason AS batch_reason
   FROM (((((((p_ids
     LEFT JOIN pre_auth_decision prad ON ((prad.payment_id = p_ids.id)))
     LEFT JOIN post_auth_decision pad ON ((pad.payment_id = p_ids.id)))
     LEFT JOIN post_kyc_decision pkyc ON ((pkyc.payment_id = p_ids.id)))
     LEFT JOIN manual_decision md ON ((md.payment_id = p_ids.id)))
     LEFT JOIN manual_offline_decision omd ON ((omd.payment_id = p_ids.id)))
     LEFT JOIN cutoff_decision cd ON ((cd.payment_id = p_ids.id)))
     LEFT JOIN batch_decision bd ON ((bd.payment_id = p_ids.id)));

