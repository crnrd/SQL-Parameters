CREATE MATERIALIZED VIEW enrich_maxmind AS SELECT enrich_maxmind_live.id,
    enrich_maxmind_live.inserted_at,
    enrich_maxmind_live.data,
    enrich_maxmind_live.request_data,
    enrich_maxmind_live.context,
    enrich_maxmind_live.hash_key
   FROM enrich_maxmind_live;

CREATE UNIQUE INDEX enrich_maxmind_pk
  ON enrich_maxmind (id);

CREATE UNIQUE INDEX enrich_maxmind_hash_key_inserted_at_idx
  ON enrich_maxmind (hash_key, inserted_at);

