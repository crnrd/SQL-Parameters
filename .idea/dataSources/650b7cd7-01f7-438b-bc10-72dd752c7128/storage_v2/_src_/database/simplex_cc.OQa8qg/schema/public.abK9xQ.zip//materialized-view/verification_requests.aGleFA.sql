CREATE MATERIALIZED VIEW verification_requests AS SELECT verification_requests_live.id,
    verification_requests_live.simplex_end_user_id,
    verification_requests_live.payment_id,
    verification_requests_live.allow_verifications,
    verification_requests_live.verification_type,
    verification_requests_live.inserted_at,
    verification_requests_live.status,
    verification_requests_live.token,
    verification_requests_live.requesting_user_id,
    verification_requests_live.finalized_at,
    verification_requests_live.verification_format,
    verification_requests_live.parent_id,
    verification_requests_live.verifier_response,
    verification_requests_live.verifier_responded_at
   FROM verification_requests_live;

CREATE UNIQUE INDEX verification_requests_id_pk
  ON verification_requests (id);

CREATE INDEX verification_requests_payment_id
  ON verification_requests (payment_id);

CREATE INDEX verification_requests_payment_id_idx
  ON verification_requests (payment_id);

