CREATE MATERIALIZED VIEW mv_fraud_inputs AS WITH p_ids AS (
         SELECT payments.id,
            payments.status
           FROM payments
          WHERE (payments.status = ANY (ARRAY[2, 13, 15, 11, 16, 22]))
        ), cb AS (
         SELECT chargebacks.payment_id,
                CASE
                    WHEN (chargebacks.reason_code = ANY (ARRAY[4837, 4870, 83, 75])) THEN 'Fraud'::text
                    ELSE 'Service'::text
                END AS cb_type
           FROM chargebacks
          WHERE (chargebacks.payment_id IN ( SELECT p_ids.id
                   FROM p_ids))
        UNION ALL
         SELECT chargeback_decisions.payment_id,
            (chargeback_decisions.fraud_type)::text AS cb_type
           FROM chargeback_decisions
          WHERE (chargeback_decisions.payment_id IN ( SELECT p_ids.id
                   FROM p_ids))
        ), ref AS (
         SELECT refunds.payment_id,
                CASE
                    WHEN ((refunds.descriptive_reason)::text = 'Preventative Fraud'::text) THEN 'Fraud'::text
                    ELSE 'Service'::text
                END AS refund_type
           FROM refunds
          WHERE (refunds.payment_id IN ( SELECT p_ids.id
                   FROM p_ids))
        ), fw AS (
         SELECT fraud_warning_classifications.payment_id,
            fraud_warning_classifications.fraud_type AS fw_type
           FROM fraud_warning_classifications
          WHERE (fraud_warning_classifications.payment_id IN ( SELECT p_ids.id
                   FROM p_ids))
        )
 SELECT fraud_inputs.payment_id,
    fraud_inputs.cb_type,
    fraud_inputs.refund_type,
    fraud_inputs.fw_type
   FROM ( SELECT p_ids.id AS payment_id,
            cb.cb_type,
            ref.refund_type,
            fw.fw_type
           FROM (((p_ids
             LEFT JOIN cb ON ((cb.payment_id = p_ids.id)))
             LEFT JOIN ref ON ((ref.payment_id = p_ids.id)))
             LEFT JOIN fw ON ((fw.payment_id = p_ids.id)))) fraud_inputs
  WHERE (((fraud_inputs.cb_type IS NOT NULL) OR (fraud_inputs.refund_type IS NOT NULL)) OR (fraud_inputs.fw_type IS NOT NULL));

