CREATE MATERIALIZED VIEW mv_user_master_label AS WITH p_ids AS (
         SELECT payments.id,
            payments.email
           FROM payments
          WHERE (payments.status = ANY (ARRAY[2, 13, 15, 11, 16, 22]))
        )
 SELECT ul.email,
        CASE
            WHEN (ul.user_label = ANY (ARRAY['fraudalent_user'::text, 'urs_decline'::text, 'bad_user'::text, 'auto_declined'::text])) THEN 'bad'::text
            WHEN (ul.user_label = ANY (ARRAY['good_user'::text, 'approved_user_cancelled_last_payment'::text, 'approved_by_analyst'::text, 'auto_approved'::text])) THEN 'good'::text
            ELSE 'other'::text
        END AS user_master_label
   FROM mv_user_label ul
  WHERE ((ul.email)::text IN ( SELECT p_ids.email
           FROM p_ids));

