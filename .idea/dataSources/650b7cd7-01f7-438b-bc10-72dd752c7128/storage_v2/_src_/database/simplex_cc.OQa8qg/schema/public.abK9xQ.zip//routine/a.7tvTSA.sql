CREATE FUNCTION a(_max_tokens integer)
  RETURNS TABLE(id integer)
LANGUAGE plpgsql
AS $$
BEGIN

   IF (select count(*) from all_payments)>_max_tokens then
  RETURN QUERY SELECT id FROM payments limit 5;  -- note the potential ambiguity
END IF;
  IF (select count(*) from all_payments)<_max_tokens then
  RETURN QUERY SELECT id FROM payments limit 5;  -- note the potential ambiguity
END IF;

END
$$;

