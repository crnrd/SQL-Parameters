CREATE MATERIALIZED VIEW settings AS SELECT settings_live.name,
    settings_live.value_integer,
    settings_live.created_at,
    settings_live.updated_at,
    settings_live.value_json
   FROM settings_live;

CREATE UNIQUE INDEX settings_pk
  ON settings (name);

CREATE UNIQUE INDEX settings_pk_idx
  ON settings (name);

