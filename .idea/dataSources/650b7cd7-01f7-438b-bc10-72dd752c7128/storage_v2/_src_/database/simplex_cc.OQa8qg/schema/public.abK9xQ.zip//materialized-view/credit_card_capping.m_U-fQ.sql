CREATE MATERIALIZED VIEW credit_card_capping AS SELECT credit_card_capping_live.id,
    credit_card_capping_live.credit_card,
    credit_card_capping_live.card_expiry_year,
    credit_card_capping_live.card_expiry_month,
    credit_card_capping_live.cap_data,
    credit_card_capping_live.created_at,
    credit_card_capping_live.updated_at
   FROM credit_card_capping_live;

CREATE UNIQUE INDEX credit_card_capping_id_primary_key
  ON credit_card_capping (id);

CREATE UNIQUE INDEX credit_card_capping_key
  ON credit_card_capping (credit_card, card_expiry_year, card_expiry_month);

