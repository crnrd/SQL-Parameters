CREATE MATERIALIZED VIEW chargeback_decisions AS SELECT chargeback_decisions_live.id,
    chargeback_decisions_live.inserted_at,
    chargeback_decisions_live.payment_id,
    chargeback_decisions_live.fraud_type,
    chargeback_decisions_live.decider_user_id
   FROM chargeback_decisions_live;

CREATE UNIQUE INDEX chargeback_decisions_pkey
  ON chargeback_decisions (id);

CREATE INDEX chargeback_decisions_payment_id_idx
  ON chargeback_decisions (payment_id);

