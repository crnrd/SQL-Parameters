CREATE MATERIALIZED VIEW user_browser_events AS SELECT user_browser_events_live.id,
    user_browser_events_live.event_type,
    user_browser_events_live.request_data,
    user_browser_events_live.response_data,
    user_browser_events_live.api_requests,
    user_browser_events_live.inserted_at,
    user_browser_events_live.payment_id
   FROM user_browser_events_live;

CREATE UNIQUE INDEX user_client_events_pk
  ON user_browser_events (id);

CREATE INDEX user_browser_events_payment_id
  ON user_browser_events (payment_id);

