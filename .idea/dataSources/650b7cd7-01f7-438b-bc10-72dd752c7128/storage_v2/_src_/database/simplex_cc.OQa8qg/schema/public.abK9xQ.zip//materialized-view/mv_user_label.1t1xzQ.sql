CREATE MATERIALIZED VIEW mv_user_label AS WITH p_ids AS (
         SELECT payments.id,
            payments.email
           FROM payments
          WHERE (payments.status = ANY (ARRAY[2, 13, 15, 11, 16, 22]))
        )
 SELECT us.email,
        CASE
            WHEN (us.fraud_payments > 0) THEN 'fraudalent_user'::text
            WHEN (us.third_party_fraud_payment > 0) THEN 'third_party_fraud_user'::text
            WHEN (us.friendly_fraud_payment > 0) THEN 'friendly_fraudster'::text
            WHEN (us.service_cb_or_refund_payments > 0) THEN 'service_cb_or_refunded_user'::text
            WHEN (us.user_risk_status = 'decline'::user_risk_status) THEN 'urs_decline'::text
            WHEN (us.user_risk_status = 'manual'::user_risk_status) THEN 'urs_manual'::text
            WHEN (us.user_last_manual_decision = 'declined_fraud'::text) THEN 'bad_user'::text
            WHEN ((us.user_last_manual_decision = 'declined_potential_fraud'::text) AND (us.old_approved_payments > 0)) THEN 'declined_but_approved_before_without_cb'::text
            WHEN (us.user_last_manual_decision = 'declined_potential_fraud'::text) THEN 'bad_user'::text
            WHEN (us.old_approved_payments > 0) THEN 'good_user'::text
            WHEN ((us.user_last_decision = ANY (ARRAY['cancelled_manual_ver'::text, 'cancelled_auto_ver'::text])) AND (us.approved_payments > 0)) THEN 'approved_user_cancelled_last_payment'::text
            WHEN (us.user_last_decision = ANY (ARRAY['cancelled_manual_ver'::text, 'cancelled_auto_ver'::text])) THEN 'not_approved_user_cancelled_last_payment'::text
            WHEN (us.approved_payments > 0) THEN 'approved_by_analyst'::text
            WHEN (us.user_last_decision = ANY (ARRAY['auto_approved'::text, 'cutoff_approved'::text])) THEN 'auto_approved'::text
            WHEN (us.user_last_decision = 'auto_declined'::text) THEN 'auto_declined'::text
            WHEN (us.user_last_decision = 'cutoff_declined'::text) THEN 'cutoff_auto_declined'::text
            WHEN (us.user_last_manual_decision = 'declined_policy'::text) THEN 'declined_policy'::text
            ELSE 'other'::text
        END AS user_label
   FROM mv_user_summary us
  WHERE ((us.email)::text IN ( SELECT p_ids.email
           FROM p_ids));

