CREATE FUNCTION bender_2_0_1_jsonb_noam(payment_pk integer)
  RETURNS sqldecisiontype
LANGUAGE plpgsql
AS $$
DECLARE
	model_decision SqlDecisionType;
	decision_out TEXT;
	payment payments%ROWTYPE;

BEGIN
    
-- populate payment variable
select * from payments into payment where id = payment_pk;

-- BEGINNING OF ANALYTIC CODE

--------------------------------------------------------------------------------------------------
-- Tables creation -------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------
--CREATE TEMP TABLE payments2 /* on commit drop */
--CREATE or replace TEMP VIEW 
WITH
/*
payments2
AS
(select *, validation_request_body #>> '{email}' email
from payments p
),

payments_log2
AS
(select *, validation_request_body #>> '{email}' email
from payments_log p
), */

--CREATE TEMP TABLE proc_requests2 /* on commit drop */
--CREATE or replace TEMP VIEW 
/*
proc_requests2
AS
(SELECT 
		prv.*, 
		p.validation_request_body #>> '{email}' email
FROM proc_requests_view prv
left join payments p on (prv.payment_id = p.id)
)
-- ******************** SIMPLEX_END_USER_ID *******************************

, */
first_payments /* on commit drop */
AS 
(SELECT MIN(a.id) first_payment_id
FROM payments a
-- ***************
where simplex_end_user_id = payment.simplex_end_user_id
-- ***************
)

,total_simplex_approved_amount  /* on commit drop */ as (
select sum(payment_amount) total_approved_amount from 
(select 
case when currency = 'EUR' then total_amount*1.12
when currency = 'GBP' then total_amount*1.55
else total_amount end payment_amount 
from payments where status in (2,6,13,15) --*** ADD refunds+status 6
-- **************
and simplex_end_user_id = payment.simplex_end_user_id
-- **************
) a
)

-- -- changed it from partner_end_user_id
-- ,total_simplex_deposits /* on commit drop */
-- AS
-- (SELECT SUM(payment_amount) total_simplex_deposits
-- FROM (SELECT 
--              CASE
--                WHEN currency = 'EUR' THEN total_amount*1.12
--                WHEN currency = 'GBP' THEN total_amount*1.55
--                ELSE total_amount
--              END payment_amount
--       FROM payments
--       WHERE status > 0
-- -- **************
-- and simplex_end_user_id = payment.simplex_end_user_id
-- -- **************
-- ) a
-- )

-- ******************** payment_id *******************************

,WP_data /* on commit drop */
AS
(SELECT payment_id, inserted_at, wp_phone, 
simplex_phone_prepaid,
simplex_phone_line_type,       
partner_phone_prepaid,
partner_phone_line_type,
CASE
WHEN simplex_phone_spam IN ('No spam indication','Low spam indication%') AND simplex_phone_prepaid <> 'Prepaid'
AND simplex_phone_line_type IN ('Mobile','Landline') THEN 'ok'
ELSE 'not_valid'
END AS simplex_phone_valid,
CASE
WHEN partner_phone_spam IN ('No spam indication','Low spam indication%') AND partner_phone_prepaid <> 'Prepaid'
AND partner_phone_line_type IN ('Mobile','Landline') THEN 'ok'
ELSE 'not_valid'
END AS partner_phone_valid,       
CASE
WHEN simplex_name_garbled_message = 'Looks valid' AND simplex_name_celeb_message = 'Looks valid (no celebrity name match)' THEN 'ok'
ELSE 'not_valid'
END AS simplex_name_valid,
CASE
WHEN simplex_name_on_card_garbled_message = 'Looks valid' AND simplex_name_on_card_celeb_message = 'Looks valid (no celebrity name match)' THEN 'ok'
ELSE 'not_valid'
END AS simplex_name_on_card_valid,
CASE
WHEN partner_name_garbled_message = 'Looks valid' AND partner_name_celeb_message = 'Looks valid (no celebrity name match)' THEN 'ok'
ELSE 'not_valid'
END AS partner_name_valid,       
-- case when simplex_address_family_count_message like '%single%' then 1 when simplex_address_family_count_message like '%None%' then 0 else cast(substring(simplex_address_family_count_message FROM '[0-9]+') as real) end as simplex_address_family_number,
-- case when partner_address_family_count_message like '%single%' then 1 when partner_address_family_count_message like '%None%' then 0 else cast(substring(partner_address_family_count_message FROM '[0-9]+') as real) end as partner_address_family_number,
CASE
WHEN (simplex_address_type IN ('Single unit','PO box','Multi unit','Unknown address type') AND simplex_address_receiving_mail <> 'receiving_mail.warn' AND simplex_address_deliverable <> 'deliverable.warn') THEN 'ok'
ELSE 'not_valid'
END AS simplex_address_valid,
CASE
WHEN (partner_address_type IN ('Single unit','PO box','Multi unit','Unknown address type') AND partner_address_receiving_mail <> 'receiving_mail.warn' AND partner_address_deliverable <> 'deliverable.warn') THEN 'ok'
ELSE 'not_valid'
END AS partner_address_valid,
 -- matching       
       CASE
         WHEN simplex_phone_addr_message = 'Directly connected to each other' THEN 'full_match'
         WHEN simplex_phone_addr_message = 'Indirectly connected to each other' THEN 'partial_match'
         ELSE 'no_match'
       END AS simplex_phone_address_match,
       CASE
         WHEN simplex_phone_name_code = 'match_status.perfect' THEN 'full_match'
         WHEN simplex_phone_name_code = 'match_status.inexact' THEN 'partial_match'
         ELSE 'no_match'
       END AS simplex_phone_name_match,
       CASE
         WHEN simplex_addr_name_code = 'match_status.perfect' THEN 'full_match'
         WHEN simplex_addr_name_code = 'match_status.inexact' THEN 'partial_match'
         ELSE 'no_match'
	       END AS simplex_address_name_match,
       CASE
         WHEN simplex_phone_name_on_card_code = 'match_status.perfect' THEN 'full_match'
         WHEN simplex_phone_name_on_card_code = 'match_status.inexact' THEN 'partial_match'
         ELSE 'no_match'
       END AS simplex_phone_name_on_card_match,
       CASE
         WHEN simplex_addr_name_on_card_code = 'match_status.perfect' THEN 'full_match'
         WHEN simplex_addr_name_on_card_code = 'match_status.inexact' THEN 'partial_match'
         ELSE 'no_match'
       END AS simplex_address_name_on_card_match,
       CASE
         WHEN partner_phone_addr_message = 'Directly connected to each other' THEN 'full_match'
         WHEN partner_phone_addr_message = 'Indirectly connected to each other' THEN 'partial_match'
         ELSE 'no_match'
       END AS partner_phone_address_match,
       CASE
         WHEN partner_phone_name_code = 'match_status.perfect' THEN 'full_match'
         WHEN partner_phone_name_code = 'match_status.inexact' THEN 'partial_match'
         ELSE 'no_match'
       END AS partner_phone_name_match,
       CASE
         WHEN partner_addr_name_code = 'match_status.perfect' THEN 'full_match'
         WHEN partner_addr_name_code = 'match_status.inexact' THEN 'partial_match'
         ELSE 'no_match'
       END AS partner_address_name_match
FROM 
(SELECT payment_id, inserted_at, replace(request_data->> 'billing_phone','%2B','+') wp_phone, 
-- validation
      			 DATA  #>> '{components,billing_phone_validation,diagnostics,1,message}' simplex_phone_spam,
             DATA  #>> '{components,billing_phone_validation,diagnostics,2,message}' simplex_phone_prepaid,
             DATA  #>> '{components,billing_phone_validation,diagnostics,3,message}' simplex_phone_line_type,
             DATA  #>> '{components,phone_validation,diagnostics,1,message}' partner_phone_spam,
             DATA  #>> '{components,phone_validation,diagnostics,2,message}' partner_phone_prepaid,
             DATA  #>> '{components,phone_validation,diagnostics,3,message}' partner_phone_line_type,             
     				 DATA  #>> '{components,billing_name_validation,diagnostics,0,message}' simplex_name_on_card_celeb_message,
             DATA  #>> '{components,billing_name_validation,diagnostics,1,message}' simplex_name_on_card_garbled_message,
						 DATA  #>> '{components,shipping_name_validation,diagnostics,0,message}' simplex_name_celeb_message,
 						 DATA  #>> '{components,shipping_name_validation,diagnostics,1,message}' simplex_name_garbled_message,
             DATA  #>> '{components,name_validation,diagnostics,0,message}' partner_name_celeb_message,
             DATA  #>> '{components,name_validation,diagnostics,1,message}' partner_name_garbled_message,             
      			 DATA  #>> '{components,billing_address_validation,diagnostics,0,message}' simplex_address_type,
             DATA  #>> '{components,billing_address_validation,diagnostics,1,code}' simplex_address_receiving_mail,
             DATA  #>> '{components,billing_address_validation,diagnostics,2,code}' simplex_address_deliverable,
             DATA  #>> '{components,billing_address_family_count,diagnostics,0,message}' simplex_address_family_count_message,
             DATA  #>> '{components,address_validation,diagnostics,0,message}' partner_address_type,
             DATA  #>> '{components,address_validation,diagnostics,1,code}' partner_address_receiving_mail,
             DATA  #>> '{components,address_validation,diagnostics,2,code}' partner_address_deliverable,
             DATA  #>> '{components,address_family_count,diagnostics,0,message}' partner_address_family_count_message,
-- matching
             DATA #>> '{components,billing_phone_name,diagnostics,0,code}' simplex_phone_name_on_card_code,
             DATA #>> '{components,billing_address_name,diagnostics,0,code}' simplex_addr_name_on_card_code,
             DATA #>> '{components,shipping_phone_address,diagnostics,0,message}' simplex_phone_addr_message,
             DATA #>> '{components,shipping_phone_name,diagnostics,0,code}' simplex_phone_name_code,
             DATA #>> '{components,shipping_address_name,diagnostics,0,code}' simplex_addr_name_code,
             DATA #>> '{components,phone_address,diagnostics,0,message}' partner_phone_addr_message,
             DATA #>> '{components,phone_name,diagnostics,0,code}' partner_phone_name_code,
             DATA #>> '{components,address_name,diagnostics,0,code}' partner_addr_name_code             
-- going over all (and only!) payments of this simplex user
  FROM (select ew.*, max(inserted_at) over (partition by ew.payment_id) max_inserted_at
  		 from enrich_whitepages ew
			 right join payments p on (p.id=ew.payment_id)
-- ****************
				where p.simplex_end_user_id = payment.simplex_end_user_id
-- ****************
 )
a where inserted_at=max_inserted_at
) wp
 ) 

,WP_payment_phone_match /* on commit drop */
AS
(SELECT p.id payment_id,
       CASE  WHEN p.id IN
       (SELECT payment_id
       FROM (SELECT id payment_id,
           					simplex_end_user_id,
                    phone
                    FROM (SELECT id,
                          updated_at,
                         phone,
                         MIN(updated_at) OVER (PARTITION BY id) min_updated_at
                         FROM (SELECT p.id,
                              p.created_at,
                              s.updated_at,
                              phone
                              FROM payments p
                              LEFT JOIN 
                              ( (SELECT id,
                              					updated_at,
                                        phone
                                        FROM simplex_end_users)
                                 UNION
                                 (SELECT current_simplex_user_id id,
                                 				 updated_at,
                                         phone
                                         FROM simplex_end_users_log)) s ON s.id = p.simplex_end_user_id
                                    -- ***************
                                    WHERE p.simplex_end_user_id = payment.simplex_end_user_id
                                    -- ***************
                                    AND   s.updated_at > p.created_at) a) b
						              WHERE updated_at = min_updated_at) a
                         	LEFT JOIN (SELECT inserted_at,
                                           wp_phone
                                    			 FROM WP_data wp )b
                                ON a.phone = b.wp_phone
                       WHERE wp_phone IS NOT NULL) THEN 1
         ELSE 0
       END is_payment_phone_same_as_wp_phone
FROM payments p
-- ***************
where p.id = payment.id
-- ***************
)

,lang_per_id  /* on commit drop */
as (
SELECT CASE
         WHEN POSITION(';' IN lang_with_weight) = 0 THEN lang_with_weight
         ELSE LEFT (lang_with_weight,POSITION(';' IN lang_with_weight) -1)
       END lang,
       CASE
         WHEN POSITION('q=' IN lang_with_weight) = 0 THEN NULL
         ELSE RIGHT (lang_with_weight,char_length(lang_with_weight) - POSITION('q=' IN lang_with_weight) -1)
       END weight,
       count(*) over (partition by id) lang_num,
       ip_country,
       ad_country
FROM (SELECT payment.id, payment.simplex_login ->> 'http_accept_language' lang_list,
             UNNEST(STRING_TO_ARRAY(payment.simplex_login ->> 'http_accept_language',',')) lang_with_weight,
             payment.maxmind ->> 'countryCode' AS ip_country,
             payment.country as ad_country
) a )

,lang_country_match /* on commit drop */  
AS
(SELECT 
       lang_num,
       CASE
         WHEN lang_num=1 and ad_lang_match>0 THEN 'single_match'
         WHEN ad_lang_match > 0 THEN 'match'
         ELSE 'no_match'
       END ad_lang_match,
       CASE
         WHEN lang_num = 1 AND ip_lang_match >0 THEN 'single_match'
         WHEN ip_lang_match > 0 THEN 'match'
         ELSE 'no_match'
       END ip_lang_match
FROM (SELECT  lang_num,
             SUM(CASE WHEN ad_lang_match = 'match' THEN 1 ELSE 0 END) ad_lang_match,
             SUM(CASE WHEN ip_lang_match = 'match' THEN 1 ELSE 0 END) ip_lang_match
      FROM (SELECT a.*, b.country_code, b.language_code, c.country_code, c.language_code,
                   CASE
                     WHEN LOWER(ad_country) != 'us' AND LOWER(lang) LIKE LOWER('%' || ad_country || '%') THEN 'match'
                     WHEN lower(b.language_code) LIKE LOWER('%' || ad_country || '%') THEN 'match'
                     WHEN lower(lang) LIKE LOWER('%' || b.language_code || '%') THEN 'match'
                     ELSE 'no_match'
                   END ad_lang_match,
                   CASE
                     WHEN LOWER(ip_country) != 'us' AND LOWER(lang) LIKE LOWER('%' || ip_country || '%') THEN 'match'
                     WHEN lower(c.language_code) LIKE LOWER('%' || ip_country || '%') THEN 'match'
                     WHEN lower(lang) LIKE LOWER('%' || c.language_code || '%') THEN 'match'
                     ELSE 'no_match'
                   END ip_lang_match
            FROM lang_per_id a
              LEFT JOIN lang_table b
                     ON a.ad_country = b.country_code
              LEFT JOIN lang_table c
                     ON a.ip_country = c.country_code) aa
      GROUP BY 1) bb)

,parsed_user_agent /* on commit drop */
AS (
				 SELECT CASE
         WHEN POSITION(';' IN user_agent) - POSITION('(' IN user_agent) < 0 THEN SUBSTRING(user_agent FROM POSITION('(' IN user_agent) +1 FOR POSITION(')' IN user_agent) - POSITION('(' IN user_agent) -1)
         ELSE SUBSTRING(user_agent FROM POSITION('(' IN user_agent) +1 FOR POSITION(';' IN user_agent) - POSITION('(' IN user_agent) -1)
         END user_agent_os
FROM (SELECT simplex_login ->> 'user_agent' user_agent
      FROM payments
      WHERE id=payment.id) a )



-- *******************  EMAIL **********************
,ea_attributes /* on commit drop */
as (
select email,inserted_at,
case when (ea_array ->> 'emailAge')='' then 0 else 1 end ea_is_age_created_at,
to_timestamp(regexp_replace(ea_array ->> 'firstVerificationDate','[TZ]', ' ','g'),'YYYY-MM-DD HH24:MI:SS') as ea_first_seen,
to_timestamp(regexp_replace(ea_array  ->> 'domainAge','[TZ]',' ','g'),'YYYY-MM-DD HH24:MI:SS') as ea_dom_created_at,
replace(ea_array  ->> 'eName','+',' ') ea_name,
ea_array  ->> 'status' ea_status,
ea_array  ->> 'country' ea_country,
cast(nullif(ea_array  ->> 'EAScore','') as numeric)  ea_score,
ea_array  ->> 'EAReason' ea_reason,
ea_array  ->> 'EARiskBandID' ea_risk_band,
ea_array  ->> 'dob' ea_dob,
ea_array  ->> 'gender' ea_gender,
replace(ea_array  ->> 'location','+',' ') ea_location,
cast(nullif(ea_array  ->> 'smfriends','') as numeric) ea_smfriends,
jsonb_array_length(ea_array  -> 'smlinks') ea_smlinks,
(nullif(ea_array  ->> 'totalhits','') ) ea_hits,
ea_array  ->> 'company' ea_company,
ea_array  ->> 'title' ea_title
from  (select email,inserted_at, DATA  #> '{query,results,0}' ea_array ,max(inserted_at) over (partition by email) max_inserted_at
from enrich_email_age
where email = payment.validation_request_body #>> '{email}'
) emailage
-- ***************

-- ***************
where inserted_at=max_inserted_at
)


-- RADAR --
,radar_proxy_detection /* on commit drop */
AS 
(
SELECT payment_id, 1000*cast(data #>> '{main,loose,diff}' as real) diff 
FROM (select *, max(inserted_at) over (partition by payment_id) max_inserted_at from proxy_detection
-- ***************
where payment_id = payment.payment_id
-- ***************
) pd where inserted_at=max_inserted_at
)
-- RADAR --


,cc_info_simplex_user /* on commit drop */
AS
(
SELECT 	array_agg (credit_card) cards,
        count(distinct x.credit_card) num_user_ccs
      FROM (SELECT credit_card
            FROM payments p
						where p.validation_request_body #>> '{email}' = payment.validation_request_body #>> '{email}'
            UNION
      			select credit_card
      			FROM payments_log pl
						where pl.validation_request_body #>> '{email}'  = payment.validation_request_body #>> '{email}'
--						where partner_end_user_id = 6313
            UNION
      			select validation_request_body #>> '{credit_card}' credit_card
      			FROM payments_log pl
						where pl.validation_request_body #>> '{email}' = payment.validation_request_body #>> '{email}'
--						where partner_end_user_id = 6313
						UNION
						select masked_credit_card credit_card
/*						when processor = 'secure_trading' then	
						replace (raw_response #>> '{maskedpan}', '#', '*') */
						
						FROM proc_requests_view prv
						left join payments p on (prv.payment_id = p.id)
						where p.validation_request_body #>> '{email}' = payment.validation_request_body #>> '{email}'
--						where partner_end_user_id = 6313
) x
where credit_card is not null
)


,phone_country_code_mismatch /* on commit drop */
AS
(
select simplex_end_user_id, 1 as mismatch from 
(
SELECT id simplex_end_user_id
FROM (SELECT *
      FROM (SELECT id,
                   country,
                   REPLACE(phone,'+','') phone
            FROM simplex_end_users
            -- ***************
where id = payment.simplex_end_user_id
-- ***************
) se
        LEFT JOIN (SELECT *,
                          CHAR_LENGTH(phone_code::text) prefix_len
                   FROM phone_country_codes) ph ON LEFT (se.phone,ph.prefix_len)::INT = ph.phone_code) aa
GROUP BY 1
HAVING SUM(CASE WHEN country = country_code THEN 1 ELSE 0 END) = 0
) a
)


-- *******************  partner_end_user_id **********************

,KYC  /* on commit drop */ as (
select
case when (kyc_files->'address'->0) is not null then 1 else 0 end address_KYC, 
case when (kyc_files->'identity'->0) is not null then 1 else 0 end identity_KYC,
case when social_data_id>0 then 1 else 0 end  social_media_partner 
from partner_end_users
-- **************
where id= payment.partner_end_user_id
-- **************
)

,total_partner_deposits /* on commit drop */
AS
(SELECT 
       SUM(amount_usd) fiat_amount,
       CASE
         WHEN SUM(alt_coin_deposits) > 0 THEN 1
         ELSE 0
       END alt_coin_deposits
FROM (SELECT
             CASE
               WHEN LOWER(currency) = 'ils' THEN amount*0.26
               WHEN LOWER(currency) = 'gbp' THEN amount*1.55
               WHEN LOWER(currency) = 'eur' THEN amount*1.12
               WHEN LOWER(currency) = 'usd' THEN amount
               ELSE NULL
             END amount_usd,
             CASE
               WHEN LOWER(currency) IN ('btc','ltc','drk','doge') THEN 1
               ELSE 0
             END alt_coin_deposits from 
(select cast(deposits#>>'{money,amount}' as real) amount, deposits#>>'{money,currency}' currency from 
(SELECT
       CASE
         WHEN jsonb_array_length (deposits) > 0 THEN jsonb_array_elements (deposits)
         ELSE NULL
       END AS deposits
FROM partner_end_users
-- ***********
WHERE id = payment.partner_end_user_id
-- ***********
) a
) b) c
)

--------------------------------------------------------------------------------------------------
-- Variables: payment_data_set -------------------------------------------------------------------
--------------------------------------------------------------------------------------------------
,payment_data_set /* on commit drop */
AS
(SELECT DISTINCT a.id payment_id,
       a.status,
       a.created_at,
       CASE
         WHEN lower(a.currency) = 'ils' THEN a.total_amount*0.26
         WHEN lower(a.currency) = 'gbp' THEN a.total_amount*1.55
         WHEN lower(a.currency) = 'eur' THEN a.total_amount*1.12
         WHEN lower(a.currency) = 'usd' THEN a.total_amount
         ELSE NULL
       END total_amount_usd,
       a.credit_card,
       a.country,
       a.simplex_end_user_id,
       a.partner_end_user_id,
       a.validation_request_body #>> '{email}' email,
       --       a.phone,
a.avs_code,
       CASE
         WHEN lower(b.first_name || ' ' || b.last_name) = lower(a.first_name_card || ' ' || a.last_name_card) THEN 'full_match'
         WHEN similarity (lower(b.first_name || ' ' || b.last_name),lower(a.first_name_card || ' ' || a.last_name_card)) >= 0.2 THEN 'partial_match'
         ELSE 'no_match'
       END name_on_card_match,
       rpd.diff radar_diff,
       coalesce(pccm.mismatch,0) phone_country_mismatch, 
       a.blocked -> 'ip' ->> 'blocked' blocked,
       CAST(a.maxmind ->> 'distance' AS REAL) AS mm_distance,
       a.maxmind ->> 'countryMatch' AS mm_countryMatch,
       a.maxmind ->> 'freeMail' AS mm_freeMail,
       a.maxmind ->> 'anonymousProxy' AS mm_anonymousProxy,
       a.maxmind ->> 'binMatch' AS mm_binMatch,
       a.maxmind ->> 'countryCode' AS ip_country,
       a.maxmind ->> 'binCountry' AS bin_country,
       
--lower(maxmind->>'binName') bin_bank,
CAST(a.maxmind ->> 'proxyScore' AS REAL) AS mm_proxyScore,
       a.maxmind ->> 'ip_userType' AS mm_ip_userType,
       CASE
         WHEN CHAR_LENGTH(maxmind ->> 'ip_postalCode') > 0 THEN 'zip'
         WHEN CHAR_LENGTH(maxmind ->> 'ip_city') > 0 THEN 'city'
         WHEN CHAR_LENGTH(maxmind ->> 'ip_regionName') > 0 THEN 'region'
         ELSE 'country'
       END AS mm_match_type,
       a.maxmind ->> 'ip_accuracyRadius' AS mm_ip_accuracyRadius,
       
--a.maxmind->>'ip_domain' as mm_ip_domain, --use to match email domain?
--right(b.email,char_length(b.email)-position('@' in b.email)) as email_domain,
a.maxmind ->> 'ip_corporateProxy' AS mm_ip_corporateProxy,
       a.maxmind ->> 'carderEmail' AS mm_carderEmail,
       CAST(a.maxmind ->> 'riskScore' AS REAL) AS mm_riskScore,
       a.maxmind ->> 'prepaid' AS mm_prepaid,
       CASE WHEN SUBSTRING(Coalesce(address1||' '||address2,address1) FROM '[0-9]+') IS NULL THEN 1 ELSE 0 END no_numbers_ad,
       a.first_name_card,
       a.last_name_card,
			CASE WHEN SUBSTRING(a.credit_card FROM 1 FOR 6) IN (SELECT *
			FROM virtual_bins) OR lower (maxmind ->> 'binName') IN ('entropay', 'teller','skrill', 'vanilla', 'nxpay') 
			THEN 1 ELSE 0 END is_virtual_cc,
			a.simplex_login->> 'uaid' cookie,
			a.simplex_login->> 'ip' ip,
			lower(a.address1 || ' ' || coalesce(a.address2,'') || ' ' || a.city || ' ' || a.country || ' ' || a.zipcode) address,
			a.btc_address,
			
			 c.two_fa_enabled,
       b.first_name,
       b.last_name,
			 
			--			ccisu.issuer_alert,
			ccisu.cards,
			ccisu.num_user_ccs,
			      
       CASE
         WHEN lower(ea.ea_reason) similar TO '%(risky|risk domain|risk email pattern|high risk|fraud|velocity)%' THEN 1
         ELSE 0
       END ea_reason_fraud,
       ea.ea_is_age_created_at,
       ea.ea_first_seen,
       ea.ea_dom_created_at,
       ea.ea_name,
       ea.ea_status,
       ea.ea_country,
       ea.ea_score,
       ea.ea_reason,
       ea.ea_risk_band,
       ea.ea_dob,
       ea.ea_gender,
       ea.ea_location,
       --ea.ea_smfriends,
       ea.ea_hits,
       ea.ea_company,
       ea.ea_title,
     --ea.inserted_at,

-- social media
case when ea_smfriends>0 or ea_smlinks>0 or social_media_partner=1 then 1 else 0 end is_sm,
--

			simplex_phone_prepaid,
			simplex_phone_line_type,       
			partner_phone_prepaid,
			partner_phone_line_type,
			simplex_phone_valid,
			partner_phone_valid,       
			simplex_name_valid,
			simplex_name_on_card_valid,
			partner_name_valid,       
			simplex_address_valid,
			partner_address_valid,
			simplex_phone_address_match,
			simplex_phone_name_match,
			simplex_address_name_match,
			simplex_phone_name_on_card_match,
			simplex_address_name_on_card_match,
			partner_phone_address_match,
			partner_phone_name_match,
			partner_address_name_match,     


       lcm.ip_lang_match,
       lcm.ad_lang_match,

       tsa.total_approved_amount,

       pua.user_agent_os,

       case when d.first_payment_id is not null then 1 else 0 end is_first,

        case when dis.dis_domain is null then 0 else 1 end is_email_disposable,

        tpd.fiat_amount - tsa.total_approved_amount  as past_usd_partner_deposits,
				tpd.alt_coin_deposits,

				identity_KYC,
				address_KYC, 

        partners.service_type partner_type 

--      g.sum_past_partner_deposits,
--			psd.sum_simplex_deposits   

FROM payments a
CROSS join cc_info_simplex_user ccisu
CROSS JOIN total_simplex_approved_amount tsa 
CROSS JOIN lang_country_match lcm
CROSS JOIN parsed_user_agent pua
CROSS JOIN total_partner_deposits tpd
--CROSS JOIN total_simplex_deposits tsd
CROSS JOIN KYC 															--ON KYC.partner_end_user_id = a.partner_end_user_id
LEFT JOIN WP_data wpd												on (a.id = wpd.payment_id)
LEFT JOIN simplex_end_users b 							ON a.simplex_end_user_id = b.id
left JOIN partner_end_users c 							ON a.partner_end_user_id = c.id
LEFT JOIN ea_attributes ea 									ON a.validation_request_body #>> '{email}' = ea.email
LEFT JOIN first_payments d 									ON a.id = d.first_payment_id
LEFT JOIN disposable_email_domains dis 			ON lower((SUBSTRING(b.email FROM (POSITION('@' IN b.email) +1)))) = dis.dis_domain
LEFT JOIN partners 													ON c.partner_id = partners.id

-- RADAR --
LEFT JOIN radar_proxy_detection rpd					ON rpd.payment_id = a.payment_id
-- RADAR --
LEFT JOIN phone_country_code_mismatch pccm			ON pccm.simplex_end_user_id = a.simplex_end_user_id

-- **************
WHERE a.id=payment.id
-- **************
)

------------------------   PAYMENT DATA SET --> FINAL DATA SET ----------------------------------------

,eligible_payment /* on commit drop */ as(
select min (is_eligible) is_eligible from (
select
case when
pd.payment_id <=69
or pd.email LIKE '%simplexcc.com'
or (LOWER ((c.text_data)) LIKE ANY(ARRAY['%random charge%', '%selfie%']) and status=1)
or LOWER ((c.text_data)) LIKE ANY(ARRAY['test%','% test%','%declined by mistake%','%fatf%','%underage%'])
then 0 else 1 end as is_eligible
FROM payment_data_set pd
  left JOIN comments c on (pd.payment_id=c.payment_id)
)z  
)

,cc_alerts /* on commit drop */
AS
(
-- MOVE FIRST LINE ONLY TO FINAL DATA SET!
SELECT case when sum (cc_status) > 0 then 1 else 0 end issuer_alert
			       FROM (SELECT masked_credit_card credit_card,
					   case when lower(status_description) like '%stolen %'
							 			or lower(status_description) like '%fraud%'
							 			or lower(status_description) like '%manipulation%'		 			
							 			or lower(status_description) like '%lost%'
					   then 1 else 0 end cc_status
						FROM proc_requests_view prv
						left join payments p on (prv.payment_id = p.id)
						where p.validation_request_body #>> '{email}' in (
            select distinct p.validation_request_body #>> '{email}' from proc_requests_view prv
						left join payments p on (prv.payment_id = p.id)            
						where masked_credit_card in
            (select unnest(cards) from payment_data_set) )
) x
)

,shared_elements  /* on commit drop */
as (

select
      max (case when zz.element_type='ip' 				 then zz.num else null end) ip_num_users,
      max (case when zz.element_type='address' 		 then zz.num else null end) ad_num_users,
      max (case when zz.element_type='cookie'  		 then zz.num else null end) cookie_num_users,
			max (case when zz.element_type='btc_address' then zz.num else null end) btc_address_num_users
--          case when sh.element_type='bin'					then sh.num end bin_num_users,

from (

select distinct element_type , count(distinct partner_end_user_id) num
--	case when element_type = 'ip'     then count(distinct partner_end_user_id) end num_ip_users
from (
select p.partner_end_user_id, 'cookie' element_type from payments p
cross join payment_data_set pd
 where simplex_login->> 'uaid' = pd.cookie 
UNION
select pl.partner_end_user_id, 'cookie' element_type from payments_log pl
cross join payment_data_set pd
 where simplex_login->> 'uaid' = pd.cookie 
union
select p.partner_end_user_id,  'ip' element_type  from payments p
cross join payment_data_set pd
 where simplex_login->> 'ip' <> '' and simplex_login->> 'ip' = pd.ip
UNION
select pl.partner_end_user_id, 'ip' element_type  from payments_log pl
cross join payment_data_set pd
where simplex_login->> 'ip' <> '' and simplex_login->> 'ip' = pd.ip
union
select p.partner_end_user_id, 'address' element_type  from payments p
cross join payment_data_set pd
where lower(p.address1 || ' ' || p.city || ' ' || p.country || ' ' || p.zipcode) = pd.address
UNION
select pl.partner_end_user_id, 'address' element_type  from payments_log pl
cross join payment_data_set pd
where lower(pl.address1 || ' ' || pl.city || ' ' || pl.country || ' ' || pl.zipcode) = pd.address
UNION
select p.partner_end_user_id, 'btc_address' element_type  from payments p
cross join payment_data_set pd
 where p.btc_address = pd.btc_address
UNION
select p.partner_end_user_id, 'btc_address' element_type  from payments_log p
cross join payment_data_set pd
 where p.btc_address = pd.btc_address
/*
-- PD.BIN DOES NOT EXIST AT THE MOMENT
select p.partner_end_user_id, 'bin' element_type  from payments p
cross join payment_data_set pd
 where left(credit_card,6) bin = pd.bin
UNION
select p.partner_end_user_id, 'bin' element_type  from payments p
cross join payment_data_set pd
 where left(credit_card,6) bin = pd.bin
*/
) b group by 1
)zz
)

,email_name_match  /* on commit drop */
as (
select
greatest(aa.first_match,aa.last_match,aa.full_match,aa.ea_full_match,aa.ea_first_match,aa.ea_last_match,aa.first_dom_match,aa.last_dom_match,aa.full_dom_match) email_name_match_score
 from (
select
--regexp_replace(SUBSTRING(email FROM 1 FOR (POSITION('@' IN email) -1)), '[^a-zA-Z]+', '','g')    ,
similarity(regexp_replace(SUBSTRING(email FROM 1 FOR (POSITION('@' IN email) -1)), '[^a-zA-Z]+', '','g'),replace(first_name,' ','')) first_match,
similarity(regexp_replace(SUBSTRING(email FROM 1 FOR (POSITION('@' IN email) -1)), '[^a-zA-Z]+', '','g'),replace(last_name,' ','')) last_match,
similarity(regexp_replace(SUBSTRING(email FROM 1 FOR (POSITION('@' IN email) -1)), '[^a-zA-Z]+', '','g'),replace(first_name || last_name,' ','')) full_match,
similarity(replace(first_name || last_name,' ',''),replace(ea_name,' ','')) ea_full_match,
similarity(replace(first_name,' ',''),replace(ea_name,' ','')) ea_first_match,
similarity(replace(first_name,' ',''),replace(ea_name,' ','')) ea_last_match,
similarity(regexp_replace(SUBSTRING(email FROM (POSITION('@' IN email) +1)), '[^a-zA-Z]+', '','g'),replace(first_name,' ','')) first_dom_match,
similarity(regexp_replace(SUBSTRING(email FROM (POSITION('@' IN email) +1)), '[^a-zA-Z]+', '','g'),replace(last_name,' ','')) last_dom_match,
similarity(regexp_replace(SUBSTRING(email FROM (POSITION('@' IN email) +1)), '[^a-zA-Z]+', '','g'),replace(first_name || last_name,' ','')) full_dom_match
from payment_data_set) aa)

-- ******************** PAYMENT_ID *******************************

,failed_auth_attempts  /* on commit drop */
as (
select count(distinct credit_card) failed_auth_diff_cc
from (
      SELECT masked_credit_card credit_card
            FROM proc_requests_view
            WHERE masked_credit_card IS NOT NULL
-- ***********						
AND payment_id= payment.id
-- ***********
)z
)

,verified_phone /* on commit drop */
AS
(
select coalesce (max(case when verified_at is null then 0 else 1 end), 0) verified_phone
from phone_verifications pv
left join payments p on (p.id = pv.payment_id)
-- ***********                     
WHERE p.partner_end_user_id= payment.partner_end_user_id
-- ***********
)

-- ******************** CREDIT_CARD *******************************

,cc_info_credit_card /* on commit drop */
AS
(
SELECT count(distinct x.email) num_cc_users
      FROM (SELECT validation_request_body #>> '{email}' email
            FROM payments p2
-- ******************
					  WHERE credit_card = payment.credit_card
-- ******************
            UNION
            SELECT validation_request_body #>> '{email}' email
            FROM payments_log pl
-- ******************
            WHERE credit_card = payment.credit_card
-- ******************
            UNION
            SELECT validation_request_body #>> '{email}' email
            FROM payments_log pl
-- ******************
            WHERE (validation_request_body ->> 'credit_card') = payment.credit_card
-- ******************
            UNION
            SELECT p.validation_request_body #>> '{email}'
            FROM proc_requests_view prv
						left join payments p on (prv.payment_id = p.id)
-- ******************
            WHERE masked_credit_card = payment.credit_card
-- ******************
) x
)

-- ******************** SIMPLEX_END_USER_ID *******************************

,verifications /* on commit drop */
AS
(
select verified_cards,
   		 case when array_length(verified_cards, 1) > 0 then 1 else 0 end verified_user from (
					SELECT array_agg (distinct credit_card) verified_cards from (
		 			select credit_card
					FROM payments p right join decisions d on (p.id= d.payment_id)
					WHERE reason = 'Verified'
					AND   batch_id IS NULL
					-- ***************
					AND   simplex_end_user_id = payment.simplex_end_user_id
					-- ***************
					UNION
					SELECT credit_card
					FROM verifications_history
					-- ***************
					WHERE simplex_end_user_id = payment.simplex_end_user_id
					-- ***************
					UNION
					-- verification might happen after the payment was declined, in that case the verification will appear in comments, not in decision
					SELECT credit_card from payments p join (SELECT payment_id, lower(STRING_AGG(REPLACE(text_data,E'\n',' '),',')) text_data FROM comments GROUP BY payment_id) c ON c.payment_id = p.id 
					WHERE text_data LIKE '%verified\_card%' 
					-- ***************
					AND simplex_end_user_id = payment.simplex_end_user_id				
					-- ***************
					)z
)x				
)

,users_history /* on commit drop */
AS
(
SELECT SUM(CASE WHEN status = 2 THEN 1 ELSE 0 END)  num_approves,
       SUM(CASE WHEN status = 11 THEN 1 ELSE 0 END)  num_declines
-- **********************
      FROM payments p2 where simplex_end_user_id = payment.simplex_end_user_id
-- **********************      
) 

-- ******************** SIMPLEX_END_USER_ID & PARTNER_END_USER_ID *******************************

,user_phones /* on commit drop */
AS
(
select count(distinct phone) num_user_phones
--FORMERLY: from phone_info
from
(
SELECT DISTINCT phone
FROM (SELECT    RIGHT (SUBSTRING(phone FROM '[0-9]+'),9) phone
--             'simplex' source
      FROM simplex_end_users
			-- ***********
			where id=payment.simplex_end_user_id
			-- ***************
      UNION
      SELECT   RIGHT (SUBSTRING(phone FROM '[0-9]+'),9) phone
--             'simplex_log' source
      FROM simplex_end_users_log
			-- ***********
			where current_simplex_user_id=payment.simplex_end_user_id
			-- ***************
      UNION
      SELECT   RIGHT (SUBSTRING(phone FROM '[0-9]+'),9) phone
--             'partner' source
      FROM partner_end_users peu
			-- ***********
			where id=payment.partner_end_user_id
			-- ***************
      AND   phone IS NOT NULL
      UNION
      SELECT RIGHT (SUBSTRING((api_requests -> 'nexmo' -> 'request_data' ->> 'number') FROM '[0-9]+'),9) phone
--             'browser_events' source
      FROM user_browser_events ube
        JOIN payments p ON (p.id = ube.payment_id)
			-- ***********
			where simplex_end_user_id=payment.simplex_end_user_id
			-- ***************
			AND (api_requests -> 'nexmo' -> 'request_data' ->> 'number')::text != ''
            ) z
WHERE char_length (phone) > 3
and phone is not null
-- sometimes only 2-3 nums of country appear
)z
 )

-- ******************** EMAIL *******************************

,override /* on commit drop */ as (
select max(case when lower (text_data) LIKE ANY(ARRAY['%override bender%']) then 1 else 0 end) override
FROM payments p
	join comments c on (p.id=c.payment_id)
where 
-- **********************
p.validation_request_body #>> '{email}' = payment.validation_request_body #>> '{email}'
-- **********************
)

,user_min_decision /* on commit drop */
AS
(SELECT simplex_end_user_id,
       MIN(decision_score) user_min_decision
FROM (SELECT *,
             CASE
               WHEN decision = 'declined' AND strength = 'Strong' THEN 1
               WHEN decision = 'declined' AND strength = 'Weak' THEN 2
               WHEN decision = 'approved' AND strength = 'Weak' THEN 3
               WHEN decision = 'approved' AND strength = 'Strong' THEN 4
-- important: see that logic does not conflict with this default value
               else 0
             END AS decision_score
      FROM (SELECT p.simplex_end_user_id,
--                   d.payment_id,
  --                 d.created_at,
                   d.decision decision,
                   d.variables #>> '{strength}' strength
            --d.reason 
            FROM decisions d
              LEFT JOIN payments p ON p.id = d.payment_id
              LEFT JOIN (SELECT payment_id, lower(STRING_AGG(REPLACE(text_data,E'\n',' '),',')) text_data FROM comments GROUP BY payment_id) c ON p.id = c.payment_id 
            WHERE application_name = 'Manual'
            AND   text_data NOT LIKE '%declined due to technical errors%' 
-- **********************
						AND simplex_end_user_id=payment.simplex_end_user_id
						AND p.id<>payment.id -- not current payment
-- **********************            
) a) b
GROUP BY 1)

,user_cc_last_decision /* on commit drop */
AS
(SELECT simplex_end_user_id,
 reason last_decision --('Didn't Respond to Verification', 'Refused Verification')
 FROM 
(SELECT d.payment_id, d.created_at,reason,simplex_end_user_id,
       max(d.created_at) over (partition by simplex_end_user_id) max_created_at
FROM decisions d
  LEFT JOIN payments p ON p.id = d.payment_id
LEFT JOIN (SELECT payment_id, lower(STRING_AGG(REPLACE(text_data,E'\n',' '),',')) text_data FROM comments GROUP BY payment_id) c ON p.id = c.payment_id 
            WHERE application_name = 'Manual'
            AND   text_data NOT LIKE '%declined due to technical errors%' 
-- **********************
and simplex_end_user_id = payment.simplex_end_user_id
and credit_card = payment.credit_card
and p.id<>payment.id -- not current payment
-- **********************  
) a where created_at = max_created_at)

----------------------------------------------
-- number of pending user payments 
, user_pending_payments /* on commit drop */
AS (
select simplex_end_user_id, count(id) from payments where status = 1 
-- ********************** 
and simplex_end_user_id = payment.simplex_end_user_id
and id<>payment.id
-- **********************
group by 1
)
--number of pending user + cc payments
, user_cc_pending_payments /* on commit drop */
AS (
select simplex_end_user_id, count(id) num from payments where status = 1 
-- ********************** 
and simplex_end_user_id = payment.simplex_end_user_id
and credit_card = payment.credit_card
and id<>payment.id
-- **********************
group by 1
)
----------------------------------------------
-- count number of times user + card 'Didn't Respond to Verification' or 'Refused Verification'
,user_cc_num_refused_verification /* on commit drop */
AS
(SELECT  simplex_end_user_id , count(distinct(p.id)) num_verification_try     
FROM decisions d
  LEFT JOIN payments p ON p.id = d.payment_id
WHERE application_name = 'Manual'
-- **********************
and simplex_end_user_id = payment.simplex_end_user_id 
and credit_card = payment.credit_card
-- **********************  
and (reason like  'Didn%t Respond to Verification'  or reason =  'Refused Verification')
group by 1
)
--------------------------------------------------------

--------------------------------------------------------------------------------------------------
-- Variables: final_data_set ---------------------------------------------------------------------
--------------------------------------------------------------------------------------------------
,final_data_set  /* on commit drop */
as (
SELECT  distinct 
			  pd.payment_id id,
       --pd.status,
			 --pd.total_amount_usd,
       --pd.mm_binmatch,
       --pd.country,
       --pd.ip_country,
       --pd.bin_country,
       CASE
         WHEN pd.mm_proxyscore > 0 THEN 'yes'
         WHEN pd.mm_anonymousproxy = 'Yes' THEN 'yes'
         WHEN pd.blocked='YES' THEN 'yes'
         ELSE 'no'
       END is_proxy_external,
       -- RADAR --
       --radar_diff,
       CASE WHEN radar_diff>25 THEN 'yes'
       ELSE 'no'
       END is_proxy_radar,
       -- RADAR --
       case when pd.mm_ip_usertype in ('school','traveler','college') then 'other'
       else pd.mm_ip_usertype
       END mm_ip_user_type,
       --pd.mm_match_type,
       --pd.mm_riskscore,
       --pd.no_numbers_ad,
       --pd.mm_carderemail,
       --pd.mm_ip_accuracyRadius,
       --pd.mm_prepaid,
       case when pd.avs_code = 'F' then 'full_match'
       when pd.avs_code = 'P' then 'partial_match'
       when pd.avs_code = 'N' then 'no_match'
       else 'not_valid' end avs_match,       
       CASE
         WHEN pd.mm_match_type = 'zip' AND pd.mm_distance <= 5 THEN 'super_close'
         WHEN pd.mm_match_type IN ('zip','city') AND pd.mm_distance <= 30 THEN 'close'
         WHEN pd.mm_match_type IN ('zip','city') AND pd.mm_distance <= 100 THEN 'in_area'
         WHEN pd.mm_countryMatch = 'Yes' THEN 'country'
         ELSE 'no_match'
       END AS ip_ad_match,
       CASE
         WHEN pd.email similar TO '%@%(gov|edu|mil|org).%' THEN 'ctrld'
         WHEN lower(pd.mm_carderemail) LIKE 'yes' THEN 'carder'
         WHEN lower(pd.mm_freemail) LIKE 'yes' THEN 'free'
         ELSE 'none'
       END AS email_type,

			--pd.num_user_ccs,
			--is_sm,
      case when uh.num_approves > 0 then 1 else 0 end approved_user,
            case when uh.num_declines > 1 then 1 else 0 end declined_user,     -- notice diff btw last 2 lines

			umd.user_min_decision,
			uld.last_decision,
			coalesce(urv.num_verification_try,0) num_verification_try,			 
			coalesce(ucpp.num,0) user_cc_pending_payments,
			
			up.num_user_phones,

      ovr.override, 

--      case when sbu1.simplex_end_user_id is not null
  --              or sbu2.email is not null then 1 else 0 end is_issuer_alert,
			cca.issuer_alert is_issuer_alert,
			
			cicc.num_cc_users,
			
			
			vp.verified_phone,
			
			ep.is_eligible,
			em.email_name_match_score,
      --ea_smfriends,

       ---***---***---***---***---***---      
--        CASE
--          WHEN lower(first_name || ' ' || last_name) = lower(first_name_card || ' ' || last_name_card) THEN 'full_match'
--          WHEN similarity (lower(first_name || ' ' || last_name),lower(first_name_card || ' ' || last_name_card)) >= 0.2 THEN 'partial_match'
--          ELSE 'no_match'
--        END name_on_card_match,
       --name_on_card_match,
       ---***---***---***---***---***---
       --identity_KYC,
  		--address_KYC,
       --two_fa_enabled,
       faa.failed_auth_diff_cc,       
       --ad_lang_match,
       --ip_lang_match,
/*       case when sum_past_partner_deposits=0 then 'none'
       when sum_past_partner_deposits>200 then 'medium'
       else 'high'
       end past_partner_deposits, */
       --user_agent_os,
       --is_first,

       --**--
--ea_reason_fraud,
--**--
case when extract(days FROM (pd.created_at-ea_first_seen)::interval)::real<0 then 0
else extract(days FROM (pd.created_at-ea_first_seen)::interval)::real end as ea_age,
            --ea_score,
            --pd.created_at, 
-- ip/cookie etc : "num_users" can be 1 (as opposed to v1.4.4)
            sh.ip_num_users,
            sh.ad_num_users,
            sh.cookie_num_users,
            sh.btc_address_num_users,
--          sh.bin_num_users,

		        --is_email_disposable,
    		    --partner_type,


--        case when v1.simplex_end_user_id is not null then 1 else 0 end verified_user,
--		      case when v2.credit_card is not null then 1 else 0 end verified_card,           
 					case when pd.credit_card like any (v.verified_cards) then 1 else 0 end verified_card, 
 					v.verified_user,

        	--total_approved_amount,
         	--past_usd_partner_deposits,
 					--alt_coin_deposits,
  		--simplex_phone_prepaid, partner_phone_prepaid,
			--simplex_phone_line_type, partner_phone_line_type,        
-- partner
case when partner_phone_valid = 'ok' and partner_name_valid='ok' then partner_phone_name_match else 'not_valid' end as wp_partner_phone_name,
case when partner_phone_valid = 'ok' and partner_address_valid='ok' then partner_phone_address_match else 'not_valid' end as wp_partner_phone_address,
case when partner_name_valid = 'ok' and partner_address_valid='ok' then partner_address_name_match else 'not_valid' end as wp_partner_address_name,
-- simplex name
case when simplex_phone_valid = 'ok' and simplex_name_valid='ok' then simplex_phone_name_match else 'not_valid' end as wp_simplex_phone_name,
case when simplex_phone_valid = 'ok' and simplex_address_valid='ok' then simplex_phone_address_match else 'not_valid' end as wp_simplex_phone_address,
case when simplex_name_valid = 'ok' and simplex_address_valid='ok' then simplex_address_name_match else 'not_valid' end as wp_simplex_address_name,
-- simplex name on card
case when simplex_phone_valid = 'ok' and simplex_name_on_card_valid='ok' then simplex_phone_name_on_card_match else 'not_valid' end as wp_simplex_phone_name_on_card,
case when simplex_name_on_card_valid = 'ok' and simplex_address_valid='ok' then simplex_address_name_on_card_match else 'not_valid' end as wp_simplex_address_name_on_card,

is_payment_phone_same_as_wp_phone,

case when identity_KYC = 1 and  name_on_card_match <> 'no_match' and is_virtual_cc = 0 and bin_country = country then 1 else 0 end suitable_for_selfie,
case WHEN country IN ('ID','DZ','EC','MM','IR','KP','LB','IQ','SY') OR bin_country IN ('ID','DZ','EC','MM','IR','KP','LB','IQ','SY') OR ip_country IN ('ID','DZ','EC','MM','IR','KP','LB','IQ','SY') THEN 1 else 0 end is_fatf, 
--case WHEN mm_riskscore > 69 THEN 1 else 0 end mm_risk_score_high,                             
--CASE WHEN (extract(hour from pd.created_at) > 17 or extract(hour from pd.created_at)  < 4) 	then 1 else 0 end  is_night_time,
case WHEN country IN ('UA','RU','MX','SA') OR bin_country IN ('UA','RU','MX','SA') OR ip_country IN ('UA','RU','MX','SA') then 1 else 0 end is_risky_county,
case WHEN ea_reason_fraud = 1 OR ea_score>500 then 1 else 0 end emailage_alert,
case WHEN sh.cookie_num_users>1 OR sh.ip_num_users>1 OR sh.ad_num_users>1 OR cicc.num_cc_users>1 or sh.btc_address_num_users>1 then 1 else 0 end linked_to_another_user

---***---***---***---***---***---
FROM payment_data_set pd
CROSS JOIN eligible_payment ep
CROSS JOIN users_history uh
CROSS JOIN user_phones up
CROSS JOIN override ovr
cross JOIN cc_alerts  cca
CROSS JOIN cc_info_credit_card cicc
CROSS JOIN verified_phone vp
cross join verifications v
CROSS JOIN shared_elements sh 						
CROSS JOIN email_name_match em 					
CROSS JOIN failed_auth_attempts faa
LEFT JOIN WP_payment_phone_match wp_ppm on (wp_ppm.payment_id = pd.payment_id)
LEFT JOIN user_min_decision umd 				ON umd.simplex_end_user_id = pd.simplex_end_user_id
LEFT JOIN user_cc_last_decision uld			ON uld.simplex_end_user_id = pd.simplex_end_user_id
LEFT JOIN user_cc_num_refused_verification urv ON urv.simplex_end_user_id = pd.simplex_end_user_id
LEFT JOIN user_cc_pending_payments ucpp ON ucpp.simplex_end_user_id = pd.simplex_end_user_id
)




-------------------------------------------------------------------------------------------------
-- Verifications --------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------

,verification_data_set  /* on commit drop */
as (
SELECT id id_tmp,
-- which verification to send
---- photo selfie ----
-- strong approve
CASE when suitable_for_selfie = 1 and user_min_decision = 4 then  'true'
-- weak approve 
when suitable_for_selfie = 1 and user_min_decision = 3 then 'false'
-- first payment
when is_first = 1 and suitable_for_selfie = 1 and total_amount_usd<=350 then 'true'
-- otherwise
else 'false' end as photo_selfie,
---- video selfie ----
-- strong approve
CASE when suitable_for_selfie = 1 and user_min_decision = 4 then  'false'
-- weak approve 
when suitable_for_selfie = 1 and user_min_decision = 3 then 'true'
-- first payment
when is_first = 1 and suitable_for_selfie = 1 and total_amount_usd>350 then 'true'
-- otherwise
else 'false' end as video_selfie,
---- random charge ----
'true' as random_charge,

-- which explanation format to show \ letter to send 
CASE when is_first = 0 and user_min_decision = 4  	-- returning + strong approve + over limit 
then 'strong approve - first time verification'
when is_first = 0 and user_min_decision = 3  	-- returning + weak approve + over limit
then 'weak approve - first time verification'
when is_first = 0 and verified_user = 1 and verified_card = 0	-- returning + verified user + new card
then 'verified user - new card'
when is_first = 1
then 'first payment'
else null 
end as verification_format,

-- address good
case when (avs_match in ('full_match', 'partial_match') and 
(wp_simplex_address_name in ('full_match', 'partial_match') or 
wp_simplex_address_name_on_card in ('full_match', 'partial_match'))
and ip_ad_match in ('super_close', 'close','in_area')) then 1 else 0 end address_good,
 
-- ip good (not proxy, close to address)
case when (is_proxy_external = 'no' and is_proxy_radar = 'no' and ip_ad_match in ('super_close', 'close','in_area')) then 1 else 0 end ip_good,

-- email good
case when (ea_age > 90 and is_email_disposable = 0 and email_name_match_score > 0.5) then 1 else 0 end email_good,

-- phone good
case when (verified_phone = 1 and is_payment_phone_same_as_wp_phone = 1
and (wp_simplex_phone_name in ('full_match', 'partial_match') or
wp_simplex_phone_name_on_card in ('full_match', 'partial_match') or
wp_simplex_phone_address in ('full_match', 'partial_match'))) then 1 else 0 end phone_good
from final_data_set cross join payment_data_set
)

-------------------------------------------------------------------------------------------------
-- Rules -----------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------
-- decline
-- CASE when is_eligible = 0 then 'not eligible - for Bender'
-- approve
-- verify (night time)
-- decide what verification method to use

,simplex_rules /* on commit drop */
AS (
-- 'recommend approve - returning'
-- 'recommend approve - verified phone match'
-- 'recommend approve - address ip match'
-- 'recommend approve'
-- 'manual'
-- 'recommend decline'
-- 'auto decline'
-------------------***********************----------------------------------
SELECT id, status,
case
-- override bender
when override= 1 then 'manual - override bender'
when is_eligible = 0 then 'not_eligible - not eligible for Bender'
-- decline - auto decline
when is_fatf = 1 then 'declined - fatf'
when is_issuer_alert = 1 and  approved_user= 0 then 'declined - issuer alert'
when mm_carderemail = 'Yes' and  approved_user= 0 then 'declined - carder email'
-- auto decline returning bad user
--
-- decline - recommend decline
when failed_auth_diff_cc > 3 then 'recommend_decline - failed auths in payment'
when mm_riskscore > 69 then 'recommend_decline - high mm risk score'
when num_user_ccs > 7
-- when num_user_status_0_cards >7
-- *****
and approved_user = 0
-- and num_fresh_ccs < 3
-- *****
 then 'recommend_decline - over 7 ccs total'

-- manual - beats approve, beats verified
when linked_to_another_user = 1 then 'manual - linking'
when num_user_phones > 2 then 'manual - too many phones'
when avs_match = 'no_match' then 'manual - avs mismatch'
when num_user_ccs > 4 then 'manual - too many ccs'

-- auto approve returning, verified, under limit
when is_first = 0 and verified_user = 1 and verified_card = 1  and (total_amount_usd+total_approved_amount)<2500
then 'approved - verified'
-- returning, verified, over limit - move to manual
when is_first = 0 and verified_user = 1 and verified_card = 1 and (total_amount_usd+total_approved_amount)>=2500 	-- returning + verified + over limit
then 'manual - verified over limit'
-- returning, were strong approve, under limit
when is_first = 0 and verified_card = 0 and user_min_decision = 4 and (total_amount_usd+total_approved_amount)<800
then 'recommend_approve - returning strong approve'
-- returning, were weak approve, under limit
when is_first = 0 and verified_card = 0 and user_min_decision = 3 and (total_amount_usd+total_approved_amount)<250
then 'recommend_approve - returning weak approve'

----------------------------------------------------------------------------------------------------------------------------------------------
-- auto verification
-- returning + strong approve + over limit 
when 	(is_first = 0 and verified_card = 0 and user_min_decision = 4 and (total_amount_usd+total_approved_amount)>=800) 	
-- returning + weak approve + over limit
or 		(is_first = 0 and verified_card = 0 and user_min_decision = 3 and (total_amount_usd+total_approved_amount)>=250) 	
-- returning + verified user + new card
or 		(is_first = 0 and verified_user = 1 		and verified_card = 0) 															
then 'verify - returning'
----------------------------------------------------------------------------------------------------------------------------------------------
-- returning + didn't respond to verification (decision or still pending)
when is_first = 0 and verified_card = 0 
and (last_decision like 'Didn%t Respond to Verification' or  last_decision = 'Refused Verification' or user_cc_pending_payments>=1 ) 
and num_verification_try + user_cc_pending_payments < 3 -- support ticket
then 'verify - did not respond'
-- returning + didn't respond to verification more than 3 times
when is_first = 0 and verified_card = 0 
and (last_decision like 'Didn%t Respond to Verification' or  last_decision = 'Refused Verification' or user_cc_pending_payments>=1) 
and num_verification_try + user_cc_pending_payments >= 3
then 'declined - over 3 verification attempts'

-- auto approve new user
-- phone verification cycle
when is_first = 1
--and total_amount_usd<250
and name_on_card_match in ('full_match', 'partial_match')
and is_proxy_external = 'no'
and radar_diff<25
and verified_phone = 1 
and num_user_phones=1
and is_payment_phone_same_as_wp_phone = 1
and wp_simplex_phone_name in ('full_match', 'partial_match')
and ea_age > 90 
and email_name_match_score > 0.5
and ip_ad_match != 'no_match'
then 'recommend_approve - verified phone match'

-- address-ip cycle
when is_first = 1
--and total_amount_usd<250
and name_on_card_match in ('full_match', 'partial_match')
and avs_match in ('full_match', 'partial_match')
and is_proxy_external = 'no'
and radar_diff<25
and verified_phone  = 1 
and ea_age > 90 
and email_name_match_score > 0.5
and ip_ad_match in ('super_close', 'close','in_area') 
and wp_simplex_address_name in ('full_match', 'partial_match')
then 'recommend_approve - address ip match'

---------------------------------------------------------------------------------------------------------------------------------------------- 
-- first time verification for new users 
when is_first = 1 
-- not bad
and failed_auth_diff_cc<=2 and num_user_ccs<=2 and ea_reason_fraud = 0 and is_sm = 0   
-- amount
and total_amount_usd > 200
-- 3 out of 4 conditios are good 
and  address_good+ip_good+email_good+phone_good = 3
then 'verify - first'

----------------------------------------------------------------------------------------------------------------------------------------------
ELSE 'manual - none' 
END as rule_desc
FROM final_data_set 
CROSS JOIN payment_data_set
CROSS JOIN verification_data_set )

--------------------------------------------------------------------------------------------------
-- Bender execution ------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------
SELECT payment_pk payment_id,
			left(rule_desc, position('-' in rule_desc)-2)::decision_type AS decision,
			(variables::jsonb->0)::varchar ::jsonb variables,
			split_part(rule_desc, '-', 2) reason,
 			'Analytic' AS application_name,
			'2.0' AS analytic_code_version,
      timezone('utc',NOW()) AS executed_at
INTO model_decision
FROM simplex_rules sr
  LEFT JOIN (
    SELECT var.id,
             json_agg(var.*) variables
             FROM (select a.*,b.*,c.*
             from final_data_set a
             join payment_data_set b
                         on a.id=b.payment_id
             join verification_data_set c 
                         on a.id=c.id_tmp
) var
             GROUP BY 1) var_agg ON sr.id = var_agg.id
-- where status in (1, 6)
where status >0
AND sr.id = payment_pk
;
-- END OF ANALYTIC CODE;
RETURN model_decision;
END;
$$;

