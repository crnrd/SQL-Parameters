CREATE MATERIALIZED VIEW http_sessions AS SELECT http_sessions_live.id,
    http_sessions_live.ip,
    http_sessions_live.uaid,
    http_sessions_live.accept_language,
    http_sessions_live.http_user_agent_id,
    http_sessions_live.inserted_at,
    http_sessions_live.cookie_session_id
   FROM http_sessions_live;

CREATE UNIQUE INDEX http_sessions_id_pk
  ON http_sessions (id);

CREATE UNIQUE INDEX http_sessions_cookie_session_id_idx
  ON http_sessions (cookie_session_id);

